﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BattleHUD : MonoBehaviour
{
    [SerializeField] Image heroHeadImage;
    [SerializeField] TMP_Text heroName;
    [SerializeField] TMP_Text heroClass;

    [SerializeField] TMP_Text HeroHealthValue;
    [SerializeField] TMP_Text HeroAccValue;
    [SerializeField] TMP_Text HeroCritValue;
    [SerializeField] TMP_Text HeroDmgValue;
    [SerializeField] TMP_Text HeroDodgeValue;
    [SerializeField] TMP_Text HeroProtValue;
    [SerializeField] TMP_Text HeroSpdValue;

    [SerializeField] SkillButton[] skillButtons;

    public void UpdateSkillButtonSpriteColor(bool ToF,int skillPosition)
    {
        if(ToF == true)
        {
            skillButtons[skillPosition].skillImage.color = new Color(1, 1, 1, 1);
        }
        else
        {
            skillButtons[skillPosition].skillImage.color = Color.gray;
        }
    }

    public void UpdateHeroUI(Character Hero)
    {
        heroHeadImage.sprite = Hero.CharacterBase.HeadSprite;
        heroName.text = Hero.HeroName;
        heroClass.text = Hero.CharacterBase.CharacterClass.ToString();

        HeroHealthValue.text = Hero.HeroCurrentHP.ToString() + " / " + Hero.HeroMaxHealth.ToString();
        HeroAccValue.text = Hero.HeroAccracyCorrect.ToString();
        HeroCritValue.text = Hero.HeroCriticalChance.ToString();
        HeroDmgValue.text = Hero.HeroMinAttack.ToString() + "-" + Hero.HeroMaxAttack.ToString();
        HeroDodgeValue.text = Hero.HeroAvoid.ToString();
        HeroProtValue.text = Hero.HeroDefense.ToString();
        HeroSpdValue.text = Hero.HeroSpeed.ToString();

        for(int i = 0; i < Hero.ValidSkill.Count;i++)
        {
            skillButtons[i].UpdateSkill(Hero.ValidSkill[i]);
        }

    }
}
