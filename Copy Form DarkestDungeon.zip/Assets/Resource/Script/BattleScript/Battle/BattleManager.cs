﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BattleState
{
    Start,PlayerActionSelection,PlayerSkillTargetSelection,EnemyTurn,RunTurn,Busy,PlayerWin,PlayerLose
}
public class BattleManager : MonoBehaviour
{
    PlayerParty playerParty;

    [SerializeField] Camera battleCamera;

    [SerializeField] List<BattleUnit> playerUnitList;
    [SerializeField] List<GameObject> playerUnitGameObjectList;
    [SerializeField] List<BattleUnit> enemyUnitList;
    [SerializeField] List<GameObject> enemyUnitGameObjectList;

    [SerializeField] List<Character> enemyParty;

    [SerializeField] Character CurrentCharacter;
    [SerializeField] BattleUnit currentUnit;

    [SerializeField] BattleHUD battleHUD;
    [SerializeField] MapEnemyParty mapEnemyParty;
    [SerializeField] GameObject playerBattleAnimGameObject;
    [SerializeField] GameObject enemyBattleAnimGameObject;
    [SerializeField] List<Transform> playerBattlePlaceList;
    [SerializeField] List<Transform> enemyBattlePlaceList;


    private BattleState battleState;
    private List<AttackOrder> attackOrderList;
    private int currentAttackIndex;
    private Skill currentHandleSkill;
    public BattleState BattleState => battleState;
    public BattleUnit CurrentUnit => currentUnit;
    public List<BattleUnit> PlayerUnitList => playerUnitList;
    public List<BattleUnit> EnemyUnitList => enemyUnitList;
    public List<Transform> PlayerBattlePlaceList => playerBattlePlaceList;
    public List<Transform> EnemyBattlePlaceList => enemyBattlePlaceList;



    private void Awake()
    {
        playerParty = GetComponent<PlayerParty>();
        battleHUD = GetComponent<BattleHUD>();
        mapEnemyParty = GetComponent<MapEnemyParty>();
    }
    private void Start()
    {
        CurrentCharacter = playerParty.playerParty[0];// ** Temp ** \\

        StartBattle();
        //battleHUD.UpdateHeroUI(CurrentCharacter);

    }

    private void Update()
    {
        HandleTurnUpdate();
    }

    public int BattleUnitPosition(BattleUnit battleUnit)
    {
        return battleUnit.IsPlayerUnit ? playerUnitList.IndexOf(battleUnit) : enemyUnitList.IndexOf(battleUnit);
    }

    private void InitPlayerUnit()
    {
         //需要一个更好的初始化方法
        for(int i = 0; i < playerParty.playerParty.Count; i++)
        {
            if(playerParty.playerParty[i].CharacterBase == null)
            {
                playerParty.playerParty.RemoveAt(i);
                i--;
            }
        }

        //从这开始，PlayerParty可能就没有4个了
        for(int i = 0; i < playerParty.playerParty.Count; i++)
        {
            playerUnitList[i].InitUnit(playerParty.playerParty[i]);
            playerUnitList[i].transform.localPosition = playerBattlePlaceList[i].transform.localPosition;
        }
        for(int i = playerParty.playerParty.Count; i < 4; i++)
        {
            //TO DO 隐藏Unit
            playerUnitGameObjectList[i].SetActive(false);
        }
    }


    public void HandleTurnUpdate()
    {
        if(battleState == BattleState.PlayerActionSelection)
        {
            HandlePlayerActionSelect();
        }else if(battleState == BattleState.PlayerSkillTargetSelection)
        {
            HandleSkillTargetSelection(currentHandleSkill);
        }

        CurrentUnit.SetCurrentHero();
    }
    public void HandlePlayerActionSelect()
    {
        if (battleState == BattleState.PlayerActionSelection)
        {
            //TO DO 玩家回合逻辑
            for (int i = 0; i < CurrentUnit.UnitCharacter.ValidSkill.Count; i++)
            {
                if (CurrentUnit.UnitCharacter.ValidSkill[i].SkillBase.SkillTargetPosition.CanUsePos[BattleUnitPosition(CurrentUnit)] == true)
                {
                    battleHUD.UpdateSkillButtonSpriteColor(true, i);
                }
                else
                {
                    battleHUD.UpdateSkillButtonSpriteColor(false, i);
                }
            }
        }
    }
    public void PlyaerSelectedSkill(Skill selectedSkill)
    {
        battleState = BattleState.PlayerSkillTargetSelection;
        currentHandleSkill = selectedSkill;
    }

    public void HandleSkillTargetSelection(Skill skill)
    {
        if(skill.SkillBase != null)
        {
            if(skill.SkillBase.SkillTarget == SkillTarget.Enemy)
            {
                for(int i = 0; i < enemyUnitList.Count; i++)
                {
                    if(skill.SkillBase.SkillTargetPosition.CanAttackPos[i] == true)
                    {
                        enemyUnitList[i].SetHitableEnemy(true);
                    }
                    else
                    {
                        enemyUnitList[i].SetHitableEnemy(false);
                    }
                }
            }else if(skill.SkillBase.SkillTarget == SkillTarget.Ally)
            {
                //TO DO 对队友释放的技能   
            }else if(skill.SkillBase.SkillTarget == SkillTarget.Self)
            {
                //TO DO 只对自身释放的技能
            }
        }
        //↑更新UI指示
        //↓玩家交互
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
            //点击左键，看是否点到了角色
            var colliders = Physics2D.OverlapPointAll(battleCamera.ScreenToWorldPoint(Input.mousePosition));

            if(currentHandleSkill.SkillBase.SkillTarget == SkillTarget.Enemy)
            {
                //只能对敌人使用
                foreach (var col in colliders)
                {
                    if (col.GetComponent<BattleUnit>() != null)
                    {
                        var _SkillTarget = col.GetComponent<BattleUnit>();
                        if (SkillAllowToHit(currentHandleSkill,_SkillTarget) && _SkillTarget.IsPlayerUnit == false)
                        {
                            ClearAllMark();
                            currentAttackIndex++;
                            StartCoroutine(RunTurn(CurrentUnit, _SkillTarget, currentHandleSkill));//开始执行技能逻辑
                        }
                        else
                        {
                            //TO DO:提示选错目标了
                            Debug.Log("技能目标非法");
                        }
                    }
                }
            }else if(currentHandleSkill.SkillBase.SkillTarget == SkillTarget.Ally)
            {
                //只能对队友使用

            }else if(currentHandleSkill.SkillBase.SkillTarget == SkillTarget.Self)
            {
                //只能对自己使用
            }
        }

        if (Input.GetKeyDown(KeyCode.Mouse1))
        {
            currentHandleSkill = null;
            battleState = BattleState.PlayerActionSelection;
            ClearAllMark();
        }
    }

    public bool SkillAllowToHit(Skill skill,BattleUnit battleUnit)//判断是否能够打中目标
    {
        if (skill.SkillBase.SkillTargetPosition.CanAttackPos[BattleUnitPosition(battleUnit)])
            return true;
        return false;
    }

    private void InitEnemyUnit()
    {
        for(int i = 0; i < enemyParty.Count; i++)
        {
            if (enemyParty[i].CharacterBase != null)
            {
                enemyUnitGameObjectList[i].SetActive(true);
                enemyUnitList[i].InitUnit(enemyParty[i]);
            }

        }
    }
    public void SetCurrentUnit()
    {
        if(CurrentUnit == null)
        {
            currentUnit = playerUnitList[0];
        }

        CurrentUnit.SetCurrentHero();
        battleHUD.UpdateHeroUI(CurrentUnit.UnitCharacter);
        
    }
    public void StartBattle()
    {
        battleState = BattleState.Start;
        this.enemyParty = mapEnemyParty.GetRandomEnemyParty().TheEnemyParty;
        InitPlayerUnit();
        InitEnemyUnit();
        SetCurrentUnit();

        JudgeAttackOrder();
        currentAttackIndex = 0;

        StartTurn();
    }

    public void StartTurn()
    {
        if (battleState == BattleState.PlayerWin||battleState == BattleState.PlayerLose) return;

        if (playerUnitList.Contains(attackOrderList[currentAttackIndex].BattleUnit))
        {
            
            battleState = BattleState.PlayerActionSelection;
            currentUnit = attackOrderList[currentAttackIndex].BattleUnit;
        }
        else if(enemyUnitList.Contains(attackOrderList[currentAttackIndex].BattleUnit))
        {
            //TO DO 敌人回合
            battleState = BattleState.EnemyTurn;
            currentUnit = attackOrderList[currentAttackIndex].BattleUnit;
            StartCoroutine(StartEnemyTurn());
        }
        else
        {
            currentAttackIndex++;
            StartTurn();
        }

        if(currentAttackIndex == attackOrderList.Count)
        {
            currentAttackIndex = 0;
            JudgeAttackOrder();
        }
    }

    public IEnumerator StartEnemyTurn()
    {
        //TO DO : 敌人AI
        ClearAllMark();
        var enemySkill = currentUnit.GetRandomSkill();
        var skillTarget = playerUnitList[0];
        currentAttackIndex++;
        yield return RunTurn(currentUnit, skillTarget, enemySkill);
        //Mark : 2021/02/07 16:30做到这里
        //接下来完成敌人AI，敌人死亡/玩家死亡逻辑 
    }

    public IEnumerator RunTurn(BattleUnit sourceUnit,BattleUnit targetUnit,Skill skill)
    {
        battleState = BattleState.RunTurn;
        ClearAllMark();

        if (skill.SkillBase.IsAoeSkill == false)
        {
            //TO DO :单体技能
            sourceUnit.SetCurrentHero();
            targetUnit.SetHitableEnemy(true);
            yield return new WaitForSeconds(0.3f);
            var attack = Random.Range(sourceUnit.UnitCharacter.HeroMinAttack, sourceUnit.UnitCharacter.HeroMaxAttack + 1);
            var damage = attack * (1 + (skill.SkillBase.DamageCorrection / 100.0));
            yield return ReciveDamageAnim(sourceUnit,targetUnit);
            var targetCurrentHP =  targetUnit.ReciveDamage((int)damage, skill);
            if(targetCurrentHP <= 0)
            {
                //PlayerUnitDead(targetUnit);
                //TO DO 死亡处理
                UnitDead(targetUnit);
            }

        }
        else
        {
            //TO DO :范围技能
        }
        yield return new WaitForSeconds(0.5f);
        ClearAllMark();
        StartTurn();

    }

    public void UnitDead(BattleUnit battleUnit)
    {
        if (battleUnit.IsPlayerUnit)
        {

            //TO DO 玩家角色死亡
            playerParty.playerParty.Remove(battleUnit.UnitCharacter);

            UpdatePlayerUnitPosition();
            if(playerParty.playerParty.Count == 0)
            {
                PlayerLoseBattle();
            }
        }
        else
        {

            //TO DO 敌人角色死亡
            enemyParty.Remove(battleUnit.UnitCharacter);


            UpdateEnemyUnitPosition();
            if(enemyParty.Count == 0)
            {
                PlayerWinBattle();
            }
        }
    }

    public void PlayerLoseBattle()
    {
        battleState = BattleState.PlayerLose;
        //TO DO 玩家失败
        Debug.Log("玩家失败");
    }

    public void PlayerWinBattle()
    {
        battleState = BattleState.PlayerWin;
        //TO DO 玩家胜利
        Debug.Log("玩家胜利");
    }

    public void UpdatePlayerUnitPosition()
    {
        for(int i = 0; i < playerParty.playerParty.Count; i++)
        {
            playerUnitList[i].InitUnit(playerParty.playerParty[i]);
        }
        for(int i = playerParty.playerParty.Count; i < 4; i++)
        {
            playerUnitList[i].ClearCurrentCharacter();
            playerUnitGameObjectList[i].SetActive(false);
        }
    }

    public void UpdateEnemyUnitPosition()
    {
        for (int i = 0; i < enemyParty.Count; i++)
        {
            enemyUnitList[i].InitUnit(enemyParty[i]);
        }
        for (int i = enemyParty.Count; i < 4; i++)
        {
            enemyUnitList[i].ClearCurrentCharacter();
            enemyUnitGameObjectList[i].SetActive(false);
        }
    }

    public IEnumerator ReciveDamageAnim(BattleUnit sourceUnit,BattleUnit targetUnit)
    {
        if (sourceUnit.IsPlayerUnit)
        {
            ShowPlayerAttackEnemyDefenseAnim(sourceUnit, targetUnit);
            yield return new WaitForSeconds(1f);
            HideBattleAnim();
        }
        else
        {
            ShowEnemyAttackPlayerDefenseAnim(sourceUnit, targetUnit);
            yield return new WaitForSeconds(1f);
            HideBattleAnim();
        }
    }
    public void ShowPlayerAttackEnemyDefenseAnim(BattleUnit sourceUnit,BattleUnit targetUnit)
    {
        playerBattleAnimGameObject.SetActive(true);
        enemyBattleAnimGameObject.SetActive(true);
        playerBattleAnimGameObject.GetComponent<SpriteRenderer>().sprite = sourceUnit.UnitCharacter.CharacterBase.AttackSprite;
        enemyBattleAnimGameObject.GetComponent<SpriteRenderer>().sprite = targetUnit.UnitCharacter.CharacterBase.DamagedSprite;
    }
    public void ShowEnemyAttackPlayerDefenseAnim(BattleUnit sourceUnit,BattleUnit targetUnit)
    {
        playerBattleAnimGameObject.SetActive(true);
        enemyBattleAnimGameObject.SetActive(true);
        playerBattleAnimGameObject.GetComponent<SpriteRenderer>().sprite = sourceUnit.UnitCharacter.CharacterBase.DamagedSprite;
        enemyBattleAnimGameObject.GetComponent<SpriteRenderer>().sprite = targetUnit.UnitCharacter.CharacterBase.AttackSprite;
    }
    public void HideBattleAnim()
    {
        playerBattleAnimGameObject.GetComponent<SpriteRenderer>().sprite = null;
        enemyBattleAnimGameObject.GetComponent<SpriteRenderer>().sprite = null;
        playerBattleAnimGameObject.SetActive(false);
        enemyBattleAnimGameObject.SetActive(false);
    }

    public void ClearAllMark()
    {
        foreach(var i in playerUnitList)
        {
            i.HideCurrentMark();
        }
        foreach(var i in enemyUnitList)
        {
            i.HideCurrentMark();
        }
    }

    public void JudgeAttackOrder()
    {
        attackOrderList = new List<AttackOrder>();
        battleState = BattleState.Busy;
        foreach(var i in playerUnitList)
        {
            if(i.isActive)
            {
                attackOrderList.Add(new AttackOrder(i,1));
            }

        }
        foreach(var i in enemyUnitList)
        {
            if (i.isActive)
            {
                attackOrderList.Add(new AttackOrder(i,1));
            }

        }



        attackOrderList.Sort((x1, x2) => (x1.BattleUnit.UnitCharacter.HeroSpeed.CompareTo(x2.BattleUnit.UnitCharacter.HeroSpeed)));//排序出手顺序


    }

}

public class AttackOrder
{
    BattleUnit battleUnit;
    int times;

    public AttackOrder(BattleUnit currentBattleUnit,int currentTimes)
    {
        this.battleUnit = currentBattleUnit;
        this.times = currentTimes;
    }

    public BattleUnit BattleUnit => battleUnit;
    public int AttackTimes => times;
}
