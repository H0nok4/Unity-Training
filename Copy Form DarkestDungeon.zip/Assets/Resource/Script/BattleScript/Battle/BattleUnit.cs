﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class BattleUnit : MonoBehaviour
{
    Character _battleUnitCharacter = null;
    Animator _battleUnitAnimator;
    SpriteRenderer battleSpriteRender;
    [SerializeField] bool isPlayerUnit;
    [SerializeField] Slider HPslider;

    //[SerializeField] int unitPosition;


    Vector3 originPosition;
    [SerializeField] Image currentHeroMark;

    [SerializeField] Color notCurrentHeroColor;
    [SerializeField] Color currentHeroColor;
    [SerializeField] Color canHitEnemyColor;
    [SerializeField] Color cantHitEnemyColor;
    [SerializeField] Color allyColor;
    public bool isActive = false;
    public Character UnitCharacter => _battleUnitCharacter;
    //public int UnitPosition => unitPosition;
    public bool IsPlayerUnit => isPlayerUnit;
    private void Awake()
    {
        battleSpriteRender = GetComponent<SpriteRenderer>();
    }
    public void InitUnit(Character PlayerCharacter)
    {
        
        this._battleUnitCharacter = PlayerCharacter;
        //this._battleUnitAnimator = PlayerCharacter.CharacterBase.CharacterAnimator;
        battleSpriteRender.sprite = _battleUnitCharacter.CharacterBase.IdleSprite;
        HPslider.maxValue = _battleUnitCharacter.HeroMaxHealth;
        HPslider.minValue = 0;
        HPslider.value = _battleUnitCharacter.HeroCurrentHP;
        currentHeroMark.color = notCurrentHeroColor;
        isActive = true;
    }

    public void SetCurrentHero()
    {
        currentHeroMark.color = currentHeroColor;
    }
    public void SetHitableEnemy(bool ToF)
    {
        if (ToF == true)
        {
            currentHeroMark.color = canHitEnemyColor;
        }
        else
        {
            currentHeroMark.color = cantHitEnemyColor;
        }

    }

    public void HideCurrentMark()
    {
        currentHeroMark.color = new Color(0,0,0,0);
    }

    public int ReciveDamage(int damage,Skill skill)
    {
        var currentHP = _battleUnitCharacter.ReciveDamage(damage, skill);
        UpdateHPSlider();
        return currentHP;
    }

    public void ClearCurrentCharacter()
    {
        this._battleUnitCharacter = null;
        //this._battleUnitAnimator = PlayerCharacter.CharacterBase.CharacterAnimator;
        battleSpriteRender.sprite = null;
        HPslider.maxValue = 0;
        HPslider.minValue = 0;
        HPslider.value = 0;
        currentHeroMark.color = notCurrentHeroColor;
        isActive = false;
    }

    public void UpdateHPSlider()
    {
        HPslider.value = _battleUnitCharacter.HeroCurrentHP;
    }

    public Skill GetRandomSkill()
    {
        int index = Random.Range(0, _battleUnitCharacter.ValidSkill.Count);
        return _battleUnitCharacter.ValidSkill[index];
    }

    public void UnitDead()
    {
        _battleUnitCharacter = null;
        
    }

}
