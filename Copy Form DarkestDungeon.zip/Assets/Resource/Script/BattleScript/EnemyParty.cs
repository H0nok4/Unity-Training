﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class EnemyParty
{
    [SerializeField] List<Character> enemyParty;
    public List<Character> TheEnemyParty => enemyParty;
    
}
