﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapEnemyParty : MonoBehaviour
{
    [SerializeField] List<EnemyParty> enemyPartys;
    public List<EnemyParty> EnemyPartys => enemyPartys;

    public EnemyParty GetRandomEnemyParty()
    {
        int resultEnemyParty = Random.Range(0, enemyPartys.Count);
        return enemyPartys[resultEnemyParty];
    }

    private void Awake()
    {
        foreach(var i in enemyPartys)
        {
            foreach(var enemy in i.TheEnemyParty)
            {
                enemy.InitHero();
            }
        }
    }
}
