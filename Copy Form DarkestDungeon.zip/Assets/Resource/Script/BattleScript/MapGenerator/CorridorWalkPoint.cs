﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CorridorWalkPoint
{
    public RoomStyle roomStyle;
    EnemyParty enemyParty;

    public EnemyParty EnemyParty => enemyParty;
    
}
