﻿using UnityEngine;
using TMPro;

public enum CorridorDirection
{
    up,
    down,
    left,
    right
}
[System.Serializable]
public class Corridors 
{
    [SerializeField] int startPointX;
    [SerializeField] int startPointY;
    [SerializeField] int corridorLength;
    [SerializeField] CorridorDirection corridorDirection;
    [SerializeField] DungeonRoom startRoom;
    [SerializeField] DungeonRoom endRoom;
    [SerializeField] GameObject thisCorridor;
    [SerializeField] CorridorWalkPoint[] walkPoints;
    [SerializeField] GameObject[] walkPointGameObjects;

    public CorridorDirection CorridorDirection => corridorDirection;
    public DungeonRoom StartRoom
    {
        get { return startRoom; }
        set { startRoom = value; }
    }
    public DungeonRoom EndRoom
    {
        get { return endRoom; }
        set { endRoom = value; }
    }

    public GameObject ThisCorridor => thisCorridor;

    public int CorridorLength => corridorLength;
    
    public int EndPointX
    {
        get
        {
            if (corridorDirection == CorridorDirection.up || corridorDirection == CorridorDirection.down)
                return startPointX;
            else if (corridorDirection == CorridorDirection.left)
                return startPointX + corridorLength - 20;
            else
                return startPointX - corridorLength + 20;
        }

    }

    public int EndPointY
    {
        get
        {
            if (corridorDirection == CorridorDirection.left || corridorDirection == CorridorDirection.right)
                return startPointY;
            else if (corridorDirection == CorridorDirection.up)
                return startPointY + corridorLength - 20;
            else
                return startPointY - corridorLength + 20;
        }
    }

    public void SetUpCorridor(GameObject corridorGameObject,DungeonRoom room,int Length,GameObject mapObject,GameObject[] walkPointGameObject)
    {
        //走廊位置
        corridorDirection = (CorridorDirection)Random.Range(0, 4);

        corridorLength = Length;

        thisCorridor = corridorGameObject;
        thisCorridor.transform.SetParent(mapObject.transform);
        thisCorridor.transform.localScale = new Vector3(1, 1, 1);

        walkPointGameObjects = walkPointGameObject;

        switch (corridorDirection)
        {
            case CorridorDirection.up:
                thisCorridor.transform.localPosition = new Vector3(room.ThisRoom.transform.localPosition.x, room.ThisRoom.transform.localPosition.y + 40 + ((corridorLength * 20) / 2), room.ThisRoom.transform.localPosition.z);
                break;
            case CorridorDirection.right:
                thisCorridor.transform.localPosition = new Vector3(room.ThisRoom.transform.localPosition.x + 40 + ((corridorLength * 20) / 2), room.ThisRoom.transform.localPosition.y, room.ThisRoom.transform.localPosition.z);
                break;
            case CorridorDirection.down:
                thisCorridor.transform.localPosition = new Vector3(room.ThisRoom.transform.localPosition.x, room.ThisRoom.transform.localPosition.y - 40 - ((corridorLength * 20) / 2), room.ThisRoom.transform.localPosition.z);
                break;
            case CorridorDirection.left:
                thisCorridor.transform.localPosition = new Vector3(room.ThisRoom.transform.localPosition.x - 40 - ((corridorLength * 20) / 2), room.ThisRoom.transform.localPosition.y, room.ThisRoom.transform.localPosition.z);
                break;
        }

        SetUpWalkPoint(walkPointGameObject, corridorLength, CorridorDirection);
    }

    public void SetUpWalkPoint(GameObject[] walkPointGameObject,int corridorLength,CorridorDirection corridorDirection)
    {
        //走廊路径点位置的调整
        if(corridorLength % 2 == 0)
        {
            walkPointGameObject[0].transform.SetParent(thisCorridor.transform);
            walkPointGameObject[0].transform.localScale = new Vector3(1, 1, 1);
            if(corridorDirection == CorridorDirection.down || corridorDirection == CorridorDirection.up)
            {
                walkPointGameObject[0].transform.localPosition = new Vector3(0, 0 - ((((corridorLength / 2) - 1) * 20) + 10), 0);
                for (int i = 1; i < corridorLength; i++)
                {
                    walkPointGameObject[i].transform.SetParent(thisCorridor.transform);
                    walkPointGameObject[i].transform.localScale = new Vector3(1, 1, 1);
                    walkPointGameObject[i].transform.localPosition = new Vector3(0, walkPointGameObject[i - 1].transform.localPosition.y + 20, 0);
                }
            }
            else
            {
                walkPointGameObject[0].transform.localPosition = new Vector3(0 - ((((corridorLength / 2) - 1) * 20) + 10), 0, 0);
                for (int i = 1; i < corridorLength; i++)
                {
                    walkPointGameObject[i].transform.SetParent(thisCorridor.transform);
                    walkPointGameObject[i].transform.localScale = new Vector3(1, 1, 1);
                    walkPointGameObject[i].transform.localPosition = new Vector3(walkPointGameObject[i - 1].transform.localPosition.x + 20,0, 0);
                }
            }


        }
        else
        {
            walkPointGameObject[0].transform.SetParent(thisCorridor.transform);
            walkPointGameObject[0].transform.localScale = new Vector3(1, 1, 1);
            if (corridorDirection == CorridorDirection.down || corridorDirection == CorridorDirection.up)
            {
                walkPointGameObject[0].transform.localPosition = new Vector3(0,0 - (((corridorLength / 2) * 20)),0);
                for (int i = 1; i < corridorLength; i++)
                {
                    walkPointGameObject[i].transform.parent = thisCorridor.transform;
                    walkPointGameObject[i].transform.localScale = new Vector3(1, 1, 1);
                    walkPointGameObject[i].transform.localPosition = new Vector3(0, walkPointGameObject[i - 1].transform.localPosition.y + 20, 0);
                }
            }
            else
            {
                walkPointGameObject[0].transform.localPosition = new Vector3(0 - (((corridorLength / 2) * 20)), 0, 0);
                for (int i = 1; i < corridorLength; i++)
                {
                    walkPointGameObject[i].transform.SetParent(thisCorridor.transform);
                    walkPointGameObject[i].transform.localScale = new Vector3(1, 1, 1);
                    walkPointGameObject[i].transform.localPosition = new Vector3(walkPointGameObject[i - 1].transform.localPosition.x + 20, 0, 0);
                }
            }

        }



    }
}
