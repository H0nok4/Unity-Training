﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum RoomStyle
{
    Empty,
    Enemy,
    Treasure,
    EnemyWhitTreasure
}
[System.Serializable]
public class DungeonRoom
{
    [SerializeField] EnemyParty enemyParty;

    [SerializeField] RoomStyle roomStyle;

    [SerializeField] Sprite roomBackground;

    [SerializeField] DungeonRoom leftRoom;
    [SerializeField] DungeonRoom upRoom;
    [SerializeField] DungeonRoom rightRoom;
    [SerializeField] DungeonRoom downRoom;

    [SerializeField] GameObject thisRoom;

    public GameObject ThisRoom => thisRoom;
    public RoomStyle RoomStyle => roomStyle;
    public void GetEnemyParty(EnemyParty enemyParty)
    {
        this.enemyParty = enemyParty;
    }

    public void GetRandomTreasure()
    {
        //TO DO 掉落物
    }

    public EnemyParty WhenPlayerEnterBattleRoom()
    {
        return this.enemyParty;
    }

    public void SetUpDungeonRoom(GameObject roomGameObject,GameObject mapObject,int pointX,int pointY,int index)
    {
        thisRoom = roomGameObject;
        thisRoom.transform.SetParent(mapObject.transform);
        thisRoom.transform.localPosition = new Vector3(pointX, pointY, 0);
        thisRoom.transform.localScale = new Vector3(1, 1, 1);
    }

    public bool SetUpDungeonRoom(GameObject roomGameObject,GameObject mapObject,Corridors prvCorridor)
    {
        thisRoom = roomGameObject;
        thisRoom.transform.SetParent(mapObject.transform);
        thisRoom.transform.localScale = new Vector3(1, 1, 1);
        if(prvCorridor.CorridorLength % 2 == 0)
        {
            switch (prvCorridor.CorridorDirection)
            {
                case CorridorDirection.up:
                    thisRoom.transform.localPosition = new Vector3(prvCorridor.ThisCorridor.transform.localPosition.x, prvCorridor.ThisCorridor.transform.localPosition.y + 40 + ((prvCorridor.CorridorLength / 2) * 20), prvCorridor.ThisCorridor.transform.localPosition.z);
                    break;
                case CorridorDirection.down:
                    thisRoom.transform.localPosition = new Vector3(prvCorridor.ThisCorridor.transform.localPosition.x, prvCorridor.ThisCorridor.transform.localPosition.y - 40 - ((prvCorridor.CorridorLength / 2) * 20), prvCorridor.ThisCorridor.transform.localPosition.z);
                    break;
                case CorridorDirection.left:
                    thisRoom.transform.localPosition = new Vector3(prvCorridor.ThisCorridor.transform.localPosition.x - 40 - ((prvCorridor.CorridorLength / 2) * 20), prvCorridor.ThisCorridor.transform.localPosition.y, prvCorridor.ThisCorridor.transform.localPosition.z);
                    break;
                case CorridorDirection.right:
                    thisRoom.transform.localPosition = new Vector3(prvCorridor.ThisCorridor.transform.localPosition.x + 40 + ((prvCorridor.CorridorLength / 2) * 20), prvCorridor.ThisCorridor.transform.localPosition.y, prvCorridor.ThisCorridor.transform.localPosition.z);
                    break;
            }
        }
        else
        {
            switch (prvCorridor.CorridorDirection)
            {
                case CorridorDirection.up:
                    thisRoom.transform.localPosition = new Vector3(prvCorridor.ThisCorridor.transform.localPosition.x, prvCorridor.ThisCorridor.transform.localPosition.y + 50 + ((prvCorridor.CorridorLength / 2) * 20), prvCorridor.ThisCorridor.transform.localPosition.z);
                    break;
                case CorridorDirection.down:
                    thisRoom.transform.localPosition = new Vector3(prvCorridor.ThisCorridor.transform.localPosition.x, prvCorridor.ThisCorridor.transform.localPosition.y - 50 - ((prvCorridor.CorridorLength / 2) * 20), prvCorridor.ThisCorridor.transform.localPosition.z);
                    break;
                case CorridorDirection.left:
                    thisRoom.transform.localPosition = new Vector3(prvCorridor.ThisCorridor.transform.localPosition.x - 50 - ((prvCorridor.CorridorLength / 2) * 20), prvCorridor.ThisCorridor.transform.localPosition.y, prvCorridor.ThisCorridor.transform.localPosition.z);
                    break;
                case CorridorDirection.right:
                    thisRoom.transform.localPosition = new Vector3(prvCorridor.ThisCorridor.transform.localPosition.x + 50 + ((prvCorridor.CorridorLength / 2) * 20), prvCorridor.ThisCorridor.transform.localPosition.y, prvCorridor.ThisCorridor.transform.localPosition.z);
                    break;
            }
        }


        var cols = Physics.OverlapBox(thisRoom.transform.localPosition,new Vector3(thisRoom.GetComponent<RectTransform>().sizeDelta.x, thisRoom.GetComponent<RectTransform>().sizeDelta.y));
        foreach(var col in cols)
        {
            if (col.gameObject.CompareTag("Room"))
            {
                return false;
            }
        }

        return true;

    }

    
}
