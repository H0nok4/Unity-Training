﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class IntRange
{
    [SerializeField] int m_min;
    [SerializeField] int m_max;

    public int Min => m_min;
    public int Max => m_max;

    public IntRange(int min,int max)
    {
        m_min = min;
        m_max = max;
    }

    public int GetRandomNumber
    {
        get
        {
            return Random.Range(m_min, m_max);
        }
    }
}
