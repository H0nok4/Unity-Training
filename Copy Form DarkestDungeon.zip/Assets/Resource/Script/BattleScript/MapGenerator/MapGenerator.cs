﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapGenerator : MonoBehaviour
{
    [SerializeField] IntRange numRooms = new IntRange(7, 10);
    [SerializeField] IntRange corridorLenght = new IntRange(4,4);

    [SerializeField] List<DungeonRoom> dungeonRooms;
    [SerializeField] List<Corridors> corridors;

    [SerializeField] GameObject mapObject;
    [SerializeField] GameObject roomGameObject;
    [SerializeField] GameObject corridorGameObject;
    [SerializeField] GameObject walkPointGameObject;

    public void Start()
    {
        CreateRoomAndCorridors();
    }

    public void CreateRoomAndCorridors()
    {

        dungeonRooms = new List<DungeonRoom>();
        corridors = new List<Corridors>();

        int dungeonRoomsCount = numRooms.GetRandomNumber;

        dungeonRooms.Add(new DungeonRoom());
        corridors.Add(new Corridors());

        //初始点的设置 ↓
        GameObject m_roomGameObject = Instantiate(roomGameObject);
        dungeonRooms[0].SetUpDungeonRoom(m_roomGameObject,mapObject,0,0,0);
        GameObject m_corridorGameObject = Instantiate(corridorGameObject);
        int m_corridorLength = corridorLenght.GetRandomNumber;
        GameObject[] walkPoints = CreatWalkPoints(m_corridorLength);
        corridors[0].SetUpCorridor(m_corridorGameObject,dungeonRooms[0],m_corridorLength, mapObject,walkPoints);
        corridors[0].StartRoom = dungeonRooms[0];

        int corridorsIndex = 0;

        //后续生成 ↓
        while(dungeonRooms.Count < dungeonRoomsCount)
        {
            DungeonRoom newDungeomRoom = new DungeonRoom();
            GameObject m_newDungeomRoomGameObject = Instantiate(roomGameObject);
            Corridors prvCorridor = corridors[corridorsIndex];
            corridorsIndex = corridors.Count - 1;
            newDungeomRoom.SetUpDungeonRoom(m_newDungeomRoomGameObject, mapObject, prvCorridor);
            bool isCreated = IsRoomOverlap(m_newDungeomRoomGameObject);
            //检测是否成功生成房间（不重叠）
            if (isCreated)
            {
                //如果成功生成房间，生成后续走廊
                dungeonRooms.Add(newDungeomRoom);
                prvCorridor.EndRoom = newDungeomRoom;
                Corridors newCorridor = new Corridors();
                GameObject newCorridorGameObject = Instantiate(corridorGameObject);
                int corridorsLength = corridorLenght.GetRandomNumber;
                GameObject[] newWalkPoints = CreatWalkPoints(corridorsLength);
                newCorridor.SetUpCorridor(newCorridorGameObject, newDungeomRoom, corridorsLength, mapObject, newWalkPoints);
                newCorridor.StartRoom = newDungeomRoom;
                corridors.Add(newCorridor);
            }
            else
            {
                DungeonRoom overlapDungeonRoom = FindRoomOverlap(newDungeomRoom.ThisRoom);
                prvCorridor.EndRoom = overlapDungeonRoom;
                //房间重叠 先生成一条通向其他方向的走廊，然后删除房间
                Corridors newCorridor = new Corridors();
                GameObject newCorridorGameObject = Instantiate(corridorGameObject);
                int corridorsLength = corridorLenght.GetRandomNumber;
                GameObject[] newWalkPoints = CreatWalkPoints(corridorsLength);
                newCorridor.SetUpCorridor(newCorridorGameObject, newDungeomRoom, corridorsLength, mapObject, newWalkPoints);
                Debug.Log("false");
                bool isCorridorOverlap = IsCorridorOverlap(newCorridorGameObject);
                if (isCorridorOverlap)
                {
                    Destroy(newCorridorGameObject);
                    Debug.Log("delet corridorOverlap");
                }
                else
                {
                    newCorridor.StartRoom = overlapDungeonRoom;
                    corridors.Add(newCorridor);
                }

                Destroy(m_newDungeomRoomGameObject);
            }

            
        }

        DeletAllOverlapCorridor();
        DeleteRedundantCorridor();
        Debug.Log($"{corridors.Count.ToString()}");
        Debug.Log($"{dungeonRooms.Count.ToString()}");
    }

    public GameObject[] CreatWalkPoints(int length)
    {
        GameObject[] walkPoints = new GameObject[length];
        for(int i = 0; i < length; i++)
        {
            walkPoints[i] = Instantiate(walkPointGameObject);
        }
        return walkPoints;
    }

    public bool IsRoomOverlap(GameObject dungeonRoom)
    {
        foreach(var room in dungeonRooms)
        {
            if(System.Math.Abs(dungeonRoom.transform.localPosition.x - room.ThisRoom.transform.localPosition.x) < 80 &&System.Math.Abs(dungeonRoom.transform.localPosition.y - room.ThisRoom.transform.localPosition.y) < 80)
            {
                return false;
            }
        }
        return true; ;
    }

    public bool IsCorridorOverlap(GameObject corridor)
    {
        foreach (var cor in corridors)
        {
            if (System.Math.Abs(corridor.transform.localPosition.x - cor.ThisCorridor.transform.localPosition.x) < 5 && System.Math.Abs(corridor.transform.localPosition.y - cor.ThisCorridor.transform.localPosition.y) < 5  && corridor != cor.ThisCorridor)
            {
                return true;
            }
        }
        return false;
    }

    public Corridors FindOverlapCorridor(GameObject corridor)
    {
        Debug.Log("Start Find");
        foreach (var cor in corridors)
        {
            if (System.Math.Abs(corridor.transform.localPosition.x - cor.ThisCorridor.transform.localPosition.x) < 10 && System.Math.Abs(corridor.transform.localPosition.y - cor.ThisCorridor.transform.localPosition.y) < 10 && corridor != cor.ThisCorridor)
            {
                return cor;
            }
        }

        return new Corridors();
    }

    public void DeletAllOverlapCorridor()
    {
        for(int i = 0; i < corridors.Count; i++)
        {
            bool isOverlap = IsCorridorOverlap(corridors[i].ThisCorridor);

            if (isOverlap)
            {
                Debug.Log("!!!");
                Corridors overCorridor = FindOverlapCorridor(corridors[i].ThisCorridor);
                if(overCorridor.ThisCorridor != null)
                {
                    Destroy(overCorridor.ThisCorridor);
                }
                corridors.Remove(overCorridor);
                i--;
            }
        }
    }

    public void DeleteRedundantCorridor()
    {
        for(int i = 0; i < corridors.Count; i++)
        {
            if(corridors[i].StartRoom == null || corridors[i].EndRoom == null)
            {
                Debug.Log("Redundant Delete");
                Destroy(corridors[i].ThisCorridor);
                corridors.RemoveAt(i);
                i--;
            }
        }
    }

    public DungeonRoom FindRoomOverlap(GameObject dungeonRoom)
    {
        DungeonRoom overlapRoom = new DungeonRoom();
        foreach (var room in dungeonRooms)
        {
            if (System.Math.Abs(dungeonRoom.transform.localPosition.x - room.ThisRoom.transform.localPosition.x) < 80 && System.Math.Abs(dungeonRoom.transform.localPosition.y - room.ThisRoom.transform.localPosition.y) < 80)
            {
                overlapRoom = room;
            }
        }
        return overlapRoom;
    }

}
