﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerParty : MonoBehaviour
{
    public List<Character> playerParty;
    private void Awake()
    {
        foreach(var playerCharacter in playerParty)
        {
            if(playerCharacter.CharacterBase != null)
                playerCharacter.InitHero();
        }
    }

}
