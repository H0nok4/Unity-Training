﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class SkillButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    public Image skillImage;
    [SerializeField] Skill currentSkill;
    [SerializeField] SkillDescribeTip skillDescribeTip;
    [SerializeField] BattleManager battleManager;
    private Vector2 position;
    [SerializeField] Camera battleCamera;
    private void Awake()
    {
        skillImage = GetComponent<Image>();
    }
    public void OnPointerEnter(PointerEventData eventData)
    {
        if(currentSkill.SkillBase != null)
        {
            skillDescribeTip.ShowSkillToolTip(true);
            skillDescribeTip.UpdateSkillDescribe(currentSkill.SkillBase.SkillName, currentSkill.SkillBase.SkillDescribe);

            RectTransformUtility.ScreenPointToLocalPointInRectangle(GameObject.Find("Skill").transform as RectTransform, Input.mousePosition,battleCamera, out position);
            skillDescribeTip.SetPosition(position);
        }

    }

    public void OnPointerExit(PointerEventData eventData)
    {
        skillDescribeTip.ShowSkillToolTip(false);
        skillDescribeTip.UpdateSkillDescribe("","");
    }
    
    public void UpdateSkill(Skill skill)
    {
        this.currentSkill = skill;
        this.skillImage.sprite = skill.SkillBase.SkillSprite;

    }

    public void OnPointerClick(PointerEventData eventData)
    {
        //技能可以使用的三个条件，1，目前是选择行动状态。2，该按钮所挂载的技能不为空。3，该挂载的技能的Unit所处的位置为可以释放的位置
        if (battleManager.BattleState == BattleState.PlayerActionSelection 
            && currentSkill.SkillBase != null 
            && currentSkill.SkillBase.SkillTargetPosition.CanUsePos[battleManager.BattleUnitPosition(battleManager.CurrentUnit)] == true)
        {
            battleManager.PlyaerSelectedSkill(currentSkill);//进入选择技能目标
        }
    }
}
