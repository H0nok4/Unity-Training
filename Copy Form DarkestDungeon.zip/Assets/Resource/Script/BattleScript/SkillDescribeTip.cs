﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SkillDescribeTip : MonoBehaviour
{
    [SerializeField] TMP_Text skillName;
    [SerializeField] TMP_Text skillDescribe;
    
    public void ShowSkillToolTip(bool show)
    {
        gameObject.SetActive(show);
    }
    public void UpdateSkillDescribe(string SkillName,string SkillDescribe)
    {
        skillName.text = SkillName;
        skillDescribe.text = SkillDescribe;
    }

    public void SetPosition(Vector2 pos)
    {
        this.transform.localPosition = pos;
    }
}
