﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ExitButton : MonoBehaviour , IPointerClickHandler
{
    [SerializeField] GameObject exitPage;
    public void OnPointerClick(PointerEventData eventData)
    {
        exitPage.SetActive(false);
    }
    
}
