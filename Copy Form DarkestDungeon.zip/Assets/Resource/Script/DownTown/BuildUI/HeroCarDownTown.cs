﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class HeroCarDownTown : MonoBehaviour, IPointerEnterHandler,IPointerClickHandler,IPointerExitHandler
{
    [SerializeField] Image heroCarImage;
    [SerializeField] GameObject heroCarUI;
    public void OnPointerClick(PointerEventData eventData)
    {
        //TO DO : 打开英雄马车的UI界面
        heroCarUI.SetActive(true);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        //TO DO ： 将马车的Sprite替换成激活状态
        heroCarImage.color = Color.blue;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        //TO DO : 将马车的Sprite替换成不激活状态
        heroCarImage.color = Color.white;
    }

}
