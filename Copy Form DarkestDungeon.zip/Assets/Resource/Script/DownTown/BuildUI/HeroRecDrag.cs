﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class HeroRecDrag : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [SerializeField] RectTransform rectTransform;
    Vector3 startPos;
    private void Start()
    {
        rectTransform = GetComponent<RectTransform>();
    }
    public void OnBeginDrag(PointerEventData eventData)
    {
        //保存开始的坐标
        startPos = rectTransform.position;


        Debug.Log("Begin Drag!");
    }

    //TO DO 拖拽招募功能
    public void OnDrag(PointerEventData eventData)
    {
        //TO DO 移动拖拽的HeroNode
        Vector3 pos;
        RectTransformUtility.ScreenPointToWorldPointInRectangle(rectTransform,eventData.position,eventData.enterEventCamera,out pos);
        rectTransform.position = pos;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        //TO DO 如果放开的位置上是HeroList，那么就删除这个节点，并在GameManager中注册这个Hero
        List<RaycastResult> list = new List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData,list);
        foreach(var rr in list)
        {
            if(rr.gameObject.GetComponent<HeroListUI>() != null)
            {
                GameManager.instance.AddHero(gameObject.GetComponent<HeroRecruitNode>().Hero);
                Destroy(gameObject);
                return;
            }
        }


        


        rectTransform.position = startPos;


    }
}
