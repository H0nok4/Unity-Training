﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class HeroRecruitNode : MonoBehaviour
{
    [SerializeField] Character hero;

    [SerializeField] Image heroImage;
    [SerializeField] TMP_Text heroName;
    [SerializeField] TMP_Text heroClass;

    public Character Hero => hero;
    public void InitHero(Character hero)
    {
        this.hero = hero;

        heroImage.sprite = hero.CharacterBase.HeadSprite;
        heroName.text = hero.HeroName;
        heroClass.text = hero.CharacterBase.CharacterClass.ToString();
    }
} 
