﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HeroDetailUI : MonoBehaviour
{
    [SerializeField] Character hero;
    [SerializeField] TMP_Text heroNameText;
    [SerializeField] TMP_Text heroClassText;
    [SerializeField] TMP_Text maxHealthText;
    [SerializeField] TMP_Text avoidText;
    [SerializeField] TMP_Text defenseText;
    [SerializeField] TMP_Text speedText;
    [SerializeField] TMP_Text accCorrectText;
    [SerializeField] TMP_Text critChanceText;
    [SerializeField] TMP_Text damageText;

    public void InitUI(Character _hero)
    {
        heroNameText.text = _hero.HeroName;
        heroClassText.text = _hero.CharacterBase.CharacterClass.ToString();
        maxHealthText.text = _hero.HeroMaxHealth.ToString();
        avoidText.text = _hero.HeroAvoid.ToString();
        defenseText.text = _hero.HeroDefense.ToString()+"%";
        speedText.text = _hero.HeroSpeed.ToString();
        accCorrectText.text = _hero.HeroAccracyCorrect.ToString();
        critChanceText.text = _hero.HeroCriticalChance.ToString() + "%";
        damageText.text = _hero.HeroMinAttack.ToString() + "-" + _hero.HeroMaxAttack.ToString();
    }
}
