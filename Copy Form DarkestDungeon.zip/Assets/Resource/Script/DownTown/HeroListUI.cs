﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroListUI : MonoBehaviour
{
    [SerializeField] GameObject heroNodeObject;
    [SerializeField] GameObject heroListObject;
    [SerializeField] List<GameObject> heroNodeGameobjectList = new List<GameObject>();

    private void Start()
    {
        UpdateHeroList();
    }

    public void UpdateHeroList()
    {
        foreach(var heroNode in heroNodeGameobjectList)
        {
            Destroy(heroNode);
        }
        heroNodeGameobjectList.Clear();
        foreach (Character playerHero in GameManager.instance.PlayerAllHeroList)
        {
            var curHeroNodeObject = Instantiate(heroNodeObject,heroListObject.transform);
            heroNodeGameobjectList.Add(curHeroNodeObject);
            curHeroNodeObject.transform.SetParent(heroListObject.transform);
            curHeroNodeObject.transform.localScale = new Vector3(1, 1, 1);
            curHeroNodeObject.GetComponent<HeroNode>().InitHero(playerHero);
        }
    }
}
