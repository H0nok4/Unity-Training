﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class HeroNode : MonoBehaviour, IPointerClickHandler,IBeginDragHandler,IDragHandler,IEndDragHandler
{
    [SerializeField] Character hero;
    [SerializeField] Image heroImage;
    [SerializeField] TMP_Text heroName;
    [SerializeField] Image levelImage;
    [SerializeField] GameObject tempHeroImagePrefebs;
    GameObject tempHeroImageObject;
    
    public HeroNode(Character hero)
    {
        this.hero = hero;
        heroImage.sprite = hero.CharacterBase.HeadSprite;
        heroName.text = hero.HeroName;
    }

    public void InitHero(Character hero)
    {
        this.hero = hero;
        heroImage.sprite = hero.CharacterBase.HeadSprite;
        heroName.text = hero.HeroName;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        //TO DO:开始拖拽英雄
        tempHeroImageObject = Instantiate(tempHeroImagePrefebs);
        tempHeroImageObject.transform.SetParent(GameObject.FindGameObjectWithTag("Canvas").transform);
        tempHeroImageObject.transform.localScale = new Vector3(1, 1, 1);
        

    }

    public void OnDrag(PointerEventData eventData)
    {
        //TO DO:
        Vector3 pos;
        RectTransformUtility.ScreenPointToWorldPointInRectangle(tempHeroImageObject.GetComponent<RectTransform>(), eventData.position, Camera.main, out pos);
        tempHeroImageObject.transform.position = pos;
    }

    public void OnEndDrag(PointerEventData eventData)
    {

        List<RaycastResult> list = new List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData, list);
        foreach (var rr in list)
        {
            if (rr.gameObject.GetComponent<PlayerBattlePartySlot>() != null && rr.gameObject.GetComponent<PlayerBattlePartySlot>().Hero.CharacterBase == null)
            {
                rr.gameObject.GetComponent<PlayerBattlePartySlot>().InitHero(this.hero);
            }
        }


        Destroy(tempHeroImageObject);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if(eventData.button == PointerEventData.InputButton.Right)
        {
            //TO DO 打开英雄的详情页面
            GameManager.instance.HeroDetailUI.SetActive(true);
            GameManager.instance.HeroDetailUI.GetComponent<HeroDetailUI>().InitUI(hero);
        }
    }
}
