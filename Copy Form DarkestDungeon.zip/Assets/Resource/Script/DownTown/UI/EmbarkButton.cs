﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public class EmbarkButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    [SerializeField] TMP_Text embarkText;
    public void OnPointerClick(PointerEventData eventData)
    {
        //TO DO ;Start Embark Menu
        GameManager.instance.SwitchPage(true);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        embarkText.color = Color.yellow;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        embarkText.color = Color.white;
    }
}
