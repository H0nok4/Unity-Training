﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class PlayerBattlePartySlot : MonoBehaviour, IBeginDragHandler, IEndDragHandler,IDragHandler
{

    [SerializeField] Image heroImage;
    [SerializeField] Character hero;
    RectTransform rectTransform;
    Vector3 startPos;
    [SerializeField] PlayerBattlePartyUI playerBattlePartyUI;

    private void Start()
    {
        heroImage = GetComponent<Image>();
        rectTransform = GetComponent<RectTransform>();
    }

    public Character Hero => hero;

    public void OnBeginDrag(PointerEventData eventData)
    {
        startPos = rectTransform.position;
    }

    public void OnDrag(PointerEventData eventData)
    {
        if(hero.CharacterBase != null)
        {
            Debug.Log("Start Drag");
            Vector3 currenPos;
            RectTransformUtility.ScreenPointToWorldPointInRectangle(rectTransform, eventData.position, Camera.main, out currenPos);
            rectTransform.position = currenPos;
        }

    }

    public void OnEndDrag(PointerEventData eventData)
    {
        if (hero.CharacterBase != null)
        {
            Debug.Log("End Drag");
            List<RaycastResult> list = new List<RaycastResult>();
            EventSystem.current.RaycastAll(eventData, list);
            foreach (var rr in list)
            {
                if (rr.gameObject.GetComponent<PlayerBattlePartySlot>() != null)
                {
                    Debug.Log("Find Slot");
                    if (rr.gameObject.GetComponent<PlayerBattlePartySlot>() != null && rr.gameObject.GetComponent<PlayerBattlePartySlot>().Hero.CharacterBase != null && rr.gameObject != this.gameObject)
                    {
                        Debug.Log("Slot not null");
                        rectTransform.position = startPos;
                        return;
                    }
                    else if (rr.gameObject.GetComponent<PlayerBattlePartySlot>() != null && rr.gameObject.GetComponent<PlayerBattlePartySlot>().Hero.CharacterBase == null && rr.gameObject != this.gameObject)
                    {
                        Debug.Log("Slot null");
                        rr.gameObject.GetComponent<PlayerBattlePartySlot>().InitHero(hero);
                        ClearThisHero();
                        rectTransform.position = startPos;
                        return;
                    }
                }
            }





            rectTransform.position = startPos;
            ClearThisHero();
        }
       
    }

    public void ClearThisHero()
    {
        this.hero = new Character(null,0);
        this.heroImage.sprite = null;
    }

    public void InitHero(Character hero)
    {
        playerBattlePartyUI.CheckReapetCharacter(hero, this);
        this.hero = hero;
        heroImage.sprite = hero.CharacterBase.HeadSprite;
    }
}
