﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class PlayerBattlePartyUI : MonoBehaviour
{
    [SerializeField] PlayerBattlePartySlot[] playerBattlePartySlots = new PlayerBattlePartySlot[4];
    
    public void CheckReapetCharacter(Character hero,PlayerBattlePartySlot checkSlot)
    {
        foreach(var pBPS in playerBattlePartySlots)
        {
            if(pBPS.Hero == hero && pBPS != checkSlot)
            {
                pBPS.ClearThisHero();
            }
        }
    }
}
