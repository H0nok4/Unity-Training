﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class Area : MonoBehaviour
{
    [SerializeField] string areaName;
    [SerializeField] int areaExp;
    [SerializeField] int areaLevel;

    [SerializeField] TMP_Text areaNameText;
    [SerializeField] Slider areaExpSlider;
    [SerializeField] TMP_Text areaLevelText;

    [SerializeField] LevelButton[] levelButtons;
    [SerializeField] List<Level> levels;
    [SerializeField] Level[] optionLevels;

    public List<Level> Levels => levels;

    public void InitAreaLevel()
    {
        int RandomCount = Random.Range(1,101);
        int levelCount = 0;
        if (RandomCount <= 75)
            levelCount = 1;//75%
        else if (RandomCount > 75 && RandomCount <= 85)
            levelCount = 2;//10%
        else if (RandomCount > 85 && RandomCount <= 95)
            levelCount = 3;//10%
        else if (RandomCount > 95)
            levelCount = 4;//5%

        InitLevel(levelCount);
        ShowOrHideLevelSlot(levelCount);


    }

    public void InitLevel(int levelCount)
    {
        for(int i = 0; i < levelCount; i++)
        {
            levels.Add(GetRandomLevel());
            levelButtons[i].SetSprite(levels[i].LevelSprite);
            
        }

        
    }

    public void ShowOrHideLevelSlot(int levelCount)
    {
        for (int i = 0; i < levelCount; i++)
        {
            levelButtons[i].gameObject.SetActive(true);
            levelButtons[i].SetLevel(levels[i]);
        }
        for (int i = levelCount; i < 4; i++)
        {
            levelButtons[i].gameObject.SetActive(false);
        }
    }

    public Level GetRandomLevel()
    {
        int rand = Random.Range(0, optionLevels.Length);

        return optionLevels[rand];
    }
}
