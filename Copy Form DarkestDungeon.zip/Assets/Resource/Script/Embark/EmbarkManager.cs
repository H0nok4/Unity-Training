﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EmbarkManager : MonoBehaviour
{
    [SerializeField] Area[] areas = new Area[6];
    [SerializeField] LevelButton currentButton;
    [SerializeField] LevelButton prvButton;
    [SerializeField] MapDetail mapDetail;
    bool isInited = false;

    public static EmbarkManager instance;
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            if (instance != null)
            {
                Destroy(gameObject);
            }
        }

    }
    private void Start()
    {
        //GameManager.instance.SetCurrentLevel(areas[0].Levels[0]);
    }

    public void InitEmbarkMenu()
    {
        //TO DO 切换页面的时候加载Embark的各项功能，不然失活状态下会出现错误。
        var areas = GameObject.FindGameObjectsWithTag("Area");
        foreach(var area in areas)
        {
            area.GetComponent<Area>().InitAreaLevel();
        }
        //初始化完了所有的Area了
    }

    public void SetCurrentLevelButton(LevelButton curlevelButton)
    {
        if(currentButton != null)
        {
            prvButton = currentButton;
            currentButton = curlevelButton;
            prvButton.SetButtonActive(false);
            currentButton.SetButtonActive(true);
            mapDetail.UpdateMapDetail(curlevelButton.Level);
        }
        else
        {
            mapDetail.gameObject.SetActive(true);
            currentButton = curlevelButton;
            currentButton.SetButtonActive(true);
            mapDetail.UpdateMapDetail(curlevelButton.Level);
        }

    }

}
