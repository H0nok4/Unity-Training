﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum DungeonSize
{
    small,mid,large
}

public enum DungeonMissonType
{
    KillAllEnemy , 
}
[CreateAssetMenu(fileName = "New Level",menuName = "Creat New Level")]
public class Level : ScriptableObject
{
    [SerializeField] string levelName;
    [SerializeField] string levelDetail;
    [SerializeField] DungeonSize dungeonSize;
    [SerializeField] int campFireCount;
    [SerializeField] DungeonMissonType dungeonMissonType;
    [SerializeField] string dungeonMissonDetail;
    [SerializeField] int dungeonLevel;
    [SerializeField] Sprite levelSprite;

    [SerializeField] EnemyParty[] allEnemyParty;
    [SerializeField] int enemyPartyBattleCount;

    public string LevelDetail => levelDetail;
    public string LevelName => levelName;
    public DungeonSize DungeonSize => dungeonSize;
    public int CampFireCount => campFireCount;
    public DungeonMissonType DungeonMissonType => dungeonMissonType;
    public string DungeonMissonDetail => dungeonMissonDetail;
    public int DungeonLevel => dungeonLevel;
    public Sprite LevelSprite => levelSprite;
    public EnemyParty[] AllEnemyParty => allEnemyParty;
    public int EnemyPartyBattleCount => enemyPartyBattleCount;
    
}
