﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class LevelButton : MonoBehaviour, IPointerClickHandler 
{
    [SerializeField] Image image;
    [SerializeField] Level level;
    private void Start()
    {
        image = GetComponent<Image>();
    }

    public Level Level => level;
    public void SetSprite(Sprite sprite)
    {
        image.sprite = sprite;
    }
    public void OnPointerClick(PointerEventData eventData)
    {
        EmbarkManager.instance.SetCurrentLevelButton(this);
    }

    public void SetLevel(Level level)
    {
        this.level = level;
    }

    public void SetButtonActive(bool tof)
    {
        if (tof)
        {
            image.gameObject.transform.localScale = new Vector3(1.1f, 1.1f, 1);
        }
        else
        {
            image.gameObject.transform.localScale = new Vector3(1, 1, 1);
        }
    }
}
