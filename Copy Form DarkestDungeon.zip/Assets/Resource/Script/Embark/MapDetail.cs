﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MapDetail : MonoBehaviour
{
    [SerializeField] TMP_Text nameOfLevel;
    [SerializeField] TMP_Text detailOfLevel;
    [SerializeField] TMP_Text campfireCount;
    [SerializeField] TMP_Text dungeonSizeText;
    [SerializeField] TMP_Text dungeonLevel;
    [SerializeField] TMP_Text dungeonTarget;

    public void UpdateMapDetail(Level level)
    {
        nameOfLevel.text = level.LevelName;
        detailOfLevel.text = level.LevelDetail;
        campfireCount.text = level.CampFireCount.ToString();
        dungeonSizeText.text = level.DungeonSize.ToString();
        dungeonTarget.text = level.DungeonMissonDetail;
    }
}
