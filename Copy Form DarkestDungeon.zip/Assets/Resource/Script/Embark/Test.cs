﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Test : MonoBehaviour, IPointerClickHandler
{
    [SerializeField] Item item;
    public void OnPointerClick(PointerEventData eventData)
    {
        if(eventData.button == PointerEventData.InputButton.Left)
        {
            GameManager.instance.PlayerAllHeroList[0].AddTrinkets(item, 0);
        }
        else if(eventData.button == PointerEventData.InputButton.Right)
        {
            GameManager.instance.PlayerAllHeroList[0].RemoveTrinkets(item, 0);
        }

    }
}
