﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuffManager
{
    public static void Init()
    {
        foreach(var KeyValuePair in buff_Dictionary)
        {
            var buff_ID = KeyValuePair.Key;
            var buff = KeyValuePair.Value;

            buff.id = buff_ID;
        }
    }

    public static Dictionary<string, buff> buff_Dictionary { get; set; } = new Dictionary<string, buff>()
    {
        {
            "Actor_Attack_Low_Add_5",
            new buff()
            {
                id = "Actor_Attack_Low_5",
                stat_type = Stat_Type.combat_stat_add,
                stat_sub_type = Stat_Sub_Type.attack_low,
                amount = 5,
                remove_if_not_active = false,
                rule_type = Rule_Type.always,
                is_false_rule = false,
                is_active = false,
                rule_data = new Rule_Data()
                {
                    rule_float = 0,
                    rule_string = ""
                }
                
            }
        },
        {
            "Actor_Attack_High_Add_5",
            new buff()
            {
                id = "Actor_Attack_High_5",
                stat_type = Stat_Type.combat_stat_add,
                stat_sub_type = Stat_Sub_Type.attack_high,
                amount = 5,
                remove_if_not_active = false,
                rule_type = Rule_Type.always,
                is_false_rule = false,
                is_active = false,
                rule_data = new Rule_Data()
                {
                    rule_float = 0,
                    rule_string = ""
                }

            }
        },
        {
            "Actor_Damage_Add_10",
            new buff()
            {
                id = "Actor_Damage_Add_10",
                stat_type = Stat_Type.combat_stat_add,
                stat_sub_type = Stat_Sub_Type.attack_all,
                amount = 0.15f,
                remove_if_not_active = false,
                rule_type = Rule_Type.always,
                is_false_rule = false,
                is_active = false,
                rule_data = new Rule_Data()
                {
                    rule_float = 0,
                    rule_string = ""
                }

            }
        },

    };


}
