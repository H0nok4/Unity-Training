﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Item
{
    [SerializeField] ItemBase itemBase;

    public Item(ItemBase itemBase)
    {
        this.itemBase = itemBase;
    }

    public ItemBase ItemBase => itemBase;
}
