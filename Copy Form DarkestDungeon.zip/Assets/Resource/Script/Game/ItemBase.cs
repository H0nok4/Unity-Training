﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ItemEnum
{
    item,
    Trinkets,
}

public enum LimitHero
{
    None,
    Warrior
}
[CreateAssetMenu(fileName = "new item",menuName = "Item/Creat new Item")]
public class ItemBase : ScriptableObject
{
    [SerializeField] string itemName;
    [SerializeField] Sprite itemSprite;
    [SerializeField] ItemEnum itemEnum;
    [SerializeField] LimitHero limitHero;
    [SerializeField] string[] buffs;
    [SerializeField] int rarity;
    [SerializeField] int price;
    [SerializeField] string origin_dungeon;
    
    public string ItemName => itemName;
    public Sprite ItemSprite => itemSprite;
    public ItemEnum ItemEnum => itemEnum;
    public LimitHero LimitHero => limitHero;
    public string[] Buffs => buffs;
    public int Rarity => rarity;
    public int Price => price;
    public string Origin_Dungeon => origin_dungeon;


}
