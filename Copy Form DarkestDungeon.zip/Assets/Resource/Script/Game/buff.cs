﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;


public enum Stat_Type
{
    none,
    combat_stat_add,
    combat_stat_multiply,
    damage_received_percent,
    hp_heal_received_percent,
    stress_heal_received_percent,
    resistance
}
public enum Stat_Sub_Type
{
    none,
    attack_low,
    attack_high,
    attack_all,
    crit_chance,
    critDamage,
    protection_rating,

}

public enum Rule_Type
{
    none,
    always,
    skill,
    hpbelow,
    hphigher,
    actorStatus,
    combat_end,
    combat_start
}

public enum Duration_Type
{
    combat_end,
    quest_end,

}
[System.Serializable]
public class buff
{
    public string id { get; set; }
    public Stat_Type stat_type { get; set; }
    public Stat_Sub_Type stat_sub_type { get; set; }
    public float amount { get; set; }
    public bool remove_if_not_active { get; set; }
    public Rule_Type rule_type { get; set; }
    public bool is_false_rule { get; set; }
    public Rule_Data rule_data { get; set; }
    public bool is_active { get; set; }

    public Action<Character> on_start_battle;
    public Action<Character> rule_buff;
    public Action<Character> on_damaged;
    public Action<Character> always;
}
