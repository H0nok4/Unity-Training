﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    [SerializeField] List<Character> playerAllHero = new List<Character>();

    public static GameManager instance;
    [SerializeField] HeroListUI heroList;
    [SerializeField] Image fadeImageDownTown;
    [SerializeField] Image fadeImageEmbark;
    [SerializeField] GameObject downTownUI;
    [SerializeField] GameObject embarkUI;
    [SerializeField] List<Character> playerBattleParty;
    [SerializeField] Level currentLevel;
    [SerializeField] GameObject heroDetailUI;

    public Level CurrentLevel => currentLevel;

    public List<Character> PlayerAllHeroList => playerAllHero;
    public GameObject HeroDetailUI => heroDetailUI; 

    public void Awake()
    {
        if(instance == null)
        {
            instance = this;
        }
        else
        {
            if(instance != null)
            {
                Destroy(gameObject);
            }
        }
        DontDestroyOnLoad(gameObject);

        InitPlayerHero();
        BuffManager.Init();
    }

    public void InitPlayerHero()
    {
        foreach(var hero in playerAllHero)
        {
            hero.InitHero();
        }
    }
    public void AddHero(Character newHero)
    {
        playerAllHero.Add(newHero);
        heroList.UpdateHeroList();
    }

    public void RemoveHero(Character Hero)
    {
        playerAllHero.Remove(Hero);
        heroList.UpdateHeroList();
    }

    public void SetCurrentLevel(Level level)
    {
        currentLevel = level;
    }
    public void SwitchPage(bool tOF)
    {
        if (tOF)
        {
            StartCoroutine(SwitchToEmbarkMenu());
        }
        else
        {

        }

    }

    public IEnumerator SwitchToEmbarkMenu()
    {
        fadeImageDownTown.gameObject.SetActive(true);
        yield return FadeImage(fadeImageDownTown, true);

        fadeImageDownTown.gameObject.SetActive(false);
        downTownUI.gameObject.SetActive(false); 
        embarkUI.gameObject.SetActive(true);
        fadeImageEmbark.gameObject.SetActive(true);

        yield return new WaitForSeconds(0.01f);
        EmbarkManager.instance.InitEmbarkMenu();
        yield return FadeImage(fadeImageEmbark, false);
        fadeImageEmbark.gameObject.SetActive(false);


        yield break;
    }

    public IEnumerator FadeImage(Image image,bool downOrUp)//DownOrUp True的时候为上升，False为下降
    {
        if (downOrUp)
        {
            float alpha = 0;
            while (alpha < 1)
            {
                alpha += 0.1f;
                image.color = new Color(0, 0, 0, alpha);
                yield return new WaitForSeconds(0.05f);
            }
        }
        else
        {
            float alpha = 1;
            while (alpha >= 0)
            {
                alpha -= 0.1f;
                image.color = new Color(0, 0, 0, alpha);
                yield return new WaitForSeconds(0.05f);
            }
        }

        yield break;
    }

    IEnumerator SwitchToDownTownMenu()
    {
        yield break;
    }
}
