﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[System.Serializable]
public class Character
{
    [SerializeField] string _characterName;
    [SerializeField] CharacterBase _characterBase;
    [SerializeField] int _level;
    [SerializeField] int _exp;//经验值
    [SerializeField] List<Skill> validSkill;
    int _currentHP;
    [SerializeField] Item[] trinketSlots;
    [SerializeField] List<buff> buffs;

    private Dictionary<HeroState, int> _HeroBaseStates;
    public CharacterBase CharacterBase => _characterBase;
    public List<Skill> ValidSkill => validSkill;
    public int HeroLevel => _level;

    public Item TrinketSlot1 => trinketSlots[0];
    public Item TrinketSlot2 => trinketSlots[1];

    public Character(CharacterBase characterBase,int level)
    {
        this._characterBase = characterBase;
        this._level = level;
        this._exp = 0;
        buffs = new List<buff>();
        if (characterBase != null)
        {
            InitHero();
        }

    }
    
    public void AddTrinkets(Item _trinkets,int slot)
    {
        if (trinketSlots[slot].ItemBase != null)
            return;
        trinketSlots[slot] = _trinkets;

        TrinketsBuffsAdd(_trinkets);
        ActiveBuffs();
    }

    public void RemoveTrinkets(Item _trinkets,int slot)
    {
        if (trinketSlots[slot].ItemBase == null)
            return;
        trinketSlots[slot] = new Item(null);

        TrinketsBuffRemove(_trinkets);
    }

    public void disableBuffs(buff _buff)
    {
        if (_buff.rule_type == Rule_Type.always)
        {
            buff_stat_down(_buff.stat_sub_type, _buff.amount);
            _buff.is_active = false;
        }

        
        
    }
    public void ActiveBuffs()
    {
        foreach(var buff in buffs)
        {
            if (buff.is_active == true) continue;

            if(buff.rule_type == Rule_Type.always)
            {
                buff_stat_up(buff.stat_sub_type, buff.amount);
                buff.is_active = true;
            }else if(buff.rule_type == Rule_Type.hpbelow)
            {
                //To Do : 根据当前血量的比值来生效
            }
        }
    }

    public void TrinketsBuffsAdd(Item _trinkets)
    {
        foreach(var buff in _trinkets.ItemBase.Buffs)
        {
            buffs.Add(BuffManager.buff_Dictionary[buff]);
        }
    }

    public void TrinketsBuffRemove(Item _trinkets)
    {
        foreach (var buff in _trinkets.ItemBase.Buffs)
        {
            buffs.Remove(BuffManager.buff_Dictionary[buff]);
            disableBuffs(BuffManager.buff_Dictionary[buff]);
        }
    }

    public void buff_stat_up(Stat_Sub_Type stat_sub_type,float amount)
    {
        switch (stat_sub_type)
        {
            case Stat_Sub_Type.attack_all:
                this._HeroBaseStates[HeroState.MinAttack] += (int)(_characterBase.MinAttackBase * amount);
                this._HeroBaseStates[HeroState.MaxAttack] += (int)(_characterBase.MaxAttackBase * amount);
                break;
            case Stat_Sub_Type.protection_rating:
                this._HeroBaseStates[HeroState.Defense] += (int)amount;
                break;
            case Stat_Sub_Type.attack_low:
                this._HeroBaseStates[HeroState.MinAttack] += (int)amount;
                break;
            case Stat_Sub_Type.attack_high:
                this._HeroBaseStates[HeroState.MaxAttack] += (int)amount;
                break;
        }
    }

    public void buff_stat_down(Stat_Sub_Type stat_sub_type, float amount)
    {
        switch (stat_sub_type)
        {
            case Stat_Sub_Type.attack_all:
                this._HeroBaseStates[HeroState.MinAttack] -= (int)(_characterBase.MinAttackBase * amount);
                this._HeroBaseStates[HeroState.MaxAttack] -= (int)(_characterBase.MaxAttackBase * amount);
                break;
            case Stat_Sub_Type.protection_rating:
                this._HeroBaseStates[HeroState.Defense] -= (int)amount;
                break;
            case Stat_Sub_Type.attack_low:
                this._HeroBaseStates[HeroState.MinAttack] -= (int)amount;
                break;
            case Stat_Sub_Type.attack_high:
                this._HeroBaseStates[HeroState.MaxAttack] -= (int)amount;
                break;
        }
    }

    public void InitHero()
    {
        foreach(Skill skill in _characterBase.Skills)
        {
            if (skill.isSkillValiable)
            {
                validSkill.Add(skill);
            }
        }

        InitBaseStates();//英雄的基础属性

        //TO DO : 装备系统的属性附加
        trinketSlots = new Item[2];
        trinketSlots[0] = new Item(null);
        trinketSlots[1] = new Item(null);
        buffs = new List<buff>();
        _currentHP = _HeroBaseStates[HeroState.MaxHealth];
    }

    private void InitBaseStates()
    {

        _HeroBaseStates = new Dictionary<HeroState, int>();
        _HeroBaseStates.Add(HeroState.MinAttack, _characterBase.MinAttackBase);
        _HeroBaseStates.Add(HeroState.MaxAttack, _characterBase.MaxAttackBase);
        _HeroBaseStates.Add(HeroState.Defense, _characterBase.DefenseBase);
        _HeroBaseStates.Add(HeroState.Speed, _characterBase.SpeedBase);
        _HeroBaseStates.Add(HeroState.MaxHealth, _characterBase.MaxHealthBase);
        _HeroBaseStates.Add(HeroState.avoid, _characterBase.AvoidBase);
        _HeroBaseStates.Add(HeroState.accracy, _characterBase.Accuracy);
        _HeroBaseStates.Add(HeroState.accracyCorrection, _characterBase.AccracyCorrectionBase);
        _HeroBaseStates.Add(HeroState.CriticalChance, _characterBase.CriticalHitChanceBase);
        _HeroBaseStates.Add(HeroState.CriticalDamage, _characterBase.CriticalHitDamageBase);
        _HeroBaseStates.Add(HeroState.bloodResistance, _characterBase.BloodResistance);
        _HeroBaseStates.Add(HeroState.deathResistance, _characterBase.DeathResistance);
        _HeroBaseStates.Add(HeroState.stunResistance, _characterBase.StunResistance);
        _HeroBaseStates.Add(HeroState.diseaseResistance, _characterBase.DiseaseResistance);
        _HeroBaseStates.Add(HeroState.corrosionResistance, _characterBase.CorrosionResistance);
        _HeroBaseStates.Add(HeroState.moveResistance, _characterBase.MoveResistance);
        _HeroBaseStates.Add(HeroState.trapResistance, _characterBase.TrapResistance);
        _HeroBaseStates.Add(HeroState.debuffResistance, _characterBase.DebuffResistance);
    }

    public int ReciveDamage(int damage,Skill skill)
    {
        //TO DO : 技能附加的特殊属性等

        //临时版本
        int ReciveDamage = (int)(damage * (1 - (HeroDefense / 100.0)));

        _currentHP -= ReciveDamage;

        foreach(var buff in buffs)
        {
            buff?.on_damaged?.Invoke(this);
        }

        return _currentHP;
    }

    public string HeroName => _characterName;
    public int HeroMinAttack => _HeroBaseStates[HeroState.MinAttack];
    public int HeroMaxAttack => _HeroBaseStates[HeroState.MaxAttack];
    public int HeroDefense => _HeroBaseStates[HeroState.Defense];
    public int HeroMaxHealth => _HeroBaseStates[HeroState.MaxHealth];
    public int HeroAvoid => _HeroBaseStates[HeroState.avoid];
    public int HeroCriticalChance => _HeroBaseStates[HeroState.CriticalChance];
    public int HeroCriticalDamage => _HeroBaseStates[HeroState.CriticalDamage];
    public int HeroAccracyCorrect => _HeroBaseStates[HeroState.accracyCorrection];
    public int HeroSpeed => _HeroBaseStates[HeroState.Speed];
    public int HeroCurrentHP => _currentHP;
}

public enum HeroState
{
    MinAttack,
    MaxAttack,
    MaxHealth,
    Defense,
    Speed,
    CriticalChance,
    CriticalDamage,
    avoid,
    accracy,
    accracyCorrection,
    deathResistance,
    bloodResistance,
    stunResistance,
    diseaseResistance,
    corrosionResistance,
    moveResistance,
    trapResistance,
    debuffResistance
}