﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
[CreateAssetMenu(menuName = "Character/Creat New Character", fileName = "New Character")]
public class CharacterBase : ScriptableObject
{
    [SerializeField] string characterName;

    [SerializeField] HeroClass heroClass;

    [SerializeField] Animator animator;

    [SerializeField] Sprite headSprite;

    [SerializeField] Sprite attackSprite;
    [SerializeField] Sprite useSkillSprite;
    [SerializeField] Sprite damagedSprite;
    [SerializeField] Sprite idleSprite;

    [TextArea]
    [SerializeField] string characterDescribe;

    [Header("基础属性")]
    [SerializeField] int minAttackBase;
    [SerializeField] int maxAttackBase;
    [SerializeField] int defenseBase;
    [SerializeField] int maxHealthBase;
    [SerializeField] int criticalHitChanceBase;
    [SerializeField] int criticalHitDamageBase;
    [SerializeField] int avoidBase;
    [SerializeField] int accracyBase = 100;
    [SerializeField] int accracyCorrectionBase;
    [SerializeField] int speedBase;

    [Header("抗性")]
    [SerializeField] int death;
    [SerializeField] int blood;
    [SerializeField] int stun;
    [SerializeField] int disease;
    [SerializeField] int corrosion;
    [SerializeField] int move;
    [SerializeField] int trap;
    [SerializeField] int debuff;

    [SerializeField] List<Skill> skills;


    public int MinAttackBase => minAttackBase;
    public int MaxAttackBase => maxAttackBase;
    public int DefenseBase => defenseBase;
    public int MaxHealthBase => maxHealthBase;
    public int SpeedBase => speedBase;
    public int CriticalHitChanceBase => criticalHitChanceBase;
    public int CriticalHitDamageBase => criticalHitDamageBase;
    public int AvoidBase => avoidBase;
    public int Accuracy => accracyBase;
    public int AccracyCorrectionBase => accracyCorrectionBase;

    public int DeathResistance => death;
    public int BloodResistance => blood;
    public int StunResistance => stun;
    public int DiseaseResistance => disease;
    public int CorrosionResistance => corrosion;
    public int MoveResistance => move;
    public int TrapResistance => trap;
    public int DebuffResistance => debuff;
    public Animator CharacterAnimator => animator;
    public HeroClass CharacterClass => heroClass;
    public Sprite AttackSprite => attackSprite;
    public Sprite UseSkillSprite => useSkillSprite;
    public Sprite DamagedSprite => damagedSprite;
    public Sprite IdleSprite => idleSprite;
    public Sprite HeadSprite => headSprite;
    public List<Skill> Skills => skills;
}

public enum HeroClass
{
    None,//用于小怪
    warrior,
}