﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Skill
{
    [SerializeField] SkillBase skillBase;
    public bool isSkillValiable;

    public Skill(SkillBase heroSkillBase)
    {
        this.skillBase = heroSkillBase;
    }
    public SkillBase SkillBase => skillBase;

}
