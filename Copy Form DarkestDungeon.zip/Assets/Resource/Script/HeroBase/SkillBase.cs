﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(menuName = "Skill/Creat New Skill", fileName = "New Skill")]
public class SkillBase : ScriptableObject
{
    [SerializeField] Sprite skillSprite;
    [SerializeField] string skillName;
    [TextArea]
    [SerializeField] string skillDescribe;

    [Header("基础精准")]
    [SerializeField] int skillAccBase;
    [Header("伤害修正")]
    [SerializeField] int damageCorrection;
    [Header("暴击修正")]
    [SerializeField] int criticalCorrection;
    [Header("冷却时间")]
    [SerializeField] int skillCoolDown;
    [Header("技能范围")]
    [SerializeField] SkillTargetPosition skillTargetPostion;
    [Header("技能是否是范围攻击")]
    [SerializeField] bool isAoeSkill;
    [Header("技能释放目标")]
    [SerializeField] SkillTarget skillTarget;


    public Sprite SkillSprite => skillSprite;
    public string SkillName => skillName;
    public string SkillDescribe => skillDescribe;
    public int SkillAccBase => skillAccBase;
    public int DamageCorrection => damageCorrection;
    public int CriticalCorrection => criticalCorrection;
    public SkillTargetPosition SkillTargetPosition => skillTargetPostion;
    public bool IsAoeSkill => isAoeSkill;
    public SkillTarget SkillTarget => skillTarget;
}

public enum SkillTarget
{
    Self,
    Ally,
    Enemy,
}