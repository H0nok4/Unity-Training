﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class SkillTargetPosition
{
    [Header("可以释放的位置")]
    [SerializeField] bool[] canUsePos = new bool[4];

    [Header("可以攻击的位置")]
    [SerializeField] bool[] canAttackPos = new bool[4];

    public bool[] CanUsePos => canUsePos;
    public bool[] CanAttackPos => canAttackPos;
}
