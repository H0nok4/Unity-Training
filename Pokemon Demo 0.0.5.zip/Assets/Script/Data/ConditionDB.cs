﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//conditionDB是异常状态管理器，这里放着与异常状态相关的代码。
public class ConditionDB
{
    public static void Init()//初始化，将异常状态的名字获取，并赋值给condition的异常状态ID，让其他类可以调用。
    {
        foreach(var keyValuePair in Conditions)
        {
            var conditionID = keyValuePair.Key;
            var condition = keyValuePair.Value;

            condition.statusID = conditionID;
        }
    }
    public static Dictionary<ConditionID, Condition> Conditions { get; set; } = new Dictionary<ConditionID, Condition>()//异常状态字典
    {
        {ConditionID.poison,//中毒状态
        new Condition()
        {
            statusID = ConditionID.poison,
            Name = "Poison",
            StartMessage = "has been poisoned",
            OnAfterTurn = (PokeGirl pokeX) =>//lamba表达式，生效时的动作等
            {
                pokeX.UpdateHP(pokeX.MaxHP / 8);
                pokeX.StatusChanges.Enqueue($"{pokeX.Base.Name} hurt itself due to poison");
            }
        }
        },
        {ConditionID.burn,//烧伤状态
        new Condition()
        {
            statusID = ConditionID.burn,
            Name = "Burn",
            StartMessage = "has been burned",
            OnAfterTurn = (PokeGirl pokeX) =>//lamba表达式，生效时的动作等
            {
                pokeX.UpdateHP(pokeX.MaxHP / 16);
                pokeX.StatusChanges.Enqueue($"{pokeX.Base.Name} hurt itself due to burn");
            }
        }
        },
        {ConditionID.paralyze,//麻痹状态
        new Condition()
        {
            statusID = ConditionID.paralyze,
            Name = "Paralyze",
            StartMessage = "has been Paralyze",
            OnBeforeSkill = (PokeGirl PokeX) =>
            {
                if(Random.Range(1,5) == 1)//每回合开始之前，25%的几率无法做出行动
                {
                    PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name}'s paralyze and can't move");
                    return false;
                }
                return true;
            }
        }
        },
        {ConditionID.freeze,//冻结状态
        new Condition()
        {
            statusID = ConditionID.freeze,
            Name = "Freeze",
            StartMessage = "has been Freezed",
            OnBeforeSkill = (PokeGirl PokeX) =>
            {
                if(Random.Range(1,5) == 1)//每回合有25%的几率从冻结中解放。
                {
                    PokeX.CureStatus();
                    PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name}'s not frozon any more");
                    return true;
                }
                return false;
            }
        }
        },
        {ConditionID.sleep,//冻结状态
        new Condition()
        {
            statusID = ConditionID.sleep,
            Name = "Sleep",
            StartMessage = "has fallen asleepy",
            OnStart = (PokeGirl PokeX) =>
            {
                PokeX.statusTimes = Random.Range(1,4);//睡眠1-3回合，睡眠期间无法行动
                Debug.Log($"Will be asleep for {PokeX.statusTimes} turn");
            },
            OnBeforeSkill = (PokeGirl PokeX) =>
            {
                if (PokeX.statusTimes <= 0)
                {
                    PokeX.CureStatus();//治疗异常状态（就是清空当前的异常状态）
                    PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name} is wake up!");//持续时间结束，醒来了
                    return true;
                }

                PokeX.statusTimes--;
                PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name} is sleeping");
                return false;
            }
        }
        },
        //volatileStatus（这玩意啥意思） 状态
        {ConditionID.confusion,//冻结状态
        new Condition()
        {
            statusID = ConditionID.confusion,
            Name = "Confusion",
            StartMessage = "has been confusion",
            OnStart = (PokeGirl PokeX) =>
            {
                //持续时间 1-4回合，range为[1,5)
                PokeX.volatileStatusTimes = Random.Range(1,5);
                Debug.Log($"Will be confuse for {PokeX.volatileStatusTimes} turn");
            },
            OnBeforeSkill = (PokeGirl PokeX) =>
            {
                if (PokeX.statusTimes <= 0)
                {
                    PokeX.CureVolatileStatus();
                    PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name} kick out of confusion!");
                    return true;
                }

                PokeX.statusTimes--;
                //混乱状态下，每回合有50%的几率可以行动
                if(Random.Range(1,3) == 1)
                {
                    return true;
                }
                //剩下50%的概率，自己受伤（相当于一半几率打对方，一半几率打自己）
                PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name} is confused");
                PokeX.UpdateHP(PokeX.MaxHP / 8);
                PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name} is hurt itself due to confusion");
                return false;
            }
        }
        }

    };

}

public enum ConditionID
{
    none,poison,burn,sleep,paralyze,freeze,
    confusion

}
