﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

    public enum GameState{ Walk,Battle,LookUI}
public class GameManager : MonoBehaviour
{
    GameState gameState;//游戏当前状态控制器

    [SerializeField] PlayerController playerController;//获取移动脚本，用来切换是否可以移动的状态
    [SerializeField] BattleManager battleManager;//获取战斗管理器，用来切换进入战斗状态。

    [SerializeField] Camera mainCamera;

    public void Start()
    {
        playerController.OnEncountered += StartBattle;//事件系统，触发战斗
        battleManager.OnBattleOver += EndBattle;//事件系统，结束战斗。

    }

    private void Awake()
    {
        ConditionDB.Init();//游戏开始时，初始化异常状态管理器
    }

    void StartBattle()//触发战斗
    {
        gameState = GameState.Battle;
        battleManager.gameObject.SetActive(true);//将battleManager显示出来
        mainCamera.gameObject.SetActive(false);//将角色的摄像头关闭，切换为战斗管理器的摄像头。
        var playerPokeXParty = playerController.GetComponent<PokeXParty>();//初始玩家的队伍
        var wildPokeX = FindObjectOfType<MapArea>().GetComponent<MapArea>().GetRandomPokeX();//初始遇到的野生PokeX

        battleManager.StartBattle(playerPokeXParty,wildPokeX);//开始战斗

    }

    void EndBattle(bool won)//结束战斗
    {
        gameState = GameState.Walk;
        battleManager.gameObject.SetActive(false);
        mainCamera.gameObject.SetActive(true);
    }

    private void Update()//检测当前的状态，然后触发控制相应的Update更新函数。
    {
        if(gameState == GameState.Walk)
        {
            playerController.HandleUpdate();
        }else if(gameState == GameState.Battle)
        {
            battleManager.HandleUpdate();
        }
    }

}
