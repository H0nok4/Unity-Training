﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//这个脚本中写着不同地图的不同野生精灵。
public class MapArea : MonoBehaviour
{
    [SerializeField]List<PokeGirl> WildPokeGirl;

    public PokeGirl GetRandomPokeX()
    {
        var wildPokeGirl = WildPokeGirl[Random.Range(0, WildPokeGirl.Count - 1)];
        wildPokeGirl.Init();
        return wildPokeGirl;
    }
}
