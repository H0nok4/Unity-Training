﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(menuName = "PokeX/Creat New Skill", fileName = "New Skill")]
public class SkillBase : ScriptableObject
{//技能系统基础，同样，SerializeField用来保护变量，并且用get，set构造器来可读可改。
    [SerializeField] string skillName;

    [TextArea]
    [SerializeField] string skillDescription;//描述

    [SerializeField] Type type;//属性  --和属性克制有关

    [SerializeField] int power;//威力
    [SerializeField] int accuracy;//命中率
    [SerializeField] bool alwaysAccuracy;//是否为必中技能

    [SerializeField] int pp;//使用次数，**不过并不想用这个

    [SerializeField] SkillCategory category;//技能种类 --普通 特殊 属性改变

    [SerializeField] SkillEffects effects;//技能效果

    [SerializeField] List<SecondaryEffects> secondaryEffects;

    [SerializeField] SkillTarget target;//技能目标

    public string Name
    {
        get { return skillName; }
    }
    public string SkillDescription
    {
        get { return skillDescription; }
    }
    public Type SkillType
    {
        get { return type; }
    }
    public int Power
    {
        get { return power; }
    }
    public int Accuracy
    {
        get { return accuracy; }
    }

    public bool AlwaysAccuracy
    {
        get { return alwaysAccuracy; }
    }
    public int PP
    {
        get { return pp; }
    }

    public SkillCategory SkillCategory
    {
        get { return category; }
    }

    public SkillEffects SkillEffects//技能效果
    {
        get { return effects; }
    }

    public SkillTarget SkillTarget//技能的目标
    {
        get { return target; }
    }

    public List<SecondaryEffects> SecondaryEffects
    {
        get { return secondaryEffects; }
    }

}


[System.Serializable]
public class SkillEffects//技能所带的效果
{
    [SerializeField] List<StateBoost> stateBoostList;//属性提升
    [SerializeField] ConditionID status;//异常状态
    [SerializeField] ConditionID volatileStatus;//不稳定异常状态

    public ConditionID Status//用geter获取并返回
    {
        get { return status; }
    }
    public List<StateBoost> StateBoostList//用geter获取并返回
    {
        get { return stateBoostList; }
    }

    public ConditionID VolatileStatus//用geter获取并返回
    {
        get { return volatileStatus; }
    }
}
[System.Serializable]
public class StateBoost//属性提升
{
    public State state;
    public int boostValue;
}

public enum SkillCategory//技能的种类，物理，特殊，属性改变
{
    Physical,Special,StatusChange
}

public enum SkillTarget//技能目标，foe 为 敌方，self 为 自身
{
    Foe,Self
}
[System.Serializable]
public class SecondaryEffects:SkillEffects
{
    [SerializeField]int chance;

    [SerializeField] SkillTarget target;

    public int Chance
    {
        get { return chance; }
    }

    public SkillTarget Target
    {
        get { return target; }
    }
}
