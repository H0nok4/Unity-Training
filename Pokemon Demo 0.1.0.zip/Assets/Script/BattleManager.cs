﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;


public enum BattleStates { Start, ActionSelection, SkillSelection, RunningTurn, Busy, BattleOver,PartyScreen}

public enum BattleAction { UseSkill,SwitchPokeX,UseItem,Run}
/*  BattleManager管理整个游戏的战斗系统逻辑
 *  用BattleStates有限状态机，实现了从开始状态到其他战斗中状态的转变，再到BattleOver状态结束战斗
 *  战斗中的状态主要有三种 动作选择（玩家选择使用技能，使用物品，切换上场的角色，逃跑），技能选择（选择在这一回合中释放的技能），执行回合逻辑（当前回合的执行逻辑，包括了使用技能，异常状态检查，是否战败检查）
 *  而状态机中的Busy状态， 则是BattleManager在执行逻辑时使用的临时状态
 *  而与BattleManager相关联的有PokeX类（精灵实例），Condition类（异常状态系统），BattleHud类（UI显示相关），Skill（PokeX的技能相关）
 */

public class BattleManager : MonoBehaviour
{
    //public BattleState battleState;//有限状态机

    //public GameObject PlayerPrefab;//玩家预设
    //public GameObject EnemyPrefab;//敌人预设

    //public Transform PlayerSpawner;//玩家位置
    //public Transform EnemySpawner;//敌人位置

    //public Unit PlayerUnit;//玩家属性
    //public Unit EnemyUnit;//敌人属性

    //public TMP_Text DiologyTMP;//对话框

    //public TMP_Text enemyNameHUD;//敌人UI名字
    //public TMP_Text enemylvHUD;//敌人等级
    //public TMP_Text playerNameHUD;//玩家名字
    //public TMP_Text playerlvHUD;//玩家等级

    //public TMP_Text playerHP;//玩家UI血量栏
    //public TMP_Text enemyHP;//敌人UI血量栏

    //public Slider PlayerHPS;//玩家血条
    //public Slider enemyHPS;//敌人血条

    //public GameObject PlayerGO;//当前玩家在场的精灵
    //public GameObject EnemyGO;//当前敌人在场的精灵


    //void Start()//初始化
    //{
    //    battleState = BattleState.START;
    //   StartCoroutine(SetUpBattleScence());

    //}

    //IEnumerator SetUpBattleScence()//初始化战斗场景
    //{

    //    PlayerGO = Instantiate(PlayerPrefab, PlayerSpawner);//初始化生成玩家第一个角色
    //    PlayerUnit = PlayerGO.GetComponent<Unit>();//读取玩家的精灵属性
    //    EnemyGO = Instantiate(EnemyPrefab, EnemySpawner);//初始化敌人第一个角色
    //    EnemyUnit = EnemyGO.GetComponent<Unit>();//初始化

    //    DiologyTMP.text = "A Wild " + EnemyUnit.Name + " is apporching!";//对话框显示一句话

    //    UpdateBattleUI();//刷新俩方UI栏，更新血条等

    //    yield return new WaitForSeconds(2f);//等待2秒钟

    //    if(PlayerUnit.speed > EnemyUnit.speed)//比较玩家和敌人的速度，设置第一个回合出手是谁
    //    {
    //        battleState = BattleState.PLAYERTURN;
    //        PlayerTurn();
    //    }

    //}

    //public void UpdateBattleUI()//刷新UI
    //{
    //    enemyNameHUD.text = EnemyUnit.Name;
    //    enemylvHUD.text = "lv: " + EnemyUnit.level.ToString();
    //    playerNameHUD.text = PlayerUnit.Name;
    //    playerlvHUD.text = "lv: " + PlayerUnit.level.ToString();
    //    playerHP.text = PlayerUnit.currentHP.ToString() + "/" + PlayerUnit.maxHP.ToString();
    //    enemyHP.text = EnemyUnit.currentHP.ToString() + "/" + EnemyUnit.maxHP.ToString();

    //    PlayerHPS.maxValue = PlayerUnit.maxHP;
    //    PlayerHPS.value = PlayerUnit.currentHP;

    //    enemyHPS.maxValue = EnemyUnit.maxHP;
    //    enemyHPS.value = EnemyUnit.currentHP;
    //}

    //public void PlayerTurn()
    //{
    //    DiologyTMP.text = "It's Your Turn Choose You Action!";//
    //}

    //IEnumerator EnemyTurn()//敌人回合
    //{
    //    if (battleState == BattleState.ENEMYTURN)//攻击玩家
    //    {
    //        Attack(EnemyUnit, PlayerUnit);
    //        yield return new WaitForSecondsRealtime(1f);
    //        if (PlayerUnit.currentHP <= 0)//如果玩家死亡，切换BattleState为LOSE
    //        {
    //            battleState = BattleState.LOSE;
    //            PlayerLose();
    //        }
    //        else
    //        {
    //            battleState = BattleState.PLAYERTURN;//如果玩家没有死亡，切换到玩家回合
    //            PlayerTurn();
    //        }

    //    }

    //}

    //public void PlayerLose()//战败
    //{
    //    DiologyTMP.text = "You LOOOOOOOOSE!";
    //}

    //public void PlayerWin()//胜利
    //{
    //    DiologyTMP.text = "You Are The Champion!";
    //}

    //public void ClickAttackButton()//玩家选择攻击
    //{
    //    if(battleState == BattleState.PLAYERTURN)
    //    {
    //        StartCoroutine(PlayerAction());
    //    }
    //}

    //IEnumerator PlayerAction()//玩家的动作。
    //{
    //    battleState = BattleState.ENEMYTURN;
    //    Attack(PlayerUnit, EnemyUnit);
    //    yield return new WaitForSecondsRealtime(1f);
    //    if (EnemyUnit.currentHP <= 0)
    //    {
    //        battleState = BattleState.WIN;
    //        PlayerWin();
    //    }
    //    else
    //    {
    //        battleState = BattleState.ENEMYTURN;
    //        StartCoroutine(EnemyTurn());
    //    }
    //}

    //private void Attack(Unit caster,Unit target)//简单的攻击函数，目标的血量减少施法者的攻击。
    //{
    //    DiologyTMP.text = caster.Name + " Attack to " + target.Name;
    //    target.currentHP -= caster.attck;
    //    UpdateBattleUI();
    //}

    [SerializeField] BattleUnit playerUnit;
    [SerializeField] BattleUnit enemyUnit;

    public TMP_Text DiologyTMP;//对话框

    public PartyScreen partyScreen;

    public BattleDialogBox battleDialogBox;//对话框

    public BattleStates battleState;//目前战斗的状态是什么
    public BattleStates? prvBattleState; //上一个战斗的状态是什么

    public int currentAction;//当前选择的行动是哪个
    public int currentSkill; //当前选择的行动是哪个
    public int currentPartyMember;

    public event Action<bool> OnBattleOver;//事件，检测战斗开启，用来在GameManager中切换行走状态和战斗状态。

    PokeGirl wildPokeX;//野生的PokeX
    PokeXParty playerPokeParty;//玩家的队伍
    public void StartBattle(PokeXParty PlayerParty, PokeGirl wildPokeX)//初始化战斗场景，将传入的参数设为当前脚本的变量。
    {
        this.playerPokeParty = PlayerParty;
        this.wildPokeX = wildPokeX;



        StartCoroutine(BattleStart());//开始迭代器。
    }

    public IEnumerator BattleStart()//迭代器，将目前场景初始化
    {

        SetUnit();//将玩家和对手的Unit显示出来。

        partyScreen.Init();

        battleDialogBox.UpdateSkillName(playerUnit.PokeX.Skills);//更新玩家的技能栏
        battleDialogBox.SetDiologText("A Wild " + enemyUnit.PokeX.Base.Name + " is apporching");//显示遇到敌人的文字。
        yield return new WaitForSeconds(2f);


        ActionSelection();//进入到玩家选择动作的步骤


    }
    //已弃用 选择第一个出手的角色的逻辑已迁移至 RunTurn 方法中
    //void ChooseFirstTurn()//选择第一个出手的角色
    //{
    //    if (playerUnit.PokeX.Speed >= enemyUnit.PokeX.Speed)
    //    {
    //        ActionSelection();
    //    }
    //    else
    //    {
    //        StartCoroutine(EnemyUsingSkill());
    //    }
    //}
    //已弃用 选择第一个出手的角色的逻辑已迁移至 RunTurn 方法中
    public void ActionSelection()//玩家回合，等待玩家选择一个动作
    {
        battleState = BattleStates.ActionSelection;//有限状态机
        battleDialogBox.SetDiologText("Choose Your Action!");
        battleDialogBox.ActionSelectorEnabled(true);

    }

    public void SkillSelection()//当玩家使用技能时，切换到目前的状态
    {
        battleState = BattleStates.SkillSelection;//切换状态机状态，调整UI界面。
        battleDialogBox.ActionSelectorEnabled(false);
        battleDialogBox.DialogTextEnabled(false);
        battleDialogBox.SkillSelectorEnabled(true);

    }

    //已弃用 敌人回合相关的逻辑已经迁移到 RunTurn 方法中
    //IEnumerator EnemyUsingSkill()//敌人的回合，包含简易AI，随机使用一个已有的技能。
    //{
    //    battleState = BattleStates.RunningTurn;

    //    var enemySkill = enemyUnit.PokeX.GetRandomSkill();//获取一个随机技能
    //    yield return StartCoroutine(RunSkill(enemyUnit, playerUnit, enemySkill));

    //    if (battleState == BattleStates.RunningTurn)
    //    {
    //        ActionSelection();//如果没有死亡，下一回合切换到玩家的回合。
    //    }
    //}
    //已弃用 敌人回合相关的逻辑已经迁移到 RunTurn 方法中

    public void HandleUpdate()//技能和动作选择栏更新。
    {
        if (battleState == BattleStates.ActionSelection)
        {
            HandleActionSelect();
        } else if (battleState == BattleStates.SkillSelection)
        {
            HandleSkillSelect();
        }
        else if (battleState == BattleStates.PartyScreen)
        {
            HandlePartyScreenSelect();
        }


    }

    public void OpenPartyScreen()//打开队伍列表
    {
        battleState = BattleStates.PartyScreen;
        partyScreen.setPartyData(playerPokeParty.pokeGirls);
        partyScreen.gameObject.SetActive(true);
    }
    private void HandleActionSelect()//处理动作选择栏
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow)) currentAction--;   
        else if (Input.GetKeyDown(KeyCode.RightArrow)) currentAction++;
        else if (Input.GetKeyDown(KeyCode.UpArrow)) currentAction -= 2;
        else if (Input.GetKeyDown(KeyCode.DownArrow)) currentAction += 2;

        currentAction = Mathf.Clamp(currentAction, 0, 3);

        battleDialogBox.UpdateActionSelection(currentAction);//每次移动选择栏，更新一次面板

        if (Input.GetKeyDown(KeyCode.Return))//按下回车键，选择动作
        {
            if (currentAction == 0)//选择的相应的动作。
            {
                //fight
                SkillSelection();
            } else if (currentAction == 1)
            {
                //bag
            } else if (currentAction == 2)
            {
                //PokeX
                prvBattleState = battleState;//当玩家选择切换PokeX，将上一个战斗状态设为当前的战斗状态
                OpenPartyScreen();
            }
            else
            {
                //Run
            }
        }
    }

    private void HandleSkillSelect()//处理技能选择栏，和动作选择大同小异。
    {
        battleDialogBox.UpdateSkillSelection(currentSkill, playerUnit.PokeX.Skills[currentSkill]);//更新玩家的技能栏
        if (Input.GetKeyDown(KeyCode.LeftArrow)) currentSkill--;//上下左右键控制当前是哪个技能
        else if (Input.GetKeyDown(KeyCode.RightArrow)) currentSkill++;
        else if (Input.GetKeyDown(KeyCode.UpArrow)) currentSkill -= 2;
        else if (Input.GetKeyDown(KeyCode.DownArrow)) currentSkill += 2;

        currentSkill = Mathf.Clamp(currentSkill, 0, playerUnit.PokeX.Skills.Count - 1);

        if (Input.GetKeyDown(KeyCode.Return) && battleState == BattleStates.SkillSelection)//玩家按下回车，且现在是玩家选择技能回合，使用当前选择的技能。
        {
            if (playerUnit.PokeX.Skills[currentSkill].PP == 0) return;
            battleDialogBox.DialogTextEnabled(true);
            battleDialogBox.SkillSelectorEnabled(false);
            StartCoroutine(RunTurn(BattleAction.UseSkill));//选定了要释放的技能，开始协程（使用技能）

        } else if (Input.GetKeyDown(KeyCode.X) && battleState == BattleStates.SkillSelection)//按X返回行动选择界面
        {
            battleDialogBox.DialogTextEnabled(true);
            battleDialogBox.SkillSelectorEnabled(false);
            ActionSelection();
        }
    }

    private void HandlePartyScreenSelect()//队伍选择相关的逻辑
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow)) currentPartyMember--;
        else if (Input.GetKeyDown(KeyCode.RightArrow)) currentPartyMember++;
        else if (Input.GetKeyDown(KeyCode.UpArrow)) currentPartyMember -= 2;
        else if (Input.GetKeyDown(KeyCode.DownArrow)) currentPartyMember += 2;

        currentPartyMember = Mathf.Clamp(currentPartyMember, 0, playerPokeParty.pokeGirls.Count - 1);

        partyScreen.UpdatePartyMember(currentPartyMember);

        if (Input.GetKeyDown(KeyCode.Return))//按下回车键，选择动作
        {
            var selectMember = playerPokeParty.pokeGirls[currentPartyMember];
            if (selectMember.CurrentHP <= 0)
            {
                partyScreen.SetMessageText("You Can't choose a dead PokeX");
                return;
            }
            if (selectMember == playerUnit.PokeX)
            {
                partyScreen.SetMessageText("You can't choose a same PokeX");
                return;
            }

            partyScreen.gameObject.SetActive(false);//关闭选择队伍的选择页面

            if(prvBattleState == BattleStates.ActionSelection)//如果上一个BattleStates状态为动作选择，那么切换角色的流程就为正常流程（因为也可能是玩家的PokeX死亡导致的需要切换角色）（正常流程：敌方PokeX将会攻击一次玩家的PokeX）
            {                                                 //如果是玩家的PokeX被击杀导致的需要切换角色，那么在切换PokeX后，敌方将不会攻击玩家
                prvBattleState = null;
                StartCoroutine(RunTurn(BattleAction.SwitchPokeX));
            }

            battleState = BattleStates.Busy;
            StartCoroutine(SwitchPokeX(selectMember));

        } else if (Input.GetKeyDown(KeyCode.X))
        {
            partyScreen.gameObject.SetActive(false);
            ActionSelection();
        }
    }
    IEnumerator ShowDamageDetail(DamageDetails damageDetails)//用来处理攻击特效，分别为暴击，效果显著，效果略微。
    {
        if (damageDetails.isCritical > 1f)
        {
            yield return battleDialogBox.TypeDialog("A critical hit!");//暴击了
            yield return new WaitForSeconds(0.5f);
        }

        if (damageDetails.isEffect > 1f)
        {
            yield return battleDialogBox.TypeDialog("It's super effective!");//效果显著
            yield return new WaitForSeconds(0.5f);
        } else if (damageDetails.isEffect < 1f)
        {
            yield return battleDialogBox.TypeDialog("It's not effective");//效果略微
            yield return new WaitForSeconds(0.5f);
        }
    }

    IEnumerator RunTurn(BattleAction playerAction)
    {
        battleState = BattleStates.RunningTurn;

        if (playerAction == BattleAction.UseSkill)//如果这一回合玩家选择了使用技能
        {
            playerUnit.PokeX.currentSkill = playerUnit.PokeX.Skills[currentSkill];//
            enemyUnit.PokeX.currentSkill = enemyUnit.PokeX.GetRandomSkill();//将俩方将要使用的技能都保存起来


            int playerSkillPriority = playerUnit.PokeX.currentSkill._base.Priority;//将双方使用的技能优先级保存起来
            int enemySkillPriority = enemyUnit.PokeX.currentSkill._base.Priority;

            bool isPlayerGoesFirst = true;

            if(enemySkillPriority > playerSkillPriority)//如果敌人的技能优先级比玩家高，那么敌人先出手
            {
                isPlayerGoesFirst = false;
            }else if(enemySkillPriority == playerSkillPriority)//如果双方技能优先级相同，则使用PokeX的速度值来作为先出手的判断条件
            {
                isPlayerGoesFirst = playerUnit.PokeX.Speed >= enemyUnit.PokeX.Speed;//检测是否是玩家先出手
            }
            else
            {
                isPlayerGoesFirst = true;//玩家的技能优先级高，玩家先出手
            }





            var firstUnit = isPlayerGoesFirst ? playerUnit : enemyUnit;
            var secondUnit = isPlayerGoesFirst ? enemyUnit : playerUnit;
            //用俩个变量来保存先出手的角色和后出手的角色（为什么要这么做：因为储存了当前的俩个角色，在之后判定异常状态和出手的时候会避免了角色死亡等情况导致的BUG。）
            var secondPokeX = secondUnit.PokeX;//用来储存第二次出手的PokeX，如果第一次出手导致它死亡的话，则跳过第二次出手的回合。

            //回合的第一次出手
            yield return RunSkill(firstUnit, secondUnit, firstUnit.PokeX.currentSkill);
            yield return RunAfterTurn(firstUnit);
            if (battleState == BattleStates.BattleOver) yield break;//如果战斗没有结束，再进行第二次出手

            if(secondPokeX.CurrentHP > 0)//如果第二次出手的PokeX死亡，并且换上了一只新的PokeX，战斗还没有结束，但是跳过这次出手回合。反之就第二次出手。
            {
                //回合的第二次出手
                yield return RunSkill(secondUnit, firstUnit, secondUnit.PokeX.currentSkill);
                yield return RunAfterTurn(secondUnit);
                if (battleState == BattleStates.BattleOver) yield break;
            }


        }
        else
        {
            if(playerAction == BattleAction.SwitchPokeX)//如果这一回合玩家切换了PokeX，切换PokeX后 敌人直接使用一次技能。
            {
                var selectedPokeX = playerPokeParty.pokeGirls[currentPartyMember];
                battleState = BattleStates.Busy;
                yield return SwitchPokeX(selectedPokeX);
            }

            var enemySkill = enemyUnit.PokeX.GetRandomSkill();
            yield return RunSkill(enemyUnit, playerUnit, enemySkill);
            yield return RunAfterTurn(enemyUnit);
            if (battleState == BattleStates.BattleOver) yield break;
        }


        if(battleState != BattleStates.BattleOver)
        {
            ActionSelection();
        }

    }
    //已弃用 ——玩家使用技能回合的逻辑已经迁移到了 RunTurn 方法中
    //IEnumerator PlayerUsingSkill()//处理玩家使用技能回合。
    //{
    //    battleState = BattleStates.RunningTurn;//将回合状态设为Busy，防止快速点击会重复使用技能。
    //    var skill = playerUnit.PokeX.Skills[currentSkill];//传入玩家选择的技能。
    //    yield return StartCoroutine(RunSkill(playerUnit, enemyUnit, skill));
    //    if (battleState == BattleStates.RunningTurn)
    //    {
    //        StartCoroutine(EnemyUsingSkill());//如果没死亡，下一回合是敌人的回合。
    //    }
    //}
    //已弃用 ——玩家使用技能回合的逻辑已经迁移到了 RunTurn 方法中

    IEnumerator RunSkill(BattleUnit sourceUnit, BattleUnit targetUnit, Skill skill)//用来处理技能释放的相关逻辑
    {
        bool canRunSkill = sourceUnit.PokeX.OnBeforeUseSkill();//回合开始之前，判断PokeX这回合是否能够出手（没有被眩晕 麻痹 冻结等）

        if (!canRunSkill)//如果是false，直接跳出，True的话才继续往下走。
        {
            yield return ShowStatusChangesMessage(sourceUnit.PokeX);
            sourceUnit.HUD.UpdateHP(sourceUnit.PokeX);//有时会有在出手前减少玩家血量的Debuff,所以在跳出前更新一下血量。
            yield break;
        }
        yield return ShowStatusChangesMessage(sourceUnit.PokeX);//播放异常状态的文字

        skill.PP--;

        battleDialogBox.SetDiologText($"{sourceUnit.PokeX.Base.Name} use {skill._base.Name}!");
        yield return new WaitForSeconds(0.5f);
        sourceUnit.PlayerAttackAnimation();//播放动画


        if (CheckIfSkillHits(skill, sourceUnit.PokeX, targetUnit.PokeX))//击中前处理是否命中，命中的话才播放受击动画
        {
            yield return new WaitForSeconds(0.25f);
            targetUnit.PlayerHitAnimation();//播放动画
            if (skill._base.SkillCategory == SkillCategory.StatusChange)
            {
                yield return RunSkillEffects(skill._base.SkillEffects, sourceUnit.PokeX, targetUnit.PokeX,skill._base.SkillTarget);//如果技能是属性改变类别，则计算改变了什么属性
            }
            else
            {
                yield return new WaitForSeconds(1.5f);
                DamageDetails damageDetails = targetUnit.PokeX.ReciveDamage(sourceUnit.PokeX,skill);//传入玩家这次攻击所包含的特效
                yield return ShowDamageDetail(damageDetails);
                targetUnit.HUD.SetData(targetUnit.PokeX);//更新对手的血条等UI
            }

            if(skill._base.SecondaryEffects != null && skill._base.SecondaryEffects.Count > 0 && targetUnit.PokeX.CurrentHP > 0)//用来实现技能带特殊效果（如攻击后烧伤等）
            {
                foreach(var secondaryEffects in skill._base.SecondaryEffects)
                {
                    var accrary = UnityEngine.Random.Range(1, 101);
                    if(accrary <= secondaryEffects.Chance)//是否命中
                    {
                        yield return RunSkillEffects(secondaryEffects, sourceUnit.PokeX, targetUnit.PokeX,skill._base.SkillTarget);//命中的话，就运行skilleffects方法来上BUFF。
                    }
                }
            }


            if (targetUnit.PokeX.CurrentHP <= 0)//处理对手死亡的事件
            {
                battleDialogBox.SetDiologText("You Win");
                targetUnit.PlayerDeadAnimation();

                yield return new WaitForSeconds(2f);

                CheckForBattleOver(targetUnit);
            }
        }
        else
        {
            yield return battleDialogBox.TypeDialog($"{sourceUnit.PokeX.Base.Name}'s attack is miss");//如果Miss了，就显示这段文字。
            yield return new WaitForSeconds(0.5f);

        }



    }

    IEnumerator RunSkillEffects(SkillEffects effects,PokeGirl Source,PokeGirl target,SkillTarget skillTarget)//用来实现技能特效
    {
        //属性提升/属性下降赋予↓
        if (effects.StateBoostList != null)
        {
            if (skillTarget == SkillTarget.Self)
            {
                Source.ApplyBoost(effects.StateBoostList);
            }
            else
            {
                target.ApplyBoost(effects.StateBoostList);
            }
        }
        //属性提升/属性下降赋予↑
        //异常状态赋予↓
        if (effects.Status != ConditionID.none)
        {
            target.SetStatus(effects.Status);
        }
        //异常状态赋予↑
        //不稳定状态赋予↓
        if (effects.VolatileStatus != ConditionID.none)
        {
            target.SetVolatailStatus(effects.VolatileStatus);
        }
        //不稳定状态赋予↑
        yield return ShowStatusChangesMessage(Source);
        yield return ShowStatusChangesMessage(target);
    }

    void BattleOver(bool won)//检测战斗是否结束。
    {
        battleState = BattleStates.BattleOver;
        playerPokeParty.pokeGirls.ForEach(p => p.onBattleOver());
        OnBattleOver(won);
    }

    bool CheckIfSkillHits(Skill skill,PokeGirl source,PokeGirl target)//用来处理技能是否命中的相关逻辑
    {
        if(skill._base.AlwaysAccuracy == true)//如果技能为必中，直接返回击中，不再进行下面的判断
        {
            return true;
        }

        float skillAccracy = skill._base.Accuracy;//技能的基础命中概率

        int boostAccracy = source.StateBoosts[State.Accuracy];//提升/降低系数
        int boostEvasion = target.StateBoosts[State.Evasion];//提升/降低系数

        var boostValues = new float[]{ 0f,10f,20f,30f,40f,50f,60f}; //正负0%~60%的概率加成和闪避加成

        if(boostAccracy > 0)//命中加成
        {
            skillAccracy += boostValues[boostAccracy];
        }else if(boostAccracy < 0)
        {
            skillAccracy -= boostValues[Math.Abs(boostAccracy)];
        }

        if(boostEvasion > 0)//闪避加成
        {
            skillAccracy -= boostValues[boostEvasion];
        }else if(boostEvasion < 0)
        {
            skillAccracy += boostValues[Math.Abs(boostEvasion)];
        }

        return UnityEngine.Random.Range(1, 101) <= skillAccracy;//如果随机概率在命中概率内，返回命中，否则不命中
    }

    //显示有关状态变化（属性上升/下降/异常状态）的对话框文字
    IEnumerator ShowStatusChangesMessage(PokeGirl pokeX)
    {
        while (pokeX.StatusChanges.Count > 0)
        {
            var temp = pokeX.StatusChanges.Dequeue();
            battleDialogBox.SetDiologText(temp);
            yield return new WaitForSeconds(1f);
        }
    }

    void CheckForBattleOver(BattleUnit DeadUnit)
    {
        if (DeadUnit.IsPlayerUnit)
        {
            //玩家单位死亡后的逻辑
            var nextPokeX = playerPokeParty.GetHealthyParty();//检查是否还有健康的角色，是就打开选队页面，否就结束战斗。
            if (nextPokeX != null)
            {
                OpenPartyScreen();
            }
            else
            {
                BattleOver(false);
            }

        }
        else
        {
            //敌方单位死亡后的逻辑
            BattleOver(true);
        }
    }

    IEnumerator SwitchPokeX(PokeGirl newPokeX)//切换PokeX相关逻辑
    {
        if(playerUnit.PokeX.CurrentHP > 0)
        {

        StartCoroutine(battleDialogBox.TypeDialog("Come back!"));
        playerUnit.PlayerDeadAnimation();
        yield return new WaitForSeconds(2f);
        }


        playerUnit.SetUp(newPokeX);
        StartCoroutine(battleDialogBox.TypeDialog("go!"));
        battleDialogBox.UpdateSkillName(playerUnit.PokeX.Skills);
        currentSkill = 0;//将当前技能的选项调到0，不然可能出现选择了一个其他PokeX没有的技能栏然后出现BUG
        yield return new WaitForSeconds(1f);

        battleState = BattleStates.RunningTurn;

    }

    IEnumerator RunAfterTurn(BattleUnit sourceUnit)
    {
        if (battleState == BattleStates.BattleOver) yield break;
        yield return new WaitUntil(() => battleState == BattleStates.RunningTurn);
        //中毒 烧伤等异常状态将会在回合结束后减少PokeX的血量
        sourceUnit.PokeX.OnAfterTurn();
        yield return ShowStatusChangesMessage(sourceUnit.PokeX);
        sourceUnit.HUD.UpdateHP(sourceUnit.PokeX);
        if (sourceUnit.PokeX.CurrentHP <= 0)//处理对手死亡的事件
        {
            battleDialogBox.SetDiologText($"{sourceUnit.PokeX.Base.Name}'s dead");
            sourceUnit.PlayerDeadAnimation();

            yield return new WaitForSeconds(2f);

            CheckForBattleOver(sourceUnit);
        }
    }

    public void SetUnit()//初始化双方的Unit，将玩家的Unit设为队伍中排前面的最健康的PokeX
    {
        playerUnit.SetUp(playerPokeParty.GetHealthyParty());
        playerUnit.HUD.SetData(playerUnit.PokeX);
        enemyUnit.SetUp(wildPokeX);//野生的PokeX出现了
        enemyUnit.HUD.SetData(enemyUnit.PokeX);
            
    }
    //public void UpdatePlayerUI(PokeGirl pokeX)//更新玩家UI栏
    //{
    //    playerNameHUD.text = pokeX.Base.Name;
    //    playerlvHUD.text = "Lv: " + pokeX.Level.ToString();
    //    playerHP.text = pokeX.CurrentHP.ToString() + "/" + pokeX.MaxHP.ToString();
    //    PlayerHPS.value = pokeX.CurrentHP / pokeX.MaxHP;
    //    PlayerHPS.value = pokeX.CurrentHP / (float)pokeX.MaxHP;

    //}

    //public void UpdateEnemyUI(PokeGirl pokeX)//更新敌人UI栏
    //{
    //    enemyNameHUD.text = pokeX.Base.Name;
    //    enemylvHUD.text = "Lv: " + pokeX.Level.ToString();
    //    enemyHP.text = pokeX.CurrentHP.ToString() + "/" + pokeX.MaxHP.ToString();
    //    enemyHPS.value = pokeX.CurrentHP / pokeX.MaxHP;
    //    enemyHPS.value = pokeX.CurrentHP / (float)pokeX.MaxHP;
    //}
}
