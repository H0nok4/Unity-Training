﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Character : MonoBehaviour
{
    CharacterAnimator animator;

    public float moveSpeed = 5.0f;

    public bool isMoveing { get; private set; }
    private void Awake()//初始化animator为当前组件
    {
        animator = GetComponent<CharacterAnimator>();
    }


    public IEnumerator Move(Vector2 moveVector,Action onMoveOver = null)//移动迭代器//传入一个Action,当不同的Action传入时可以实现不同的功能
    {
        animator.moveX =Mathf.Clamp(moveVector.x,-1f,1f);//播放动画所需要的的变量
        animator.moveY =Mathf.Clamp(moveVector.y,-1f,1f);//播放动画所需要的的变量

        var targetPosition = transform.position;//先将TargetPosition设为当前的位置
        targetPosition.x += moveVector.x;//
        targetPosition.y += moveVector.y;//通过玩家输入的方向，改变TargetPosition的位置。

        if (!IsPathClear(targetPosition))
            yield break;

        isMoveing = true;
        while ((targetPosition - transform.position).sqrMagnitude > Mathf.Epsilon)//特殊函数，如果位置改变了，就移动。
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);//将玩家移动过去。
            yield return null;
        }
        transform.position = targetPosition;

        isMoveing = false;

        onMoveOver?.Invoke();//在移动结束时，调用传入的Action，实现它的方法。
    }

    public void HandleUpdate()//将管理动画的IsWalked设为目前的移动状态，以便正常播放动画。
    {
        animator.isWalked = isMoveing;
    }

    public bool IsPathClear(Vector3 targetPos)
    {
        var diff = targetPos - transform.position;
        var dir = diff.normalized;//diff是从当前位置指向目标位置的向量，Dir是归一化的向量，视作方向
        if(Physics2D.BoxCast(transform.position + dir,new Vector2(0.2f, 0.2f),0f,dir,diff.magnitude - 1, (GameLayers.instance.solidObjectsLayer | GameLayers.instance.interactableLayer | GameLayers.instance.player)) == true)
        {
            return false;//BoxCast会创建一个BOX形状的Object，检测它所经过的区域是否都是可行动区域，如果不是，则返回False，是的话返回True
        }
        return true;

    }
    public bool IsWalkable(Vector3 targetPosition)//移动前需要判断目标地点是否是可以移动的
    {
        if (Physics2D.OverlapCircle(targetPosition, 0.1f, GameLayers.instance.solidObjectsLayer | GameLayers.instance.interactableLayer ) != null)//检测目标地点是否可以移动，solidObjectLayer是不可移动的Layer
        {
            return false;
        }
        return true;
    }

    public CharacterAnimator Animator//让别的变量可以调用动画管理器
    {
        get => animator;
    }


    public void LookTowards(Vector3 targetPosition)
    {
        var xDiff = Mathf.Floor(targetPosition.x) - Mathf.Floor(transform.position.x);//
        var yDiff = Mathf.Floor(targetPosition.y) - Mathf.Floor(transform.position.y);//x和yDiff都是用来检测传入参数的坐标与当前NPC的坐标的差别。

        if(xDiff == 0||yDiff == 0)//如果有一个等于0，说明玩家在NPC的正上，正左，正右，正下任意一方，调整当前的动画为朝向玩家方向
        {
            animator.moveX = Mathf.Clamp(xDiff, -1f, 1f);//播放动画所需要的的变量
            animator.moveY = Mathf.Clamp(yDiff, -1f, 1f);//播放动画所需要的的变量
        }
        else//如果不是，输入的坐标就不合法，返回一个错误。
        {
            Debug.Log("输入了一个不合法的位置来确认NPC的朝向。");
        }
    }
}

