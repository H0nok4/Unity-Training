﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterAnimator : MonoBehaviour//角色自定义动画播放器
{
    //这里用来储存所需要的sprite List，对应不同的自定义动画。
    [SerializeField] List<Sprite> walkDownSprites;
    [SerializeField] List<Sprite> walkUpSprites;
    [SerializeField] List<Sprite> walkLeftSprites;
    [SerializeField] List<Sprite> walkRightSprites;

    //
    public float moveX { get; set; }
    public float moveY { get; set; }

    public bool isWalked { get; set; }

    public bool prvIsWalked;

    //这里储存着不同种类的自定义动画
    SpriteAnimator walkDownAnim;
    SpriteAnimator walkUpAnim;
    SpriteAnimator walkLeftAnim;
    SpriteAnimator walkRightAnim;

    //
    SpriteAnimator currentAnim;//这个变量用来调用目前播放的是哪个动画

    SpriteRenderer spriteRenderer;//播放动画所需要的spriteRenderer组件，播放动画需要用它切换目标的sprite

    private void Start()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();//获取当前物体的sprteRenderer组件。
        //初始化该角色所拥有的各个动画
        walkDownAnim = new SpriteAnimator(walkDownSprites, spriteRenderer);
        walkUpAnim = new SpriteAnimator(walkUpSprites, spriteRenderer);
        walkLeftAnim = new SpriteAnimator(walkLeftSprites, spriteRenderer);
        walkRightAnim = new SpriteAnimator(walkRightSprites, spriteRenderer);

        //
        currentAnim = walkDownAnim;//初始默认的动画设置
    }

    private void Update()
    {
        var prvAnim = currentAnim;//把当前的动画是什么储存起来，用于下面检测动画是否有变动，有变动的话就播放动画

        if (moveX == 1)//moveX和moveY由PlayerController控制，输入Vertical和Horizontal上的值对应了moveX和moveY
            currentAnim = walkRightAnim;
        else if (moveX == -1)
            currentAnim = walkLeftAnim;
        else if (moveY == 1)
            currentAnim = walkUpAnim;
        else if (moveY == -1)
            currentAnim = walkDownAnim;

        if(prvAnim != currentAnim || prvIsWalked != isWalked)//检测当前动画/是否行动的变量是否改变，如果改变就初始化动画
        {
            currentAnim.Start();
        }


        if (isWalked)
        {
            currentAnim.HandleUpdate();
        }
        else
        {
            spriteRenderer.sprite = currentAnim.frames[0];
        }

        prvIsWalked = isWalked;//这个变化用于储存现在的行动变量，用于上面检测是否用行动（因为会有小BUG，如果用户一下一下走可能会出现角色不播放动画，导致滑步的出现）
        //出现原因：可能是moveX和moveY没法检测到用户的微小输入，导致没有及时接受PlayerController里面的moveX和moveY，导致动画没法正常播放
        //解决方法，用一个布尔变量，储存每次Update后角色是否移动，因为Playercontroller直接可以控制到CharactorAnimator的isWalk变量，所以如果每次Walk变动，储存下来的变量和下一次更新的walk会不一样。
    }
}
