﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

//这个脚本中处理在地图中玩家的移动
//这个角色移动是Tile地图的，按格子移动。
public class PlayerController : MonoBehaviour
{

    private Vector2 inPut;

    private Character character;

    public event Action OnEncountered;

    private void Awake()//初始化动画
    {
        character = GetComponent<Character>();
    }
    public void HandleUpdate()
    {


        if (!character.isMoveing)//如果现在没有在移动中
        {

            inPut.x = Input.GetAxisRaw("Horizontal");//获取X的方向
            inPut.y = Input.GetAxisRaw("Vertical");//获取Y的方向

            if (inPut.x != 0) inPut.y = 0;//禁止X和Y一起走，当X不为0时，将Y设为0

            if (inPut != Vector2.zero)//输入的不是一个空值，开始行走。
            {

                StartCoroutine(character.Move(inPut,ChackForBattle));//传入Move的一个参数是输入的inPut变量，input的Xy分别是vertical和Horizontal的参数，用来在Move方法中判断上下左右移动的方向
                                                                     //第二个参数是一个Action方法，传入后在Move结束时，会调用这个方法。
            }
        }

        character.HandleUpdate();

        if (Input.GetKeyDown(KeyCode.Return))
        {
            interact();
        }
    }
    /*移动协程被移动到了Character类中，以便复用在其他地方
    IEnumerator Move(Vector3 targetPosition)//移动迭代器
    {
        isMove = true;
        while((targetPosition - transform.position).sqrMagnitude > Mathf.Epsilon)//特殊函数，如果位置改变了，就移动。
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);//将玩家移动过去。
            yield return null;
        }
        transform.position = targetPosition;
        isMove = false;

        ChackForBattle();//这个函数用来触发战斗
    }
    */

    /*判断Move是否可以移动的方法，已经移动到Character以便复用
    public bool IsWalkable(Vector3 targetPosition)
    {
        if(Physics2D.OverlapCircle(targetPosition,0.1f,solidObjectsLayer | interactableLayer) == null)//检测目标地点是否可以移动，solidObjectLayer是不可移动的Layer
        {
            return true;
        }
        return false;
    }
    */
    void interact()//与可互动的物品等互动
    {
        var faceDir = new Vector3(character.Animator.moveX, character.Animator.moveY);
        var interactPosition = transform.position + faceDir;//获取角色面对的方向的前方一格坐标的东西

        //Debug.DrawLine(transform.position, interactPosition,Color.red,0.5f);

        var collider = Physics2D.OverlapCircle(interactPosition, 0.3f, GameLayers.instance.interactableLayer);//用OverlapCircle检测前方一格的东西是可互动层，调用接口方法interac()开始互动。
        if(collider != null)
        {
            collider.GetComponent<Interactable>()?.Interac(transform);//用接口方法，只要继承了接口的类都可以直接调用他的方法（目前理解的，大概是这样）
        }
    }

    public void ChackForBattle()
    {
        if (Physics2D.OverlapCircle(transform.position, 0.1f, GameLayers.instance.grassLayer) != null)
        {
            if(UnityEngine.Random.Range(1,101) <= 10)//每走一步有10%的概率碰上战斗。
            {
                character.Animator.isWalked = false;
                OnEncountered();
            }
        }
    }

}

