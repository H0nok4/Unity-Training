﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class DialogManager : MonoBehaviour
{
    [SerializeField] GameObject dialogGO;
    [SerializeField] TMP_Text DialogText;

    public event Action onShowDialog;//事件 → 显示对话框
    public event Action onCloseDialog;//时间 → 关闭对话框
    Action onDialogFinished;

    Dialog dialog;//对话框所需要的各种信息
    public static DialogManager instance { get; private set; }//单例模式

    int currentLine = 0;

    public bool isShowing { get; private set; }

    bool isTypingDialogText = false;

    private void Awake()
    {
        instance = this;//单例模式
    }
    public IEnumerator ShowDialog(Dialog dialog,Action onFinished = null)//迭代器 → 显示对话框
    {
        yield return new WaitForEndOfFrame();
        this.dialog = dialog;

        onShowDialog?.Invoke();//显示对话框

        onDialogFinished = onFinished;//Action委托，处理对话框关闭时的动作

        isShowing = true;
        dialogGO.SetActive(true);
        StartCoroutine(TypeDialog(dialog.Lines[0]));


    }

    public IEnumerator TypeDialog(string line)//迭代器，用来一个字一个字的显示文字。
    {
        isTypingDialogText = true;
        DialogText.text = "";
        foreach (char i in line.ToCharArray())
        {
            DialogText.text += i;
            yield return new WaitForSeconds(1f / 60);// 1f/60为显示速度，1/60秒显示一个文字。
        }
        isTypingDialogText = false;

    }

    public void HandleUpdate()//在显示对话框时所可以做的操作
    {

        if (Input.GetKeyDown(KeyCode.Return) && isTypingDialogText == false)//当文字都显示完时，回车可以进行下一页
        {
            ++currentLine;
            if(currentLine < dialog.Lines.Count)
            {
                StartCoroutine(TypeDialog(dialog.Lines[currentLine]));
            }
            else//如果对话显示完了，关闭对话框，并用事件触发GameManager，改变当前游戏状态为可行走。
            {
                isShowing = false;
                currentLine = 0;
                dialogGO.SetActive(false);
                onDialogFinished?.Invoke();//当对话框结束时，使NPC变得可行走
                onCloseDialog?.Invoke();//当关闭对话框时，使玩家变得可行走
            }
        }
    }
}
