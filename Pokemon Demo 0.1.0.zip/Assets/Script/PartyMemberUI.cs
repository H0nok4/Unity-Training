﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class PartyMemberUI : MonoBehaviour
{
    [SerializeField] TMP_Text nameText;
    [SerializeField] TMP_Text levelText;
    [SerializeField] Slider HPSlider;
    [SerializeField] TMP_Text HPtext;

    PokeGirl _pokeX;

    [SerializeField] Color highLightMemberColor;

    
    public void SetData(PokeGirl pokeX)
    {
        _pokeX = pokeX;
        nameText.text = pokeX.Base.Name;
        levelText.text = "Lvl: " + pokeX.Level.ToString();
        HPSlider.value = pokeX.CurrentHP / (float)pokeX.MaxHP;
        HPtext.text = pokeX.CurrentHP.ToString() + "/" + pokeX.MaxHP.ToString();

    }

    public void HighLightMember(bool isCurrentMember)
    {
        if(isCurrentMember == true)
        {
            nameText.color = highLightMemberColor;
        }
        else
        {
            nameText.color = Color.black;
        }
    }
}
