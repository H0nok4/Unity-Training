﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BattleHud : MonoBehaviour
{
    public TMP_Text nameHUD;//UI名字
    public TMP_Text lvHUD;//等级
    public TMP_Text playerHP;//UI血量栏
    public Slider PlayerHPS;//血条
    public TMP_Text statusText;

    public Color poisonColor;
    public Color burnColor;
    public Color freezeColor;
    public Color sleepColor;
    public Color paralyzeColor;

    public Dictionary<ConditionID, Color> statusColor;
    public PokeGirl pokeX;

    public void SetData(PokeGirl _pokeX)//初始化属性
    {
        pokeX = _pokeX;
        nameHUD.text = _pokeX.Base.Name;
        lvHUD.text = "lv:" + _pokeX.Level.ToString();
        
        playerHP.text = _pokeX.CurrentHP.ToString() + "/" + _pokeX.MaxHP.ToString();
        PlayerHPS.value = _pokeX.CurrentHP / (float)_pokeX.MaxHP;

        statusColor = new Dictionary<ConditionID, Color>()//储存了不同异常状态的颜色，用于显示在BattleHUD上
        {
            {ConditionID.poison,poisonColor},
            {ConditionID.burn,burnColor},
            {ConditionID.freeze,freezeColor},
            {ConditionID.sleep,sleepColor},
            {ConditionID.paralyze,paralyzeColor}
        };


        SetStatusText();
        _pokeX.OnStatusChanged += SetStatusText;
    }

    public void UpdateHP(PokeGirl _pokeX)//更新UI生命值
    {
        if(_pokeX.HPchanged == true)
        {
            playerHP.text = _pokeX.CurrentHP.ToString() + "/" + _pokeX.MaxHP.ToString();
            PlayerHPS.value = _pokeX.CurrentHP / (float)_pokeX.MaxHP;
            _pokeX.HPchanged = false;
        }

    }

    void SetStatusText()//更新异常状态文字在HUB上，可以直观看到。
    {
        if(pokeX.status == null)
        {
            statusText.text = "";
        }
        else
        {
            statusText.text = pokeX.status.statusID.ToString().ToUpper();
            statusText.color = statusColor[pokeX.status.statusID];
        }
    }
}
