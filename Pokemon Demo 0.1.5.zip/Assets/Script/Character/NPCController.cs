﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCController : MonoBehaviour,Interactable//NPC类
{
    [SerializeField] Dialog dialog;

    Character character;

    [SerializeField] List<Vector2> movementPattern;//用来储存移动动作的向量
    [SerializeField] float movementBetweenPattern;//每个移动动作之间的间隔为多少


    NPCState state;//NPC目前的行动状态

    float idleTimer = 0;//待机的时间
    int currentPattern = 0;//目前的移动动作是那个
    private void Awake()
    {
        character = GetComponent<Character>();
    }
    public void Interac(Transform initiator)//继承的接口方法
    {
        if (state == NPCState.Idle) {
            state = NPCState.Dialoging;

            character.LookTowards(initiator.position);//这个方法是调整NPC的朝向为玩家的朝向

            StartCoroutine(DialogManager.instance.ShowDialog(dialog,()=> {
                idleTimer = 0f;
                state = NPCState.Idle;
            }));//显示对话框是，不止要触发对话框，还要用Lambda表达式传入一个匿名Action方法，让NPC停止行动。
        }//如果目前NPC的状态为待机才能对话


    }

    private void Update()
    {
        /*if (DialogManager.instance.isShowing == true) //如果对话框显示中，所有的NPC都不能移动
            return;*/


        if(state == NPCState.Idle)//固定间隔时间移动
        {
            idleTimer += Time.deltaTime;
            if(idleTimer >= movementBetweenPattern)//如果待机时间已经大于移动的间隔
            {
                idleTimer = 0;//将待机经过的时间设为0，然后开始移动
                if (movementPattern.Count > 0)
                {
                    StartCoroutine(Move());//开启移动协程
                }


            }
            
        }

        character.HandleUpdate();//调用这个方法来控制角色的动画正常播放

    }

    IEnumerator Move()//移动协程
    {
        state = NPCState.Walking;//将NPC的状态设置为行走
        var oldPos = transform.position;//记录下目前位置为上一个位置

        yield return StartCoroutine(character.Move(movementPattern[currentPattern]));//移动方法，输入参数是NPC的List<Vector2>，里面储存了每步移动的步骤；

        if (transform.position != oldPos)
        {
            currentPattern = (currentPattern + 1) % movementPattern.Count;//如果NPC的上一个位置与当前位置不同，说明NPC正确的移动了，那么将目前的movePattern切换到下一个。
        }//如果transform.position == oldPos，说明NPC在移动过程中遇到了障碍物，那么我们一直尝试当前的movePattern直到障碍物移除，正确的移动后再切换到下一个


        state = NPCState.Idle;


    }

}

public enum NPCState
{
    Idle,Walking,Dialoging   
}