﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrainerController : MonoBehaviour
{
    [SerializeField] string _trainerName;
    [SerializeField] Sprite _trainerSprite;
    [SerializeField] Dialog dialog;
    [SerializeField] GameObject excalmation;
    [SerializeField] GameObject FovObject;

    Character character;
        

    public Sprite trainerSprite
    {
        get => _trainerSprite;
    }
    public string trainerName
    {
        get => _trainerName;
    }

    private void Awake()
    {
        character = GetComponent<Character>();

    }
    private void Start()
    {
        SetFovDirection(character.Animator.DefaultFaceDirection);
    }

    public IEnumerator TriggerTrainerBattle(PlayerController player)
    {
        //显示出训练师头上的惊叹号，然后再消失，演出一个发现玩家的场景
        excalmation.SetActive(true);
        yield return new WaitForSeconds(0.5f);
        excalmation.SetActive(false);
        //移动到玩家身旁，准备向玩家发起挑战
        var diff = player.transform.position - transform.position;
        var moveVec = diff - diff.normalized;
        moveVec = new Vector2(Mathf.Round(moveVec.x), Mathf.Round(moveVec.y));
       
        yield return character.Move(moveVec);

        //显示对话
        StartCoroutine(DialogManager.instance.ShowDialog(dialog, () => { GameManager.instance.StartTrainerBattle(this); }));


    }

    public void SetFovDirection(FaceDirection faceDirection)//将Trainer用来触发玩家进入视野的碰撞体的方向随着默认朝向而改变
    {
        float angle = 0f;
        if (faceDirection == FaceDirection.Right)
            angle = 90f;
        else if (faceDirection == FaceDirection.Up)
            angle = 180f;
        else if (faceDirection == FaceDirection.Left)
            angle = 270f;

        FovObject.transform.eulerAngles = new Vector3(0f, 0f, angle);
    }
}
