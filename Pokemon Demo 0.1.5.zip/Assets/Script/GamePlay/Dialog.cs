﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Dialog
{
    [SerializeField] List<string> lines;

    public List<string> Lines//对话框所需要的的文字
    {
        get { return lines; }
    }
}
