﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameLayers : MonoBehaviour
{
    //这个类中储存的是游戏中的TileMap的各个Layer，分别可以实现不同的功能

    [SerializeField] LayerMask SolidObjectsLayer;//静态的装饰物等层（无法行走）

    [SerializeField] LayerMask GrassLayer;//可以进入战斗的草层（可行走）

    [SerializeField] LayerMask InteractableLayer;//可交互层（无法行走）

    [SerializeField] LayerMask Player;//玩家层（无法行走）（NPC行走的时候要判定，不然会穿过玩家）

    [SerializeField] LayerMask FovLayer;
    public static GameLayers instance { get; set; }//单例模式
    private void Awake()
    {
        instance = this;
    }
    public LayerMask solidObjectsLayer
    {
        get => SolidObjectsLayer; 
    }

    public LayerMask grassLayer
    {
        get => GrassLayer;
    }

    public LayerMask interactableLayer
    {
        get => InteractableLayer;
    }

    public LayerMask playerLayer
    {
        get => Player;
    }

    public LayerMask fovLayer
    {
        get => FovLayer;
    }
}
