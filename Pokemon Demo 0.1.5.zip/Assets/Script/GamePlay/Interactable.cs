﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface Interactable  //可互动物品/角色/场景的接口
{
    void Interac(Transform initiator);//可互动方法,输入参数：触发者的坐标
}
