﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Condition
{
    public ConditionID statusID { get; set; }//异常状态的名字
    public string Name { get; set; }//异常状态的名字

    public string Description { get; set; }//异常状态的描述

    public string StartMessage { get; set; }//生效时所显示的对话框文字

    public Action<PokeGirl> OnAfterTurn { get; set; }//结束回合时计算伤害等
    //Action委托 适用于没有返回值的方法
    public Func<PokeGirl,bool> OnBeforeSkill { get; set; }//使用技能之前判定
    //在使用技能之前判定的Fuc委托，适用于有参数的方法,传入参数为一个PokeX实例，而返回值是bool变量，BattleManager中会用返回值来判定这一回合是否能出手一类的逻辑
    public Action<PokeGirl> OnStart { get; set; }//开始

}
