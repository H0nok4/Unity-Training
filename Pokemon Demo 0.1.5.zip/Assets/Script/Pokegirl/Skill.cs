﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skill//技能系统
{
    public SkillBase _base { get; set; }
    public int PP { get; set; }

    public Skill(SkillBase pBase)
    {
        _base = pBase;
        PP = pBase.PP;
    }

}
