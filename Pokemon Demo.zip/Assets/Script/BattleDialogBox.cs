﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class BattleDialogBox : MonoBehaviour
{
    //serializeField用来保护变量。
    [SerializeField] TMP_Text DialogText;
    [SerializeField] int TypeDialogSpeed;

    [SerializeField] GameObject skillSelector;
    [SerializeField] GameObject actionSelector;
    [SerializeField] GameObject skillDetail;

    public List<TMP_Text> SkillList;
    public List<TMP_Text> ActionList;

    public TMP_Text ppText;
    public TMP_Text typeText;

    public Color highLightColor;

    public void SetDiologText(string diologText)//调用协程函数来处理一字一字的浮现对话框
    {
        StartCoroutine(TypeDialog(diologText));
    }

    public IEnumerator TypeDialog(string dialog)//携程函数，用来一个字一个字的显示文字。
    {
        DialogText.text = "";
        foreach(char i in dialog)
        {
            DialogText.text += i;
            yield return new WaitForSeconds(1f / 60);// 1f/60为显示速度，1/60秒显示一个文字。
        }
    }
    
    public void UpdateActionSelection(int selectedAction)//来显示玩家现在在处理哪个行动。
    {
        for(int i = 0; i < ActionList.Count; i++)
        {
            if(i == selectedAction)
            {
                ActionList[i].color = highLightColor;
            }
            else
            {
                ActionList[i].color = Color.gray;
            }
        }
    }

    public void UpdateSkillSelection(int selectedSkill,Skill skill)//用来显示玩家现在在处理哪个技能。
    {
        for(int i = 0; i < SkillList.Count; i++)
        {
            if(i == selectedSkill)
            {
                SkillList[i].color = highLightColor;
                
            }
            else
            {
                SkillList[i].color = Color.gray;
            }
        }
        ppText.text = skill._base.PP.ToString();//Pp技能使用次数，考虑删掉。
        typeText.text = skill._base.SkillType.ToString();//显示技能的属性。
    }

    public void UpdateSkillName(List<Skill> skills)//用来更新技能列表中的技能
    {
        for(int i = 0; i < SkillList.Count; ++i)//遍历技能表，将PokeX的技能一一对应的填上去。
        {
            if (i < skills.Count)
            {
                SkillList[i].text = skills[i]._base.Name;
            }
            else
            {
                SkillList[i].text = "-";//没有的技能用 - 代替。
            }
        }
    }
    public void DialogTextEnabled(bool enabled)//显示对话框文字。
    {
        DialogText.enabled = enabled;
    }

    public void ActionSelectorEnabled(bool enabled)//显示行动选择界面
    {
        actionSelector.SetActive(enabled);
    }
    public void SkillSelectorEnabled(bool enabled)//显示技能选择界面。
    {
        skillSelector.SetActive(enabled);
        skillDetail.SetActive(enabled);
    }


}
