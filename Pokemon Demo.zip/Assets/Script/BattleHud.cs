﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BattleHud : MonoBehaviour
{
    public TMP_Text nameHUD;//UI名字
    public TMP_Text lvHUD;//等级
    public TMP_Text playerHP;//UI血量栏
    public Slider PlayerHPS;//血条

    public PokeGirl pokeX;

    public void SetData(PokeGirl _pokeX)//初始化属性
    { 
        nameHUD.text = _pokeX.Base.Name;
        lvHUD.text = "lv:" + _pokeX.Level.ToString();
        
        playerHP.text = _pokeX.CurrentHP.ToString() + "/" + _pokeX.MaxHP.ToString();
        PlayerHPS.value = _pokeX.CurrentHP / (float)_pokeX.MaxHP;
    }

    public void UpdateHP(PokeGirl _pokeX)//更新UI生命值
    {
        if(_pokeX.HPchanged == true)
        {
            playerHP.text = _pokeX.CurrentHP.ToString() + "/" + _pokeX.MaxHP.ToString();
            PlayerHPS.value = _pokeX.CurrentHP / (float)_pokeX.MaxHP;
            _pokeX.HPchanged = false;
        }

    }
}
