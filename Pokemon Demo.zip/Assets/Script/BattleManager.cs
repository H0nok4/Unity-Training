﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;


public enum BattleStates { Start, ActionSelection, SkillSelection, PerformSkill, Busy, BattleOver,PartyScreen};
public class BattleManager : MonoBehaviour
{
    //public BattleState battleState;//有限状态机

    //public GameObject PlayerPrefab;//玩家预设
    //public GameObject EnemyPrefab;//敌人预设

    //public Transform PlayerSpawner;//玩家位置
    //public Transform EnemySpawner;//敌人位置

    //public Unit PlayerUnit;//玩家属性
    //public Unit EnemyUnit;//敌人属性

    //public TMP_Text DiologyTMP;//对话框

    //public TMP_Text enemyNameHUD;//敌人UI名字
    //public TMP_Text enemylvHUD;//敌人等级
    //public TMP_Text playerNameHUD;//玩家名字
    //public TMP_Text playerlvHUD;//玩家等级

    //public TMP_Text playerHP;//玩家UI血量栏
    //public TMP_Text enemyHP;//敌人UI血量栏

    //public Slider PlayerHPS;//玩家血条
    //public Slider enemyHPS;//敌人血条

    //public GameObject PlayerGO;//当前玩家在场的精灵
    //public GameObject EnemyGO;//当前敌人在场的精灵


    //void Start()//初始化
    //{
    //    battleState = BattleState.START;
    //   StartCoroutine(SetUpBattleScence());

    //}

    //IEnumerator SetUpBattleScence()//初始化战斗场景
    //{

    //    PlayerGO = Instantiate(PlayerPrefab, PlayerSpawner);//初始化生成玩家第一个角色
    //    PlayerUnit = PlayerGO.GetComponent<Unit>();//读取玩家的精灵属性
    //    EnemyGO = Instantiate(EnemyPrefab, EnemySpawner);//初始化敌人第一个角色
    //    EnemyUnit = EnemyGO.GetComponent<Unit>();//初始化

    //    DiologyTMP.text = "A Wild " + EnemyUnit.Name + " is apporching!";//对话框显示一句话

    //    UpdateBattleUI();//刷新俩方UI栏，更新血条等

    //    yield return new WaitForSeconds(2f);//等待2秒钟

    //    if(PlayerUnit.speed > EnemyUnit.speed)//比较玩家和敌人的速度，设置第一个回合出手是谁
    //    {
    //        battleState = BattleState.PLAYERTURN;
    //        PlayerTurn();
    //    }

    //}

    //public void UpdateBattleUI()//刷新UI
    //{
    //    enemyNameHUD.text = EnemyUnit.Name;
    //    enemylvHUD.text = "lv: " + EnemyUnit.level.ToString();
    //    playerNameHUD.text = PlayerUnit.Name;
    //    playerlvHUD.text = "lv: " + PlayerUnit.level.ToString();
    //    playerHP.text = PlayerUnit.currentHP.ToString() + "/" + PlayerUnit.maxHP.ToString();
    //    enemyHP.text = EnemyUnit.currentHP.ToString() + "/" + EnemyUnit.maxHP.ToString();

    //    PlayerHPS.maxValue = PlayerUnit.maxHP;
    //    PlayerHPS.value = PlayerUnit.currentHP;

    //    enemyHPS.maxValue = EnemyUnit.maxHP;
    //    enemyHPS.value = EnemyUnit.currentHP;
    //}

    //public void PlayerTurn()
    //{
    //    DiologyTMP.text = "It's Your Turn Choose You Action!";//
    //}

    //IEnumerator EnemyTurn()//敌人回合
    //{
    //    if (battleState == BattleState.ENEMYTURN)//攻击玩家
    //    {
    //        Attack(EnemyUnit, PlayerUnit);
    //        yield return new WaitForSecondsRealtime(1f);
    //        if (PlayerUnit.currentHP <= 0)//如果玩家死亡，切换BattleState为LOSE
    //        {
    //            battleState = BattleState.LOSE;
    //            PlayerLose();
    //        }
    //        else
    //        {
    //            battleState = BattleState.PLAYERTURN;//如果玩家没有死亡，切换到玩家回合
    //            PlayerTurn();
    //        }

    //    }

    //}

    //public void PlayerLose()//战败
    //{
    //    DiologyTMP.text = "You LOOOOOOOOSE!";
    //}

    //public void PlayerWin()//胜利
    //{
    //    DiologyTMP.text = "You Are The Champion!";
    //}

    //public void ClickAttackButton()//玩家选择攻击
    //{
    //    if(battleState == BattleState.PLAYERTURN)
    //    {
    //        StartCoroutine(PlayerAction());
    //    }
    //}

    //IEnumerator PlayerAction()//玩家的动作。
    //{
    //    battleState = BattleState.ENEMYTURN;
    //    Attack(PlayerUnit, EnemyUnit);
    //    yield return new WaitForSecondsRealtime(1f);
    //    if (EnemyUnit.currentHP <= 0)
    //    {
    //        battleState = BattleState.WIN;
    //        PlayerWin();
    //    }
    //    else
    //    {
    //        battleState = BattleState.ENEMYTURN;
    //        StartCoroutine(EnemyTurn());
    //    }
    //}

    //private void Attack(Unit caster,Unit target)//简单的攻击函数，目标的血量减少施法者的攻击。
    //{
    //    DiologyTMP.text = caster.Name + " Attack to " + target.Name;
    //    target.currentHP -= caster.attck;
    //    UpdateBattleUI();
    //}

    [SerializeField] BattleUnit playerUnit;
    [SerializeField] BattleUnit enemyUnit;

    public TMP_Text DiologyTMP;//对话框

    public PartyScreen partyScreen;

    public BattleDialogBox battleDialogBox;//对话框

    public BattleStates battleState;//目前战斗的状态机

    public int currentAction;//当前选择的行动是哪个
    public int currentSkill; //当前选择的行动是哪个
    public int currentPartyMember;

    public event Action<bool> OnBattleOver;//事件，检测战斗开启，用来在GameManager中切换行走状态和战斗状态。

    PokeGirl wildPokeX;//野生的PokeX
    PokeXParty playerPokeParty;//玩家的队伍
    public void StartBattle(PokeXParty PlayerParty,PokeGirl wildPokeX)//初始化战斗场景，将传入的参数设为当前脚本的变量。
    {
        this.playerPokeParty = PlayerParty;
        this.wildPokeX = wildPokeX;

        

        StartCoroutine(BattleStart());//开始迭代器。
    }

    public IEnumerator BattleStart()//迭代器，将目前场景初始化
    {
        
        SetUnit();//将玩家和对手的Unit显示出来。

        partyScreen.Init();

        battleDialogBox.UpdateSkillName(playerUnit.PokeX.Skills);//更新玩家的技能栏
        battleDialogBox.SetDiologText("A Wild " + enemyUnit.PokeX.Base.Name + " is apporching");//显示遇到敌人的文字。
        yield return new WaitForSeconds(2f);


        ChooseFirstTurn();//切换到玩家回合**//第一次更改:使用上了速度属性，比较俩方的速度大小如果玩家的大于等于敌人，玩家先出手，反之先让敌人放技能


    }

    void ChooseFirstTurn()//选择第一个出手的角色
    {
        if (playerUnit.PokeX.Speed >= enemyUnit.PokeX.Speed)
        {
            ActionSelection();
        }
        else
        {
            StartCoroutine(EnemyUsingSkill());
        }
    }

    public void ActionSelection()//玩家回合，等待玩家选择一个动作
    {
        battleState = BattleStates.ActionSelection;//有限状态机
        battleDialogBox.SetDiologText("Choose Your Action!");
        battleDialogBox.ActionSelectorEnabled(true);

    }

    public void SkillSelection()//当玩家使用技能时，切换到目前的状态
    {
        battleState = BattleStates.SkillSelection;//切换状态机状态，调整UI界面。
        battleDialogBox.ActionSelectorEnabled(false);
        battleDialogBox.DialogTextEnabled(false);
        battleDialogBox.SkillSelectorEnabled(true);
        
    }

    IEnumerator EnemyUsingSkill()//敌人的回合，包含简易AI，随机使用一个已有的技能。
    {
        battleState = BattleStates.PerformSkill;

        var enemySkill = enemyUnit.PokeX.GetRandomSkill();//获取一个随机技能
        yield return StartCoroutine(RunSkill(enemyUnit, playerUnit, enemySkill));

        if (battleState == BattleStates.PerformSkill)
        {
            ActionSelection();//如果没有死亡，下一回合切换到玩家的回合。
        }



    }

    public void HandleUpdate()//技能和动作选择栏更新。
    {
        if(battleState == BattleStates.ActionSelection)
        {
            HandleActionSelect();
        }else if(battleState == BattleStates.SkillSelection)
        {
            HandleSkillSelect();
        }
        else if (battleState == BattleStates.PartyScreen)
        {
            HandlePartyScreenSelect();
        }


    }

    public void OpenPartyScreen()//打开队伍列表
    {
        battleState = BattleStates.PartyScreen;
        partyScreen.setPartyData(playerPokeParty.pokeGirls);
        partyScreen.gameObject.SetActive(true);
    }
    private void HandleActionSelect()//处理动作选择栏
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow)) currentAction--;
        else if (Input.GetKeyDown(KeyCode.RightArrow)) currentAction++;
        else if (Input.GetKeyDown(KeyCode.UpArrow)) currentAction -= 2;
        else if (Input.GetKeyDown(KeyCode.DownArrow)) currentAction += 2;

        currentAction = Mathf.Clamp(currentAction, 0, 3);

        battleDialogBox.UpdateActionSelection(currentAction);//每次移动选择栏，更新一次面板

        if (Input.GetKeyDown(KeyCode.Return))//按下回车键，选择动作
        {
            if(currentAction == 0)//选择的相应的动作。
            {
                //fight
                SkillSelection();
            }else if(currentAction == 1)
            {
                //bag
            }else if (currentAction == 2)
            {
                //PokeX
                OpenPartyScreen();
            }
            else
            {
                //Run
            }
        }
    }

    private void HandleSkillSelect()//处理技能选择栏，和动作选择大同小异。
    {
        battleDialogBox.UpdateSkillSelection(currentSkill, playerUnit.PokeX.Skills[currentSkill]) ;//更新玩家的技能栏
        if (Input.GetKeyDown(KeyCode.LeftArrow)) currentSkill--;//上下左右键控制当前是哪个技能
        else if (Input.GetKeyDown(KeyCode.RightArrow)) currentSkill++;
        else if (Input.GetKeyDown(KeyCode.UpArrow)) currentSkill -= 2;
        else if (Input.GetKeyDown(KeyCode.DownArrow)) currentSkill += 2;

        currentSkill = Mathf.Clamp(currentSkill, 0, playerUnit.PokeX.Skills.Count - 1);

        if (Input.GetKeyDown(KeyCode.Return) && battleState == BattleStates.SkillSelection)//玩家按下回车，且现在是玩家选择技能回合，使用当前选择的技能。
        {
            battleDialogBox.DialogTextEnabled(true);
            battleDialogBox.SkillSelectorEnabled(false);
            StartCoroutine(PlayerUsingSkill());
        }else if(Input.GetKeyDown(KeyCode.X) && battleState == BattleStates.SkillSelection)
        {
            battleDialogBox.DialogTextEnabled(true);
            battleDialogBox.SkillSelectorEnabled(false);
            ActionSelection();
        }
    }

    private void HandlePartyScreenSelect()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow)) currentPartyMember--;
        else if (Input.GetKeyDown(KeyCode.RightArrow)) currentPartyMember++;
        else if (Input.GetKeyDown(KeyCode.UpArrow)) currentPartyMember -= 2;
        else if (Input.GetKeyDown(KeyCode.DownArrow)) currentPartyMember += 2;

        currentPartyMember = Mathf.Clamp(currentPartyMember, 0, playerPokeParty.pokeGirls.Count - 1);

        partyScreen.UpdatePartyMember(currentPartyMember);

        if (Input.GetKeyDown(KeyCode.Return))//按下回车键，选择动作
        {
            var selectMember = playerPokeParty.pokeGirls[currentPartyMember];
            if(selectMember.CurrentHP <= 0)
            {
                partyScreen.SetMessageText("You Can't choose a dead PokeX");
                return;
            }
            if(selectMember == playerUnit.PokeX)
            {
                partyScreen.SetMessageText("You can't choose a same PokeX");
                return;
            }

            partyScreen.gameObject.SetActive(false);
            battleState = BattleStates.Busy;
            StartCoroutine(SwitchPokeX(selectMember));

        }else if (Input.GetKeyDown(KeyCode.X))
        {
            partyScreen.gameObject.SetActive(false);
            ActionSelection();
        }
    }
    IEnumerator ShowDamageDetail(DamageDetails damageDetails)//用来处理攻击特效，分别为暴击，效果显著，效果略微。
    {
        if(damageDetails.isCritical > 1f)
        {
            yield return battleDialogBox.TypeDialog("A critical hit!");
            yield return new WaitForSeconds(1f);
        }

        if(damageDetails.isEffect > 1f)
        {
            yield return battleDialogBox.TypeDialog("It's super effective!");
            yield return new WaitForSeconds(1f);
        }else if(damageDetails.isEffect < 1f)
        {
            yield return battleDialogBox.TypeDialog("It's not effective");
            yield return new WaitForSeconds(1f);
        }
    }
    IEnumerator PlayerUsingSkill()//处理玩家使用技能回合。
    {
        battleState = BattleStates.PerformSkill;//将回合状态设为Busy，防止快速点击会重复使用技能。
        var skill = playerUnit.PokeX.Skills[currentSkill];//传入玩家选择的技能。
        yield return StartCoroutine(RunSkill(playerUnit, enemyUnit, skill));
        if (battleState == BattleStates.PerformSkill)
        {
            StartCoroutine(EnemyUsingSkill());//如果没死亡，下一回合是敌人的回合。
        }


    }

    IEnumerator RunSkill(BattleUnit sourceUnit,BattleUnit targetUnit,Skill skill)
    {
        bool canRunSkill = sourceUnit.PokeX.OnBeforeUseSkill();//回合开始之前，判断PokeX这回合是否能够出手（没有被眩晕 麻痹 冻结等）

        if (!canRunSkill)//如果是false，直接跳出，True的话才继续往下走。
        {
            yield return ShowStatusChangesMessage(sourceUnit.PokeX);
            sourceUnit.HUD.UpdateHP(sourceUnit.PokeX);//有时会有在出手前减少玩家血量的Debuff,所以在跳出前更新一下血量。
            yield break;
        }
        yield return ShowStatusChangesMessage(sourceUnit.PokeX);//播放异常状态的文字

        skill.PP--;

        battleDialogBox.SetDiologText($"{sourceUnit.PokeX.Base.Name} use {skill._base.Name}!");
        yield return new WaitForSeconds(0.5f);
        sourceUnit.PlayerAttackAnimation();//播放动画
        yield return new WaitForSeconds(0.25f);
        targetUnit.PlayerHitAnimation();//播放动画
        if(skill._base.SkillCategory == SkillCategory.StatusChange)
        {
            yield return RunSkillEffects(skill, sourceUnit.PokeX, targetUnit.PokeX);
        }
        else
        {
            yield return new WaitForSeconds(1.5f);
            DamageDetails damageDetails = targetUnit.PokeX.ReciveDamage(sourceUnit.PokeX, sourceUnit.PokeX.Skills[currentSkill]);//传入玩家这次攻击所包含的特效
            yield return ShowDamageDetail(damageDetails);
            targetUnit.HUD.SetData(targetUnit.PokeX);//更新对手的血条等UI
        }
        
        
        if (targetUnit.PokeX.CurrentHP <= 0)//处理对手死亡的事件
        {
            battleDialogBox.SetDiologText("You Win");
            targetUnit.PlayerDeadAnimation();

            yield return new WaitForSeconds(2f);

            CheckForBattleOver(targetUnit);
        }
        //中毒 烧伤等异常状态将会在回合结束后减少PokeX的血量
        sourceUnit.PokeX.OnAfterTurn();
        yield return ShowStatusChangesMessage(sourceUnit.PokeX);
        sourceUnit.HUD.UpdateHP(sourceUnit.PokeX);
        if (sourceUnit.PokeX.CurrentHP <= 0)//处理对手死亡的事件
        {
            battleDialogBox.SetDiologText("You Win");
            targetUnit.PlayerDeadAnimation();

            yield return new WaitForSeconds(2f);

            CheckForBattleOver(targetUnit);
        }

    }

    IEnumerator RunSkillEffects(Skill skill,PokeGirl Source,PokeGirl target)
    {
        var effect = skill._base.SkillEffects;
        //属性提升/属性下降赋予↓
        if (effect.StateBoostList != null)
        {
            if (skill._base.SkillTarget == SkillTarget.Self)
            {
                Source.ApplyBoost(effect.StateBoostList);
            }
            else
            {
                target.ApplyBoost(effect.StateBoostList);
            }
        }
        //属性提升/属性下降赋予↑
        //异常状态赋予↓
        if (effect.Status != ConditionID.none)
        {
            target.SetStatus(effect.Status);
        }
        //异常状态赋予↑
        //不稳定状态赋予↓
        if (effect.VolatileStatus != ConditionID.none)
        {
            target.SetVolatailStatus(effect.VolatileStatus);
        }
        //不稳定状态赋予↑
        yield return ShowStatusChangesMessage(Source);
        yield return ShowStatusChangesMessage(target);
    }

    void BattleOver(bool won)//检测战斗是否结束。
    {
        battleState = BattleStates.BattleOver;
        playerPokeParty.pokeGirls.ForEach(p => p.onBattleOver());
        OnBattleOver(won);
    }

    //显示有关状态变化（属性上升/下降/异常状态）的对话框文字
    IEnumerator ShowStatusChangesMessage(PokeGirl pokeX)
    {
        while (pokeX.StatusChanges.Count > 0)
        {
            var temp = pokeX.StatusChanges.Dequeue();
            battleDialogBox.SetDiologText(temp);
            yield return new WaitForSeconds(1f);
        }
    }

    void CheckForBattleOver(BattleUnit DeadUnit)
    {
        if (DeadUnit.IsPlayerUnit)
        {
            //玩家单位死亡后的逻辑
            var nextPokeX = playerPokeParty.GetHealthyParty();//检查是否还有健康的角色，是就打开选队页面，否就结束战斗。
            if (nextPokeX != null)
            {
                OpenPartyScreen();
            }
            else
            {
                BattleOver(false);
            }

        }
        else
        {
            //敌方单位死亡后的逻辑
            BattleOver(true);
        }
    }

    IEnumerator SwitchPokeX(PokeGirl newPokeX)//切换PokeX
    {
        bool currentPokeXDead = true;
        if(playerUnit.PokeX.CurrentHP > 0)
        {
            currentPokeXDead = false;
        battleDialogBox.SetDiologText("Come back!");
        playerUnit.PlayerDeadAnimation();
        yield return new WaitForSeconds(2f);
        }


        playerUnit.SetUp(newPokeX);
        battleDialogBox.SetDiologText("go!");
        battleDialogBox.UpdateSkillName(playerUnit.PokeX.Skills);

        yield return new WaitForSeconds(1f);
        if (currentPokeXDead)
        {
            ChooseFirstTurn();
        }
        else
        {
            StartCoroutine(EnemyUsingSkill());
        }

    }


    public void SetUnit()//初始化双方的Unit，将玩家的Unit设为队伍中排前面的最健康的PokeX
    {
        playerUnit.SetUp(playerPokeParty.GetHealthyParty());
        playerUnit.HUD.SetData(playerUnit.PokeX);
        enemyUnit.SetUp(wildPokeX);//野生的PokeX出现了
        enemyUnit.HUD.SetData(enemyUnit.PokeX);
            
    }
    //public void UpdatePlayerUI(PokeGirl pokeX)//更新玩家UI栏
    //{
    //    playerNameHUD.text = pokeX.Base.Name;
    //    playerlvHUD.text = "Lv: " + pokeX.Level.ToString();
    //    playerHP.text = pokeX.CurrentHP.ToString() + "/" + pokeX.MaxHP.ToString();
    //    PlayerHPS.value = pokeX.CurrentHP / pokeX.MaxHP;
    //    PlayerHPS.value = pokeX.CurrentHP / (float)pokeX.MaxHP;

    //}

    //public void UpdateEnemyUI(PokeGirl pokeX)//更新敌人UI栏
    //{
    //    enemyNameHUD.text = pokeX.Base.Name;
    //    enemylvHUD.text = "Lv: " + pokeX.Level.ToString();
    //    enemyHP.text = pokeX.CurrentHP.ToString() + "/" + pokeX.MaxHP.ToString();
    //    enemyHPS.value = pokeX.CurrentHP / pokeX.MaxHP;
    //    enemyHPS.value = pokeX.CurrentHP / (float)pokeX.MaxHP;
    //}
}
