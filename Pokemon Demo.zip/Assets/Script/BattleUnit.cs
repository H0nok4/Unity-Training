﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
//这里用上了一个特殊库DG.Tweening用来处理动画
public class BattleUnit : MonoBehaviour
{

    [SerializeField] bool isPlayerUnit;//是否为玩家单位。
    [SerializeField] BattleHud hud;

    public BattleHud HUD
    {
        get { return hud; }
    }

    public bool IsPlayerUnit
    {
        get { return isPlayerUnit; }
    }


    public PokeGirl PokeX;

    Image image;
    Vector3 originPosition;
    Color originColor;

    private void Awake()//初始化，用来处理动画。
    {
        image = GetComponent<Image>();
        originPosition = image.transform.localPosition;//记录起始位置
        originColor = image.color;
    }
    public void SetUp(PokeGirl pokeX)//将玩家图片和属性显示出来。
    {
        PokeX = pokeX;
        image.sprite = PokeX.Base.Sprite;
        image.color = originColor;

        hud.SetData(pokeX);

        PlayerEnterAnimation();


    }

    public void PlayerEnterAnimation()//播放进场动画
    {
        if (isPlayerUnit)
        {
            image.transform.localPosition = new Vector3(-1088, originPosition.y);
        }
        else
        {
            image.transform.localPosition = new Vector3(1082, originPosition.y);
        }

        image.transform.DOLocalMoveX(originPosition.x,1f);
        
    }

    public void PlayerAttackAnimation()//播放攻击动画
    {
        var sequence = DOTween.Sequence();
        if (isPlayerUnit)
        {
           sequence.Append(image.transform.DOLocalMoveX(originPosition.x + 50, 0.25f));
        }
        else
        {
            sequence.Append(image.transform.DOLocalMoveX(originPosition.x - 50, 0.25f));
        }

        sequence.Append(image.transform.DOLocalMoveX(originPosition.x, 0.25f));
    }

    public void PlayerHitAnimation()//播放被攻击的动画
    {
        var sequence = DOTween.Sequence();
        sequence.Append(image.DOColor(Color.gray, 0.1f));
        sequence.Append(image.DOColor(originColor, 0.1f));
    }

    public void PlayerDeadAnimation()//播放死亡动画
    {
        var sequence = DOTween.Sequence();
        sequence.Append(image.transform.DOLocalMoveY(originPosition.y - 50f, 1f));
        sequence.Join(image.DOFade(0f, 1f));
    }

}
