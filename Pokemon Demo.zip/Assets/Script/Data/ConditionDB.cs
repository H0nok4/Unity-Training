﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConditionDB
{
    public static Dictionary<ConditionID, Condition> Conditions { get; set; } = new Dictionary<ConditionID, Condition>()//异常状态字典
    {
        {ConditionID.poison,//中毒状态
        new Condition()
        {
            Name = "Poison",
            StartMessage = "has been poisoned",
            OnAfterTurn = (PokeGirl pokeX) =>//lamba表达式，生效时的动作等
            {
                pokeX.UpdateHP(pokeX.MaxHP / 8);
                pokeX.StatusChanges.Enqueue($"{pokeX.Base.Name} hurt itself due to poison");
            }
        }
        },
        {ConditionID.burn,//烧伤状态
        new Condition()
        {
            Name = "Burn",
            StartMessage = "has been burned",
            OnAfterTurn = (PokeGirl pokeX) =>//lamba表达式，生效时的动作等
            {
                pokeX.UpdateHP(pokeX.MaxHP / 16);
                pokeX.StatusChanges.Enqueue($"{pokeX.Base.Name} hurt itself due to burn");
            }
        }
        },
        {ConditionID.paralyze,//麻痹状态
        new Condition()
        {
            Name = "Paralyze",
            StartMessage = "has been Paralyze",
            OnBeforeSkill = (PokeGirl PokeX) =>
            {
                if(Random.Range(1,5) == 1)//每回合开始之前，25%的几率无法做出行动
                {
                    PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name}'s paralyze and can't move");
                    return false;
                }
                return true;
            }
        }
        },
        {ConditionID.freeze,//冻结状态
        new Condition()
        {
            Name = "Freeze",
            StartMessage = "has been Freezed",
            OnBeforeSkill = (PokeGirl PokeX) =>
            {
                if(Random.Range(1,5) == 1)
                {
                    PokeX.CureStatus();
                    PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name}'s not frozon any more");
                    return true;
                }
                return false;
            }
        }
        },
        {ConditionID.sleep,//冻结状态
        new Condition()
        {
            Name = "Sleep",
            StartMessage = "has fallen asleepy",
            OnStart = (PokeGirl PokeX) =>
            {
                PokeX.statusTimes = Random.Range(1,4);
                Debug.Log($"Will be asleep for {PokeX.statusTimes} turn");
            },
            OnBeforeSkill = (PokeGirl PokeX) =>
            {
                if (PokeX.statusTimes <= 0)
                {
                    PokeX.CureStatus();
                    PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name} is wake up!");
                    return true;
                }

                PokeX.statusTimes--;
                PokeX.StatusChanges.Enqueue($"{PokeX.Base.Name} is sleeping");
                return false;
            }
        }
        }

    };

}

public enum ConditionID
{
    none,poison,burn,sleep,paralyze,freeze
}
