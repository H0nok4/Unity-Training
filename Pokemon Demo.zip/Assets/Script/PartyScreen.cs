﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PartyScreen : MonoBehaviour
{
    [SerializeField] TMP_Text MessageText;

    PartyMemberUI[] memberList;

    List<PokeGirl> pokeXs;

    public void Init()
    {
        memberList = GetComponentsInChildren<PartyMemberUI>();

    }

    public void setPartyData(List<PokeGirl> pokeXs)
    {
        this.pokeXs = pokeXs;
        for(int i = 0; i < memberList.Length; i++)
        {
            if(i < pokeXs.Count)
            {
                memberList[i].SetData(pokeXs[i]);
            }
            else
            {
                memberList[i].gameObject.SetActive(false);
            }
        }

        MessageText.text = "Choose a PokeX";
    }

    public void UpdatePartyMember(int currentPartyMember)
    {
        for(int i  = 0; i < pokeXs.Count; i++)
        {
            if(i == currentPartyMember)
            {
                memberList[i].HighLightMember(true);
            }
            else
            {
                memberList[i].HighLightMember(false);
            }
        }
    }

    public void SetMessageText(string messageText)
    {
        MessageText.text = messageText;
    }
}
