﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

//这个脚本中处理在地图中玩家的移动
//这个角色移动是Tile地图的，按格子移动。
public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5.0f;

    public LayerMask solidObjectsLayer;

    public LayerMask GrassLayer;

    private bool isMove;

    private Vector2 inPut;

    private Animator animator;

    public event Action OnEncountered;

    private void Awake()//初始化动画
    {
        animator = GetComponent<Animator>();
    }
    public void HandleUpdate()
    {


        if (!isMove)//如果现在没有在移动中
        {

            inPut.x = Input.GetAxisRaw("Horizontal");//获取X的方向
            inPut.y = Input.GetAxisRaw("Vertical");//获取Y的方向

            if (inPut.x != 0) inPut.y = 0;//禁止X和Y一起走，当X不为0时，将Y设为0

            if (inPut != Vector2.zero)//输入的不是一个空值，开始行走。
            {
                animator.SetFloat("MoveX", inPut.x);//播放动画所需要的的变量
                animator.SetFloat("MoveY", inPut.y);//播放动画所需要的的变量

                var targetPosition = transform.position;//先将TargetPosition设为当前的位置
                targetPosition.x += inPut.x;//
                targetPosition.y += inPut.y;//通过玩家输入的方向，改变TargetPosition的位置。
                if (IsWalkable(targetPosition))
                {
                    StartCoroutine(Move(targetPosition));//开始迭代器，移动角色到目标地点
                }

            }
        }
        animator.SetBool("isMoving", isMove);//播放行走动画。
    }

    IEnumerator Move(Vector3 targetPosition)//移动迭代器
    {
        isMove = true;
        while((targetPosition - transform.position).sqrMagnitude > Mathf.Epsilon)//特殊函数，如果位置改变了，就移动。
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);//将玩家移动过去。
            yield return null;
        }
        transform.position = targetPosition;
        isMove = false;

        ChackForBattle();//这个函数用来触发战斗
    }

    public bool IsWalkable(Vector3 targetPosition)
    {
        if(Physics2D.OverlapCircle(targetPosition,0.1f,solidObjectsLayer) == null)//检测目标地点是否可以移动，solidObjectLayer是不可移动的Layer
        {
            return true;
        }
        return false;
    }
    
    public void ChackForBattle()
    {
        if (Physics2D.OverlapCircle(transform.position, 0.1f, GrassLayer) != null)
        {
            if(UnityEngine.Random.Range(1,101) <= 10)//每走一步有10%的概率碰上战斗。
            {
                animator.SetBool("isMoving",false);
                OnEncountered();
            }
        }
    }

}

