﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Condition
{
    public ConditionID statusID { get; set; }//异常状态的名字
    public string Name { get; set; }//异常状态的名字

    public string Description { get; set; }//异常状态的描述

    public string StartMessage { get; set; }//生效时所显示的对话框文字

    public Action<PokeGirl> OnAfterTurn { get; set; }//结束回合时计算伤害等

    public Func<PokeGirl,bool> OnBeforeSkill { get; set; }//使用技能之前判定

    public Action<PokeGirl> OnStart { get; set; }//开始

}
