﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
[System.Serializable]
public class PokeGirl
{




    
    public List<Skill> Skills { get; set; }
    public void Init()
    {
       
        //管理PokeX的技能
        Skills = new List<Skill>();
        foreach(var Skill in Base.LearnableSkill)
        {
            if(Skill.Level <= Level)
            {
                Skills.Add(new Skill(Skill.SkillBase));//猜测 SkillBase指的是自己创建的Skill实体
            }

            if(Skills.Count>= 4)
            {
                break;
            }
        }

        CalculateStats();//实例化时，计算各种属性

        CurrentHP = MaxHP;//计算完属性，将CurrentHP设为最大HP

        ResetStateBoost();

        status = null;
        volatileStatus = null;
    }

    void CalculateStats()
    {
        StateDictionary = new Dictionary<State, int>();
        StateDictionary.Add(State.Attack, Mathf.FloorToInt((Base.BaseAttack * Level) / 100f) + 5);
        StateDictionary.Add(State.Defense, Mathf.FloorToInt((Base.BaseDefende * Level) / 100f) + 5);
        StateDictionary.Add(State.SpAttack, Mathf.FloorToInt((Base.SpAttack * Level) / 100f) + 5);
        StateDictionary.Add(State.SpDefense, Mathf.FloorToInt((Base.SpDefende * Level) / 100f) + 5);
        StateDictionary.Add(State.Speed, Mathf.FloorToInt((Base.Speed * Level) / 100f) + 5);

        MaxHP = Mathf.FloorToInt((Base.MaxHp * Level) / 10f) + 10 + Level;
    }

    void ResetStateBoost()
    {
        StateBoosts = new Dictionary<State, int>()
        {
            {State.Attack,0},
            {State.Defense,0},
            {State.SpAttack,0},
            {State.SpDefense,0},
            {State.Speed,0}
        };
    }

    [SerializeField]PokeGirlBase _base;
    [SerializeField]int Pokelevel;
    public Dictionary<State, int> StateDictionary { get; private set; }

    public Dictionary<State, int> StateBoosts { get; private set; }
    public PokeGirlBase Base
    {
        get
        {
            return _base;
        }
    }

    public int Level
    {
        get
        {
            return Pokelevel;
        }
    }   

    int GetState(State state)
    {
        int stateValue = StateDictionary[state];
        int boost = StateBoosts[state];
        var boostsValue = new float[] { 1f, 1.5f, 2f, 2.5f, 3f, 3.5f, 4f };
        //属性提升
        if(boost >= 0)
        {
            stateValue = Mathf.FloorToInt(stateValue * boostsValue[boost]);
        }
        else
        {
            stateValue = Mathf.FloorToInt(stateValue / boostsValue[Mathf.Abs(boost)]);
        }

        return stateValue;

    }
    public int Attack
    {
        get { return GetState(State.Attack); }
    }
    public int Defende
    {
        get { return GetState(State.Defense); }
    }
    public int SpAttack
    {
        get { return GetState(State.SpAttack); }
    }
    public int SpDefende
    {
        get { return GetState(State.SpDefense); }
    }
    public int Speed
    {
        get { return GetState(State.Speed); }
    }
    public int MaxHP
    {
        get;private set;
    }

    public int CurrentHP
    {
        get;set;
    }

    public bool HPchanged = false;



    public Queue<string> StatusChanges { get; private set; } = new Queue<string>();//状态改变的队列，用来逐一显示状态改变文字

    public int statusTimes { get; set; }
    public Condition status { get; private set; }//异常状态如 烧伤 中毒等

    public event Action OnStatusChanged;
    public int volatileStatusTimes { get; set; }
    public Condition volatileStatus { get; private set; }

    public void ApplyBoost(List<StateBoost> statBoosts)//属性提升/下降的技能相关
    {
        foreach(var stateBoost in statBoosts)
        {
            var state = stateBoost.state;
            var boost = stateBoost.boostValue;

            StateBoosts[state] = Mathf.Clamp(StateBoosts[state] + boost,-6,6);//最多只能提升6级和降低6级

            if (boost > 0)
            {
                StatusChanges.Enqueue($"{Base.Name}'s {state} rise!");
            }
            else
            {
                StatusChanges.Enqueue($"{Base.Name}'s {state} down!");
            }

            Debug.Log($"{state} has been boosted to {StateBoosts[state]}!");
        }
    }

    public DamageDetails ReciveDamage(PokeGirl attacker,Skill skill)//处理被攻击的掉血操作。
    {
        float critical = 1;//攻击系数
        if(UnityEngine.Random.value * 100f <= 6)//暴击几率。0.06
        {
            critical = 2;//双倍伤害。
        }
        float typeEffect = TypeChart.GetEffectiness(skill._base.SkillType, this.Base.Type);//属性伤害倍数。
        var damageDetail = new DamageDetails()
        {
            isCritical = critical,//是否暴击
            isDead = false,//是否死亡
            isEffect =typeEffect//是否效果显著

        };
        float _attack = (skill._base.SkillCategory == SkillCategory.Special) ? attacker.SpAttack :attacker.Attack ;//查看这次攻击是否为属性攻击，是的话则使用特殊攻击计算伤害，不是则使用普通攻击
        float _defense = (skill._base.SkillCategory == SkillCategory.Special) ? SpDefende : Defende;//防御同理

        float Power = UnityEngine.Random.Range(0.85f, 1f) * typeEffect * critical;//伤害倍数，0.85到1之间
        //********
        int damage = (int)(((_attack + skill._base.Power) - _defense) * Power);//伤害公式**以后调整
        //********

        UpdateHP(damage);

        return damageDetail;//将这次攻击的是否暴击，是否有死亡，是否效果显著返回给BattleManager
        
    }

    public void SetStatus(ConditionID conditionid)//用来设置当前PokeX处于什么异常状态中
    {
        if (status != null) return;

        status = ConditionDB.Conditions[conditionid];
        status?.OnStart?.Invoke(this);
        StatusChanges.Enqueue($"{Base.Name} {status.StartMessage}");
        OnStatusChanged?.Invoke();
    }

    public void SetVolatailStatus(ConditionID conditionid)//用来设置当前PokeX处于什么异常状态中
    {
        if (volatileStatus != null) return;

        volatileStatus = ConditionDB.Conditions[conditionid];
        volatileStatus?.OnStart?.Invoke(this);
        StatusChanges.Enqueue($"{Base.Name} {volatileStatus.StartMessage}");
    }

    public void CureVolatileStatus()//治疗不稳定的异常状态（如混乱）
    {
        volatileStatus = null;
    }

    public Skill GetRandomSkill()//获取当前PokeX的一个随机技能。
    {
        int randomSkill = UnityEngine.Random.Range(0, Skills.Count);
        return Skills[randomSkill];
    }

    public void onBattleOver()//战斗结束
    {
        volatileStatus = null;
        ResetStateBoost();
    }

    public void UpdateHP(int damage)//更新自身的血量
    {
        CurrentHP =Mathf.Clamp(CurrentHP - damage,0,MaxHP);
        HPchanged = true;
    }

    public bool OnBeforeUseSkill()//用来在战斗开始时，判断这回合是否能够出手
    {
        bool canPerformSkill = true;
        if(status?.OnBeforeSkill != null)
        {
            if (!status.OnBeforeSkill(this))
            {
                canPerformSkill = false;
            }
        }
        if (volatileStatus?.OnBeforeSkill != null)
        {
            if (!volatileStatus.OnBeforeSkill(this))
            {
                canPerformSkill = false;
            }
        }
        return canPerformSkill;
    }
    public void OnAfterTurn()//用来在战斗结束时计算异常状态伤害
    {
        status?.OnAfterTurn?.Invoke(this);
        volatileStatus?.OnAfterTurn?.Invoke(this);
    }

    public void CureStatus()//从异常状态中恢复
    {
        status = null;
        OnStatusChanged?.Invoke();
    }

}



public enum State
{
    Attack,Defense,SpAttack,SpDefense,Speed
}

public class DamageDetails//三个参数。
{
    public bool isDead { get; set; }

    public float isEffect { get; set; }

    public float isCritical { get; set; }
}