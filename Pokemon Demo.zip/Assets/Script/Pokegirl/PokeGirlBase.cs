﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "PokeX/Creat New PokeX", fileName = "New PokeX")]
public class PokeGirlBase : ScriptableObject
{
    //↓私有变量，serializeField为了能在面板上直接更改
    [SerializeField] string pokeXName;

    [TextArea]
    [SerializeField] string describe;

    [SerializeField] Sprite sprite;

    [SerializeField] Type type;



    [SerializeField] int level;
    [SerializeField] int maxHP;
    [SerializeField] int currentHP;
    [SerializeField] int baseAttack;
    [SerializeField] int baseDefende;
    [SerializeField] int speed;
    [SerializeField] int spAttack;
    [SerializeField] int spDefende;

    [SerializeField] List<LearnableSkill> learnableSkill;
    //get set 构造器，为了保护变量，并且又能够像public变量一样随时调用，get是只读，set是可以更改。
    public string Name
    {
        get { return pokeXName; }
    }
    public string Description
    {
        get { return describe; }
    }
    public Sprite Sprite
    {
        get { return sprite; }
    }
    public Type Type
    {
        get { return type; }
    }
    public int Level
    {
        get { return level; }
    }
    public int MaxHp
    {
        get { return maxHP; }
    }
    public int CurrentHP
    {
        get { return currentHP; }
        set { currentHP = value; }
    }
    public int BaseAttack
    {
        get { return baseAttack; }
    }
    public int BaseDefende
    {
        get { return baseDefende; }
    }
    public int Speed
    {
        get { return speed; }
    }
    public int SpAttack
    {
        get { return spAttack; }
    }
    public int SpDefende
    {
        get { return spDefende; }
    }

    public List<LearnableSkill> LearnableSkill
    {
        get { return learnableSkill; }
    }
}
[System.Serializable]
public class LearnableSkill//可学习系的技能
{
    [SerializeField] SkillBase skillBase;
    [SerializeField] int level;

    public SkillBase SkillBase
    {
        get { return skillBase; }
    }
    public int Level
    {
        get { return level; }
    }

}

 public enum Type {None,Fire,Water,Grass,Light,Dark };

public class TypeChart//属性克制系统，横坐标和纵坐标分别为属性在Enum中的位置。
{
    static float[][] Chart =
    {   //                     None Fire Water Grass Light Dark
        /*None*/   new float[]{1f,  1f,  1f,   1f,   1f,   1f},
        /*Fire*/   new float[]{1f,  1f,  0.5f, 1.5f, 1f,   1f},
        /*Water*/  new float[]{1f,  1.5f,1f,   0.5f, 1f,   1f},
        /*Grass*/  new float[]{1f,  0.5f,1.5f, 1f,   1f,   1f},
        /*Light*/  new float[]{1f,  1f,  1f,   1f,   1f,   1.25f},
        /*Dark*/   new float[]{1f,  1f,  1f,   1f,   1.25f,1f}
    };

    public static float GetEffectiness(Type attackerType,Type defenseType)//获取属性克制系数
    {
        if (attackerType == Type.None || defenseType == Type.None) return 1;

        int col = (int)attackerType;
        int row = (int)defenseType;

        return Chart[col][row];
        
    }
}