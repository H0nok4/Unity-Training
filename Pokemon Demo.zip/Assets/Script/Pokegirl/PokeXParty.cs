﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

//这个脚本中写着队伍系统的相关函数
public class PokeXParty : MonoBehaviour
{
    [SerializeField] List<PokeGirl> PokeGirls;

    public List<PokeGirl> pokeGirls
    {
        get
        {
            return PokeGirls;
        }
    }
    private void Start()
    {
        foreach(var pokeX in PokeGirls)
        {
            pokeX.Init();
        }
    }

    public PokeGirl GetHealthyParty()
    {
        return PokeGirls.Where(x => x.CurrentHP > 0).FirstOrDefault();
    }
}
