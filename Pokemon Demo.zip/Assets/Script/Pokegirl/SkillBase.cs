﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(menuName = "PokeX/Creat New Skill", fileName = "New Skill")]
public class SkillBase : ScriptableObject
{//技能系统基础，同样，SerializeField用来保护变量，并且用get，set构造器来可读可改。
    [SerializeField] string skillName;

    [TextArea]
    [SerializeField] string skillDescription;

    [SerializeField] Type type;

    [SerializeField] int power;
    [SerializeField] int accuracy;

    [SerializeField] int pp;

    [SerializeField] SkillCategory category;

    [SerializeField] SkillEffects effects;

    [SerializeField] SkillTarget target;

    public string Name
    {
        get { return skillName; }
    }
    public string SkillDescription
    {
        get { return skillDescription; }
    }
    public Type SkillType
    {
        get { return type; }
    }
    public int Power
    {
        get { return power; }
    }
    public int Accuracy
    {
        get { return accuracy; }
    }
    public int PP
    {
        get { return pp; }
    }

    public SkillCategory SkillCategory
    {
        get { return category; }
    }

    public SkillEffects SkillEffects//技能效果
    {
        get { return effects; }
    }

    public SkillTarget SkillTarget//技能的目标
    {
        get { return target; }
    }

}


[System.Serializable]
public class SkillEffects//技能所带的效果
{
    [SerializeField] List<StateBoost> stateBoostList;
    [SerializeField] ConditionID status;

    public ConditionID Status
    {
        get { return status; }
    }
    public List<StateBoost> StateBoostList
    {
        get { return stateBoostList; }
    }
}
[System.Serializable]
public class StateBoost//属性提升
{
    public State state;
    public int boostValue;
}

public enum SkillCategory
{
    Physical,Special,StatusChange
}

public enum SkillTarget
{
    Foe,Self
}

