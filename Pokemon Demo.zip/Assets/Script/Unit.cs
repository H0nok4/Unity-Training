﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour
{
    public string Name;

    public int level;

    public int attck;

    public int maxHP;
    public int currentHP;

    public int speed;

}
