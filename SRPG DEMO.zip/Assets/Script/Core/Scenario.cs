﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[CreateAssetMenu(fileName = "new Scenario",menuName = "SPRG/Scenario")]
public class Scenario : ScriptableObject
{
    public List<Dialogue> dialogues;

    public Action onEnd;
}
