﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScenarioPlayer : MonoBehaviour
{
    //播放传入的Scenario剧情
    public void Play(Scenario scenario)
    {

    }
}
