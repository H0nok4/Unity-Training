﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScenceManager : MonoBehaviour
{
    public List<SrpgClass> playerClasses;
    public List<SrpgClass> enemyClasses;
    public List<SrpgClass> allyClasses;
    public List<SrpgClass> neutralClasses;
    public Dictionary<Vector3Int,GameObject> mapObjectGameObjects;

    public void InitAllMapObject()
    {
        mapObjectGameObjects = new Dictionary<Vector3Int, GameObject>();
        var gameobjects = GameObject.FindGameObjectsWithTag("MapObject");
        foreach(var mapObjectGameObject in gameobjects)
        {
            mapObjectGameObjects.Add(new Vector3Int((int)mapObjectGameObject.transform.position.x, (int)mapObjectGameObject.transform.position.y, 0), mapObjectGameObject);
        }
    }
    public void UpdateMapObjectPosition(MapObject mapObject)
    {
        Vector3Int removePos;
        foreach(var kvp in mapObjectGameObjects)
        {
            if(kvp.Value == mapObject)
            {
                removePos = kvp.Key;
                break;
            }
        }

        mapObjectGameObjects.Add(mapObject.m_Position,mapObject.gameObject);
    }
    public void UpdateMapObjectPosition()
    {
        List<Vector3Int> needUpdatePosition = new List<Vector3Int>();
        List<GameObject> needAddGameobject = new List<GameObject>();
        foreach (var kvp in mapObjectGameObjects)
        {
            if(kvp.Value.GetComponent<MapObject>().m_Position != kvp.Key)
            {
                needAddGameobject.Add(kvp.Value);
                needUpdatePosition.Add(kvp.Key);

            }
        }
        foreach(var gameObject in needAddGameobject)
        {
            mapObjectGameObjects.Add(new Vector3Int(gameObject.GetComponent<MapObject>().m_Position.x, gameObject.GetComponent<MapObject>().m_Position.y, 0), gameObject);
        }
        foreach(var pos in needUpdatePosition)
        {
            mapObjectGameObjects.Remove(pos);
        }

    }

    public SrpgClass GetClassInVector3Int(Vector3Int classPos)
    {
        if (mapObjectGameObjects.ContainsKey(classPos))
            return mapObjectGameObjects[classPos].GetComponent<SrpgClass>();
        else
            return null;
    }

    public void InitClass()
    {
        foreach(var Class in playerClasses)
        {
            Class.InitClass();
        }
        foreach (var Class in enemyClasses)
        {
            Class.InitClass();
            Class.SetDefaultAIBaseOnClassType();
        }
        foreach (var Class in allyClasses)
        {
            Class.InitClass();
            Class.SetDefaultAIBaseOnClassType();
        }
        foreach (var Class in neutralClasses)
        {
            Class.InitClass();
            Class.SetDefaultAIBaseOnClassType();
        }
    }

    public void DestroyMapObject(MapObject destroyMapObject)
    {
        mapObjectGameObjects.Remove(destroyMapObject.m_Position);
        destroyMapObject.OnDispawn();
    }
}
