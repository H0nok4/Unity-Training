﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[SerializeField]
public class item
{
    public Sprite sprite;
}
