﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Born : MonoBehaviour
{
    SpriteAnimator bornAnim;

    [SerializeField]List<Sprite> bornSprits;

    SpriteRenderer spriteRenderer;

    float timer;

    bool IsPlayerBorn;

    public bool isPlayerBorn
    {
        get;set;
    }

    [SerializeField] GameObject playerTank1;
    [SerializeField] GameObject enemyTank1;
    [SerializeField] GameObject enemyTank2;

    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        bornAnim = new SpriteAnimator(bornSprits, spriteRenderer,0.32f);
    }

    public void Update()
    {
        timer += Time.deltaTime;
        bornAnim.HandleUpdate();
        if(timer >= 1.28f)
        {
            BornTank(transform.position, isPlayerBorn);
            Destroy(gameObject);
        }
    }

    public void BornTank(Vector3 Pos,bool isPlayerTank)
    {
        if (isPlayerTank)
        {
            Instantiate(playerTank1, Pos, transform.rotation);
        }
        else
        {
            if (Random.Range(1, 4) == 1)
            {
                Instantiate(enemyTank2, Pos, transform.rotation);
            }
            else
            {
                Instantiate(enemyTank1, Pos, transform.rotation);
            }
        }
    }

}
