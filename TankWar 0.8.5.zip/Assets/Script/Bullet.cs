﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] float BulletSpeed = 10;
    private void FixedUpdate()
    {
        transform.Translate(transform.up * BulletSpeed * Time.deltaTime, Space.World);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("EnemyTank"))
        {
            collision.GetComponent<Tank>().Die();
            DestroyBullet();
        }else if (collision.CompareTag("Bullet"))
        {
            collision.GetComponent<Bullet>().DestroyBullet();
            DestroyBullet();
        }
        else if (collision.CompareTag("Wall"))
        {
            collision.GetComponent<Wall>().DestroyWall();
            DestroyBullet();
        }
        else if (collision.CompareTag("Barrir"))
        {
            DestroyBullet();
        }
        else if (collision.CompareTag("Player"))
        {
            collision.GetComponent<PlayerController>().CheckPlayerCanRelife();
            DestroyBullet();
        }
        else if (collision.CompareTag("Home"))
        {
            //结束游戏
            DestroyBullet();
        }

    }

    public void DestroyBullet()
    {
        Destroy(gameObject);
    }
}
