﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    float timer;
    float MoveTimer;

    float MoveH;
    float MoveV;

    Tank tank;

    private void Awake()
    {
        tank = GetComponent<Tank>();
    }

    private void Update()
    {
        RandomFire();
        RandomMove();

    }

    private void FixedUpdate()
    {
        tank.Move(new Vector3(MoveH, MoveV, 0));
    }

    public void RandomMove()
    {
        MoveTimer += Time.deltaTime;
        if(MoveTimer >= 3)
        {
            var r = Random.Range(0, 8);
            if (r <= 3)
            {
                MoveH = 0;
                MoveV = -1;
            }
            else if (r <= 4)
            {
                MoveH = 1;
                MoveV = 0;
            }
            else if (r <= 5)
            {
                MoveH = -1;
                MoveV = 0;
            }
            else if (r <= 6)
            {
                MoveH = 0;
                MoveV = 1;
            }
            else if (r <= 7)
            {
                MoveH = 0;
                MoveV = 0;
            }
            MoveTimer -= 3;
        }


    }

    public void RandomFire()
    {
        timer += Time.deltaTime;
        if (timer >= tank.reloadTime)
        {
            if (Random.Range(1, 3) == 1)
            {
                tank.Fire();
            }
            timer -= tank.reloadTime;
        }
    }
}
