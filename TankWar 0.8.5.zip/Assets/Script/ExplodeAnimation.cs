﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class ExplodeAnimation : MonoBehaviour
{
    SpriteAnimator animator;

    SpriteRenderer spriteRenderer;

    [SerializeField]List<Sprite> explodeSprites;

    public bool isSingleTimesAnimation = true;

    float timer;
    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }
    private void Start()
    {
        animator = new SpriteAnimator(explodeSprites,spriteRenderer,0.32f);
    }

    private void Update()
    {
        animator.HandleUpdate();
        timer += Time.deltaTime;
        if(timer > 0.64f)
        {
            Destroy(this.gameObject);
        }
    }



}
