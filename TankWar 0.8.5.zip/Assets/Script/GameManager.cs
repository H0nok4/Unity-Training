﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum GameState { start,playering,end}
public class GameManager : MonoBehaviour
{
    public GameState State;

    public int PlayerHealthy = 3;
    public static GameManager instance { get; private set; }


    private void Awake()
    {
        instance = this;
    }

    public void Update()
    {
        if(State == GameState.start)
        {
            //显示主菜单
        }else if(State == GameState.playering)
        {
            //运行游戏逻辑
        }else if(State == GameState.end)
        {
            //结束游戏
        }
    }

    public bool ChackPlayerHealthy()
    {
        if(PlayerHealthy > 0)
        {
            PlayerHealthy--;
            return true;
        }
        return false;
    }
}
