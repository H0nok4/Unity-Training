﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntMap : MonoBehaviour
{
    [SerializeField] GameObject barrir;
    [SerializeField] GameObject home;
    [SerializeField] GameObject Wall;
    [SerializeField] GameObject Grass;
    [SerializeField] GameObject water;

    [SerializeField] GameObject MapManager;

    [SerializeField] GameObject BornObject;
    [SerializeField] int MapLength;
    [SerializeField] int MapHight;

    float EnemyBornTimer;
    public int mapLength
    {
        get => MapLength;
    }
    public int mapHight
    {
        get => MapHight;
    }

    bool[,] isCreated;
    private void Awake()
    {
        isCreated = new bool[MapLength, mapHight];
        InitOutWall();
        InitHome();
        BornPlayer();
        for(int i = 0;i< 3; i++)
        {
            BornEnemy();
        }
        RandomCreatMap();
    }

    public void BornEnemyOnTime()
    {
        EnemyBornTimer += Time.deltaTime;
        if(EnemyBornTimer > 8)
        {
            BornEnemy();
            EnemyBornTimer -= 8;
        }
    }

    public void Update()
    {
        BornEnemyOnTime();
    }
    public void BornEnemy()
    {
        Instantiate(BornObject, new Vector3(Random.Range(1, mapLength), mapHight - 1, 0), transform.rotation);
    }

    public void InitOutWall()
    {
        for (int i = 0; i < 17; i++)
        {
            Instantiate(barrir, new Vector3(i, 0, 0), transform.rotation);
            Instantiate(barrir, new Vector3(i, 18, 0), transform.rotation);
        }
        for (int i = 1; i < 18; i++)
        {
            Instantiate(barrir, new Vector3(0, i, 0), transform.rotation);
            Instantiate(barrir, new Vector3(16, i, 0), transform.rotation);
        }
    }

    public void InitHome()
    {
        Instantiate(home, new Vector3(8, 1, 0), transform.rotation);
        for(int i = 0; i < 3; i++)
        {
            Instantiate(Wall, new Vector3(7 + i, 2, 0),transform.rotation);
        }
        Instantiate(Wall, new Vector3(7, 1, 0), transform.rotation);
        Instantiate(Wall, new Vector3(9, 1, 0), transform.rotation);
    }

    public void RandomCreatMap()
    {
        for(int i = 0;i< 100; i++)
        {
            CreatMapObject(Wall, new Vector3(Random.Range(1, mapLength - 1), Random.Range(3, mapHight - 1), 0));
        }
        for(int i = 0; i < 10; i++)
        {
            CreatMapObject(barrir, new Vector3(Random.Range(1, mapLength - 1), Random.Range(3, mapHight - 1), 0));
        }

    }

    public void CreatMapObject(GameObject obj,Vector3 Pos)
    {
        if(isCreated[(int)Pos.x, (int)Pos.y] == false)
        {
            var Temp = Instantiate(obj, Pos, transform.rotation);
            Temp.transform.SetParent(MapManager.transform);
            isCreated[(int)Pos.x, (int)Pos.y] = true;
        }
    }

    public void BornPlayer()
    {
        var player = Instantiate(BornObject, new Vector3(6, 1, 0), transform.rotation);
        player.GetComponent<Born>().isPlayerBorn = true;
    }
}
