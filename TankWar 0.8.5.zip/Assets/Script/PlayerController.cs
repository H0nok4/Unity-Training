﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    

    private Vector2 input;

    Tank tank;

    private void Awake()
    {
        tank = GetComponent<Tank>();
    }

    public void FixedUpdate()
    {
        input.x = Input.GetAxisRaw("Horizontal");
        input.y = Input.GetAxisRaw("Vertical");

        if (input.x != 0) input.y = 0;

        //Vector3 targetPos = new Vector3(transform.position.x +Mathf.Clamp(input.x,-1,1), transform.position.y + Mathf.Clamp(input.y,-1,1), 0f);

        if (input != Vector2.zero)
        {
            tank.Move(input);
        }
    }

    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.J))
        {
            tank.Fire();
        }
    }

    public void CheckPlayerCanRelife()
    {
        if (GameManager.instance.ChackPlayerHealthy())
        {
            //复活玩家
        }
        else
        {
            GameManager.instance.State = GameState.end;
        }
    }

}
