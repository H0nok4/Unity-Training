﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank : MonoBehaviour
{
    public float moveSpeed = 5;

    TankAnimator animator;

    [SerializeField] GameObject bulletPrefab;

    bool canFire = true;
    float timer = 0;
    [SerializeField]float ReloadTime;

    [SerializeField]GameObject explodeAnimation;

    public float reloadTime
    {
        get => ReloadTime;
    }
    private void Awake()
    {
        animator = GetComponent<TankAnimator>();
    }

    public void Fire()
    {
        if (canFire == true)
        {
            Instantiate(bulletPrefab, GetFireDirection(), Quaternion.Euler(0f, 0f, animator.faceDirection));
            canFire = false;
            StartCoroutine(Reload());
        }

    }

    public Vector3 GetFireDirection()
    {
        if (animator.faceDirection == 0f)
            return new Vector3(transform.position.x, transform.position.y + 0.55f, transform.position.z);
        else if(animator.faceDirection == 90f)
            return new Vector3(transform.position.x - 0.55f, transform.position.y, transform.position.z);
        else if (animator.faceDirection == 180f)
            return new Vector3(transform.position.x, transform.position.y - 0.55f, transform.position.z);
        else if (animator.faceDirection == 270f)
            return new Vector3(transform.position.x + 0.55f, transform.position.y, transform.position.z);

        return transform.position;
    }

    public IEnumerator Reload()
    {
        yield return new WaitForSeconds(ReloadTime);
        canFire = true;
    }

    public void Move(Vector2 moveVector)
    {
        animator.moveX = Mathf.Clamp(moveVector.x, -1, 1);
        animator.moveY = Mathf.Clamp(moveVector.y, -1, 1);

        transform.Translate(moveVector * moveSpeed * Time.deltaTime, Space.World);
    }

    public void Die()
    {
        Instantiate(explodeAnimation, transform.position, transform.rotation);
        Destroy(gameObject);
    }
}
