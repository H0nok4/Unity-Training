﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TankAnimator : MonoBehaviour
{
    public float moveX { get; set; }
    public float moveY { get; set; }

    public bool isWalked { get; set; }

    [SerializeField]Sprite leftSprite;
    [SerializeField]Sprite rightSprite;
    [SerializeField]Sprite downSprite;
    [SerializeField]Sprite upSprite;

    Sprite currentFace;
    SpriteRenderer spRenderer;

    float FaceDirection;

    public float faceDirection
    {
        get;
        private set;
    }
    private void Awake()
    {
        spRenderer = GetComponent<SpriteRenderer>();
        currentFace = upSprite;
    }

    private void Update()
    {
        var prvFace = currentFace;

        if (moveX == 1)
        {
            currentFace = rightSprite;
            faceDirection = 270f;
        }
        else if (moveX == -1)
        {
            currentFace = leftSprite;
            faceDirection = 90f;
        }
        else if (moveY == -1)
        {
            currentFace = downSprite;
            faceDirection = 180f;
        }
        else if (moveY == 1)
        {
            currentFace = upSprite;
            faceDirection = 0f;
        }


        spRenderer.sprite = currentFace;
    }

}
