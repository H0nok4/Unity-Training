﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameConstants
{
    public const string k_LeftMouseKey = "Fire 0";
}
