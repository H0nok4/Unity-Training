﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AchievmentSystem
{
    public int a_TotalCauseDamage = 0;
    public int a_TotalReciveDamage = 0;
    public int a_TotalKillEnemy = 0;
    public int a_TotalDeadUnit = 0;

    public void CheckAchievmentUnlock()
    {

    }
}
